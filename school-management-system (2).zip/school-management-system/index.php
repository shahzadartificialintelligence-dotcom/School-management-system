<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ghazali School - Excellence in Education</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap');
        
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            position: relative;
            overflow: hidden;
        }
        
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="%23ffffff" fill-opacity="0.1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,170.7C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>');
            background-repeat: no-repeat;
            background-position: bottom;
            background-size: cover;
            opacity: 0.1;
        }
        
        .floating-shapes {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 1;
        }
        
        .floating-shapes div {
            position: absolute;
            display: block;
            list-style: none;
            width: 20px;
            height: 20px;
            background: rgba(255, 255, 255, 0.2);
            animation: animate 25s linear infinite;
            bottom: -150px;
            border-radius: 50%;
        }
        
        @keyframes animate {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(-1000px) rotate(720deg);
                opacity: 0;
            }
        }
        
        .floating-shapes div:nth-child(1) {
            left: 10%;
            width: 80px;
            height: 80px;
            animation-delay: 0s;
        }
        
        .floating-shapes div:nth-child(2) {
            left: 20%;
            width: 40px;
            height: 40px;
            animation-delay: 2s;
            animation-duration: 17s;
        }
        
        .floating-shapes div:nth-child(3) {
            left: 30%;
            width: 60px;
            height: 60px;
            animation-delay: 4s;
        }
        
        .floating-shapes div:nth-child(4) {
            left: 60%;
            width: 50px;
            height: 50px;
            animation-delay: 0s;
            animation-duration: 22s;
        }
        
        .floating-shapes div:nth-child(5) {
            left: 70%;
            width: 70px;
            height: 70px;
            animation-delay: 3s;
        }
        
        .floating-shapes div:nth-child(6) {
            left: 80%;
            width: 30px;
            height: 30px;
            animation-delay: 7s;
            animation-duration: 12s;
        }
        
        .feature-card {
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        
        .login-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
            border: 2px solid white;
        }
        
        .login-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .footer {
            background: linear-gradient(135deg, #1a1c2c 0%, #2d2f42 100%);
        }
        
        .social-icon {
            transition: all 0.3s ease;
        }
        
        .social-icon:hover {
            transform: translateY(-5px);
            color: #667eea;
        }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navigation Bar -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex items-center space-x-3">
                    <div class="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-graduation-cap text-white text-xl"></i>
                    </div>
                    <span class="text-2xl font-extrabold text-gray-800">Ghazali <span class="text-blue-600">School</span></span>
                </div>
                
                <div class="hidden md:flex items-center space-x-8">
                    <a href="#home" class="text-gray-700 hover:text-blue-600 font-medium transition">Home</a>
                    <a href="#about" class="text-gray-700 hover:text-blue-600 font-medium transition">About</a>
                    <a href="#programs" class="text-gray-700 hover:text-blue-600 font-medium transition">Programs</a>
                    <a href="#contact" class="text-gray-700 hover:text-blue-600 font-medium transition">Contact</a>
                </div>
                
                <a href="dashboard.php" class="login-btn text-white font-bold py-3 px-8 rounded-full shadow-lg">
                    <i class="fas fa-sign-in-alt mr-2"></i>Dashboard
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section relative min-h-screen flex items-center justify-center overflow-hidden">
        <!-- Floating Shapes Animation -->
        <div class="floating-shapes">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
        
        <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
            <div class="animate-bounce mb-8">
                <div class="w-24 h-24 bg-white rounded-full mx-auto flex items-center justify-center shadow-2xl">
                    <i class="fas fa-graduation-cap text-5xl text-blue-600"></i>
                </div>
            </div>
            
            <h1 class="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-tight">
                Welcome to <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-400">
                    Ghazali School
                </span>
            </h1>
            
            <p class="text-xl md:text-2xl text-white/90 mb-12 max-w-3xl mx-auto">
                Empowering minds, shaping futures, and building tomorrow's leaders through excellence in education.
            </p>
            
            <div class="flex flex-col sm:flex-row gap-6 justify-center items-center">
                <a href="dashboard.php" class="bg-white text-blue-600 font-bold py-4 px-12 rounded-full text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-300">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Get Started
                </a>
                
                <a href="#about" class="border-2 border-white text-white font-bold py-4 px-12 rounded-full text-xl hover:bg-white hover:text-blue-600 transform hover:scale-110 transition-all duration-300">
                    <i class="fas fa-play-circle mr-2"></i>
                    Learn More
                </a>
            </div>
            
            <!-- Stats -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
                <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <div class="text-4xl font-bold mb-2">500+</div>
                    <div class="text-lg">Students Enrolled</div>
                </div>
                <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <div class="text-4xl font-bold mb-2">50+</div>
                    <div class="text-lg">Expert Teachers</div>
                </div>
                <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 text-white">
                    <div class="text-4xl font-bold mb-2">15+</div>
                    <div class="text-lg">Academic Programs</div>
                </div>
            </div>
        </div>
        
        <!-- Bottom Wave -->
        <div class="absolute bottom-0 left-0 right-0">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
                <path fill="#f9fafb" fill-opacity="1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,170.7C1248,160,1344,128,1392,112L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
            </svg>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">About Ghazali School</h2>
                <div class="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto"></div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div>
                    <img src="https://daily.jstor.org/wp-content/uploads/2017/12/blackboard_classroom_1050x700-600x400.jpg" 
                         alt="School Building" 
                         class="rounded-2xl shadow-2xl">
                </div>
                <div class="space-y-6">
                    <p class="text-lg text-gray-600 leading-relaxed">
                        Ghazali School has been a beacon of educational excellence for over two decades. We believe in nurturing young minds and preparing them for the challenges of tomorrow through a comprehensive and balanced curriculum.
                    </p>
                    <p class="text-lg text-gray-600 leading-relaxed">
                        Our state-of-the-art facilities, experienced faculty, and innovative teaching methods ensure that every student reaches their full potential.
                    </p>
                    
                    <div class="grid grid-cols-2 gap-4 pt-6">
                        <div class="bg-white p-4 rounded-xl shadow-md">
                            <i class="fas fa-flask text-3xl text-blue-600 mb-2"></i>
                            <h3 class="font-bold">Science Labs</h3>
                        </div>
                        <div class="bg-white p-4 rounded-xl shadow-md">
                            <i class="fas fa-book-open text-3xl text-purple-600 mb-2"></i>
                            <h3 class="font-bold">Library</h3>
                        </div>
                        <div class="bg-white p-4 rounded-xl shadow-md">
                            <i class="fas fa-laptop text-3xl text-green-600 mb-2"></i>
                            <h3 class="font-bold">Computer Lab</h3>
                        </div>
                        <div class="bg-white p-4 rounded-xl shadow-md">
                            <i class="fas fa-futbol text-3xl text-orange-600 mb-2"></i>
                            <h3 class="font-bold">Sports Complex</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Programs Section -->
    <section id="programs" class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">Our Academic Programs</h2>
                <div class="w-24 h-1 bg-gradient-to-r from-blue-600 to-purple-600 mx-auto"></div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="feature-card bg-white rounded-2xl shadow-xl p-8 text-center">
                    <div class="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-child text-4xl text-blue-600"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">Primary School</h3>
                    <p class="text-gray-600">Grades 1-5: Building strong foundations with creative learning approaches.</p>
                </div>
                
                <div class="feature-card bg-white rounded-2xl shadow-xl p-8 text-center">
                    <div class="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-users text-4xl text-purple-600"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">Middle School</h3>
                    <p class="text-gray-600">Grades 6-8: Developing critical thinking and subject expertise.</p>
                </div>
                
                <div class="feature-card bg-white rounded-2xl shadow-xl p-8 text-center">
                    <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-graduation-cap text-4xl text-green-600"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4">High School</h3>
                    <p class="text-gray-600">Grades 9-12: Preparing for higher education and career success.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div class="max-w-4xl mx-auto text-center px-4">
            <h2 class="text-4xl font-bold text-white mb-6">Ready to Start Your Journey?</h2>
            <p class="text-xl text-white/90 mb-10">Join Ghazali School today and give your child the gift of quality education.</p>
            <a href="dashboard.php" class="inline-block bg-white text-blue-600 font-bold py-4 px-12 rounded-full text-xl shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-300">
                <i class="fas fa-sign-in-alt mr-2"></i>
                Dashboard
            </a>
        </div>
    </section>

    <!-- Footer -->
    <footer id="contact" class="footer text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-12">
                <!-- School Info -->
                <div>
                    <div class="flex items-center space-x-3 mb-6">
                        <div class="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                            <i class="fas fa-graduation-cap text-2xl text-blue-600"></i>
                        </div>
                        <span class="text-2xl font-bold">Ghazali School</span>
                    </div>
                    <p class="text-gray-300 mb-6">Excellence in education since 2000. Nurturing young minds for a brighter future.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="social-icon w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-blue-600">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="social-icon w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-blue-600">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="social-icon w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-blue-600">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="social-icon w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-blue-600">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div>
                    <h3 class="text-xl font-bold mb-6">Quick Links</h3>
                    <ul class="space-y-3">
                        <li><a href="#home" class="text-gray-300 hover:text-white transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>Home</a></li>
                        <li><a href="#about" class="text-gray-300 hover:text-white transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>About Us</a></li>
                        <li><a href="#programs" class="text-gray-300 hover:text-white transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>Programs</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>Admissions</a></li>
                        <li><a href="#" class="text-gray-300 hover:text-white transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>Contact</a></li>
                    </ul>
                </div>
                
                <!-- Contact Info -->
                <div>
                    <h3 class="text-xl font-bold mb-6">Contact Us</h3>
                    <ul class="space-y-4">
                        <li class="flex items-start space-x-3">
                            <i class="fas fa-map-marker-alt mt-1 text-blue-400"></i>
                            <span class="text-gray-300">123 Education Street, Knowledge City, KC 12345</span>
                        </li>
                        <li class="flex items-center space-x-3">
                            <i class="fas fa-phone text-blue-400"></i>
                            <span class="text-gray-300">+1 234 567 8900</span>
                        </li>
                        <li class="flex items-center space-x-3">
                            <i class="fas fa-envelope text-blue-400"></i>
                            <span class="text-gray-300">info@ghazalischool.com</span>
                        </li>
                        <li class="flex items-center space-x-3">
                            <i class="fas fa-clock text-blue-400"></i>
                            <span class="text-gray-300">Mon-Fri: 8:00 AM - 4:00 PM</span>
                        </li>
                    </ul>
                </div>
                
                <!-- Newsletter -->
                <div>
                    <h3 class="text-xl font-bold mb-6">Newsletter</h3>
                    <p class="text-gray-300 mb-4">Subscribe to get updates about events and news</p>
                    <form class="space-y-3">
                        <input type="email" placeholder="Your email" 
                               class="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-white">
                        <button type="submit" class="w-full bg-white text-blue-600 font-bold py-3 px-6 rounded-lg hover:bg-gray-100 transition">
                            Subscribe
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Copyright -->
            <div class="border-t border-white/10 mt-12 pt-8 text-center">
                <p class="text-gray-400">
                    &copy; <?= date('Y') ?> Ghazali School. All rights reserved. | 
                    <a href="#" class="hover:text-white transition">Privacy Policy</a> | 
                    <a href="#" class="hover:text-white transition">Terms of Service</a>
                </p>
            </div>
        </div>
    </footer>
    
    <!-- Floating Login Button (Mobile) -->
    <div class="fixed bottom-6 right-6 md:hidden z-50">
        <a href="auth/login.php" class="w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform">
            <i class="fas fa-sign-in-alt text-white text-xl"></i>
        </a>
    </div>

    <!-- Smooth Scroll -->
    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
</body>
</html>