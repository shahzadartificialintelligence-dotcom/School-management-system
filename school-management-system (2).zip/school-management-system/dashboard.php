<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ghazali School | Campus Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap');
        
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            position: relative;
            overflow-x: hidden;
            /* overflow-hidden removed to allow scrolling */
        }
        
        /* Animated Background Elements */
        .bg-shape {
            position: absolute;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            filter: blur(60px);
            z-index: 0;
        }
        
        .shape-1 {
            width: 400px;
            height: 400px;
            top: -100px;
            left: -100px;
            background: rgba(255, 182, 193, 0.3);
            animation: float 8s ease-in-out infinite;
        }
        
        .shape-2 {
            width: 350px;
            height: 350px;
            bottom: -50px;
            right: -50px;
            background: rgba(135, 206, 235, 0.3);
            animation: float 10s ease-in-out infinite reverse;
        }
        
        .shape-3 {
            width: 300px;
            height: 300px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 255, 255, 0.15);
            animation: pulse 12s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-30px) rotate(5deg); }
        }
        
        @keyframes pulse {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.3; }
            50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.5; }
        }
        
        /* Glass Card Effect */
        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            position: relative;
            z-index: 10;
            overflow: hidden;
        }
        
        .glass-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                45deg,
                transparent,
                rgba(255, 255, 255, 0.3),
                transparent
            );
            transform: rotate(45deg);
            transition: transform 0.6s ease;
            opacity: 0;
        }
        
        .glass-card:hover::before {
            transform: rotate(45deg) translate(50%, 50%);
            opacity: 1;
        }
        
        .hover-scale {
            transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.4s ease;
        }
        
        .hover-scale:hover {
            transform: translateY(-15px) scale(1.02);
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.4);
        }
        
        /* Icon Circle */
        .icon-circle {
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            z-index: 2;
        }
        
        .icon-circle::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 100%;
            height: 100%;
            background: inherit;
            border-radius: 50%;
            transform: translate(-50%, -50%) scale(1);
            z-index: -1;
            opacity: 0.3;
            transition: all 0.4s ease;
        }
        
        .group:hover .icon-circle::after {
            transform: translate(-50%, -50%) scale(1.5);
            opacity: 0.2;
        }
        
        /* Campus Badge */
        .campus-badge {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 5px 15px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            z-index: 20;
        }
        
        .badge-girls {
            background: linear-gradient(135deg, #fbc2c2 0%, #ff9a9e 100%);
            color: #7f1d1d;
        }
        
        .badge-boys {
            background: linear-gradient(135deg, #b2d8fa 0%, #6ab0f5 100%);
            color: #1e3c72;
        }
        
        /* Feature List */
        .feature-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            color: #4b5563;
            margin-bottom: 8px;
        }
        
        .feature-item i {
            font-size: 12px;
            color: #10b981;
        }
        
        /* Welcome Text */
        .welcome-text {
            background: linear-gradient(135deg, #fff5f5 0%, #f0f9ff 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        
        /* Floating Particles */
        .particle {
            position: absolute;
            background: white;
            border-radius: 50%;
            opacity: 0.3;
            pointer-events: none;
        }
        
        .particle-1 {
            width: 10px;
            height: 10px;
            top: 20%;
            left: 10%;
            animation: float 6s ease-in-out infinite;
        }
        
        .particle-2 {
            width: 15px;
            height: 15px;
            top: 70%;
            right: 15%;
            animation: float 8s ease-in-out infinite reverse;
        }
        
        .particle-3 {
            width: 8px;
            height: 8px;
            bottom: 30%;
            left: 20%;
            animation: float 7s ease-in-out infinite 1s;
        }
        
        .particle-4 {
            width: 12px;
            height: 12px;
            top: 40%;
            right: 25%;
            animation: float 9s ease-in-out infinite 0.5s;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .shape-1, .shape-2, .shape-3 {
                display: none;
            }
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6 relative">
    <!-- Removed overflow-hidden to allow scrolling -->

    <!-- Animated Background Shapes -->
    <div class="shape-1 bg-shape"></div>
    <div class="shape-2 bg-shape"></div>
    <div class="shape-3 bg-shape"></div>
    
    <!-- Floating Particles -->
    <div class="particle particle-1"></div>
    <div class="particle particle-2"></div>
    <div class="particle particle-3"></div>
    <div class="particle particle-4"></div>

    <!-- Main Container -->
    <div class="max-w-6xl w-full relative z-10">
        
        <!-- Welcome Header -->
        <div class="text-center mb-16">
            <div class="inline-block mb-4">
                <span class="bg-white/20 backdrop-blur-md text-white px-6 py-2 rounded-full text-sm font-semibold border border-white/30 shadow-lg">
                    <i class="fas fa-graduation-cap mr-2"></i>
                    Ghazali School System
                </span>
            </div>
            <h1 class="text-5xl md:text-6xl font-extrabold text-white mb-4 leading-tight">
                Welcome <span class="welcome-text">Back!</span>
            </h1>
            <p class="text-white/90 text-xl max-w-2xl mx-auto">
                Select your campus to access the dashboard and manage school activities
            </p>
            
            <!-- Stats Row -->
            <div class="flex justify-center gap-8 mt-8 text-white/80">
                <div class="flex items-center gap-2">
                    <i class="fas fa-user-graduate"></i>
                    <span>500+ Students</span>
                </div>
                <div class="flex items-center gap-2">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span>50+ Teachers</span>
                </div>
                <div class="flex items-center gap-2">
                    <i class="fas fa-school"></i>
                    <span>2 Campuses</span>
                </div>
            </div>
        </div>

        <!-- Campus Cards Grid -->
        <div class="grid md:grid-cols-2 gap-8 lg:gap-12">
            
            <!-- Girls Campus Card -->
            <a href="auth/girls-login.php" class="glass-card hover-scale p-8 md:p-10 rounded-3xl group relative">
                <!-- Campus Badge -->
                <div class="campus-badge badge-girls">
                    <i class="fas fa-venus mr-1"></i> Girls Wing
                </div>
                
                <!-- Icon Circle -->
                <div class="icon-circle w-28 h-28 bg-gradient-to-br from-pink-400 to-pink-600 text-white rounded-full flex items-center justify-center mx-auto mb-8 group-hover:rotate-12 transition-all duration-500 shadow-xl">
                    <i class="fa-solid fa-person-dress text-5xl group-hover:scale-110 transition-transform duration-300"></i>
                </div>
                
                <!-- Card Content -->
                <h2 class="text-3xl font-bold text-gray-800 mb-3 text-center">Girls Campus</h2>
                <p class="text-gray-600 mb-6 text-center">Empowering young women through quality education and character building</p>
                
                <!-- Features List -->
                <div class="space-y-3 mb-8">
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>24 Teachers & Staff</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>280+ Female Students</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>Science & Arts Programs</span>
                    </div>
                </div>
                
                <!-- Enter Button -->
                <div class="text-center">
                    <span class="inline-flex items-center gap-3 bg-gradient-to-r from-pink-500 to-pink-600 text-white font-semibold py-4 px-8 rounded-full group-hover:shadow-2xl transition-all duration-300">
                        <span>Enter Dashboard</span>
                        <i class="fa-solid fa-arrow-right group-hover:translate-x-2 transition-transform"></i>
                    </span>
                </div>
                
                <!-- Decorative Element -->
                <div class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-pink-300 to-pink-600 rounded-b-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </a>

            <!-- Boys Campus Card -->
            <a href="auth/boys-login.php" class="glass-card hover-scale p-8 md:p-10 rounded-3xl group relative">
                <!-- Campus Badge -->
                <div class="campus-badge badge-boys">
                    <i class="fas fa-mars mr-1"></i> Boys Wing
                </div>
                
                <!-- Icon Circle -->
                <div class="icon-circle w-28 h-28 bg-gradient-to-br from-blue-500 to-blue-700 text-white rounded-full flex items-center justify-center mx-auto mb-8 group-hover:rotate-12 transition-all duration-500 shadow-xl">
                    <i class="fa-solid fa-person text-5xl group-hover:scale-110 transition-transform duration-300"></i>
                </div>
                
                <!-- Card Content -->
                <h2 class="text-3xl font-bold text-gray-800 mb-3 text-center">Boys Campus</h2>
                <p class="text-gray-600 mb-6 text-center">Nurturing young minds to become future leaders and innovators</p>
                
                <!-- Features List -->
                <div class="space-y-3 mb-8">
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>26 Teachers & Staff</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>320+ Male Students</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-check-circle"></i>
                        <span>Sports & Technology Focus</span>
                    </div>
                </div>
                
                <!-- Enter Button -->
                <div class="text-center">
                    <span class="inline-flex items-center gap-3 bg-gradient-to-r from-blue-500 to-blue-700 text-white font-semibold py-4 px-8 rounded-full group-hover:shadow-2xl transition-all duration-300">
                        <span>Enter Dashboard</span>
                        <i class="fa-solid fa-arrow-right group-hover:translate-x-2 transition-transform"></i>
                    </span>
                </div>
                
                <!-- Decorative Element -->
                <div class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-blue-400 to-blue-700 rounded-b-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </a>

        </div>

        <!-- Quick Actions Footer -->
        <div class="mt-16 flex flex-wrap items-center justify-center gap-6">
            <!-- System Status -->
            <div class="bg-white/10 backdrop-blur-md rounded-full px-6 py-3 border border-white/20">
                <div class="flex items-center gap-3 text-white">
                    <span class="flex items-center gap-2">
                        <i class="fas fa-circle text-green-400 text-xs"></i>
                        <span class="text-sm">System Active</span>
                    </span>
                    <span class="w-px h-4 bg-white/30"></span>
                    <span class="flex items-center gap-2">
                        <i class="fas fa-clock text-yellow-300"></i>
                        <span class="text-sm"><?= date('h:i A') ?></span>
                    </span>
                </div>
            </div>
            
            <!-- Help & Support -->
            <a href="#" class="bg-white/10 backdrop-blur-md rounded-full px-6 py-3 border border-white/20 text-white hover:bg-white/20 transition-all flex items-center gap-2">
                <i class="fas fa-headset"></i>
                <span>Help & Support</span>
            </a>
            
            <!-- Logout Button -->
            <button onclick="window.location.href='auth/logout.php'" class="bg-red-500/90 backdrop-blur-md hover:bg-red-600 text-white rounded-full px-8 py-3 transition-all duration-300 flex items-center gap-3 shadow-lg hover:shadow-xl">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span class="font-semibold">Logout System</span>
            </button>
        </div>

        <!-- Footer Note -->
        <div class="text-center mt-8 text-white/60 text-sm">
            <p>© <?= date('Y') ?> Ghazali School System. All rights reserved.</p>
        </div>
    </div>

</body>
</html>