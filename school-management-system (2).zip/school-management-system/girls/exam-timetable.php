<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);

// Initialize filter parameter
$selected_class = isset($_GET['class_id']) ? intval($_GET['class_id']) : '';

// Fetch exams based on selected class
$exams = [];
$class_name = '';

if ($selected_class) {
    // Get class name
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$selected_class]);
    $class_name = $stmt->fetchColumn();

    // Fetch exams for selected class
    $stmt = $pdo->prepare("
        SELECT e.*, 
               TIME_FORMAT(e.start_time, '%h:%i %p') as start_time_formatted,
               TIME_FORMAT(e.end_time, '%h:%i %p') as end_time_formatted,
               DATE_FORMAT(e.exam_date, '%W, %D %M %Y') as formatted_date
        FROM exams e
        WHERE e.class_id = ?
        ORDER BY e.exam_date, e.start_time
    ");
    $stmt->execute([$selected_class]);
    $exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group exams by date
    $exams_by_date = [];
    foreach ($exams as $exam) {
        $exams_by_date[$exam['exam_date']][] = $exam;
    }
}

// Define time slots for morning to evening
$time_slots = [
    '08:00' => '8:00 AM',
    '08:30' => '8:30 AM',
    '09:00' => '9:00 AM',
    '09:30' => '9:30 AM',
    '10:00' => '10:00 AM',
    '10:30' => '10:30 AM',
    '11:00' => '11:00 AM',
    '11:30' => '11:30 AM',
    '12:00' => '12:00 PM',
    '12:30' => '12:30 PM',
    '13:00' => '1:00 PM',
    '13:30' => '1:30 PM',
    '14:00' => '2:00 PM',
    '14:30' => '2:30 PM',
    '15:00' => '3:00 PM',
    '15:30' => '3:30 PM',
    '16:00' => '4:00 PM',
    '16:30' => '4:30 PM',
    '17:00' => '5:00 PM'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Timetable - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .main-container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .filter-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            margin-bottom: 30px;
            backdrop-filter: blur(10px);
        }
        
        .timetable-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .date-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 15px 25px;
            border-radius: 15px;
            margin: 30px 0 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .date-header i {
            font-size: 24px;
            color: #ffd700;
        }
        
        .exam-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .exam-table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
            padding: 15px;
            text-align: left;
            font-size: 15px;
        }
        
        .exam-table td {
            padding: 15px;
            border: 1px solid #e0e0e0;
        }
        
        .exam-table tr:nth-child(even) {
            background: #f8fafc;
        }
        
        .time-slot {
            background: #f0f9ff;
            font-weight: 600;
            color: #1e3c72;
            width: 120px;
        }
        
        .subject-cell {
            font-weight: 600;
            color: #2d3748;
        }
        
        .print-btn {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            margin-top: 30px;
        }
        
        .print-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(30, 60, 114, 0.4);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(30, 60, 114, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: scale(1.05);
        }
        
        .school-header {
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border-radius: 15px;
        }
        
        .school-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .school-header p {
            font-size: 16px;
            opacity: 0.9;
        }
        
        .stats-badge {
            background: rgba(255,255,255,0.2);
            padding: 5px 15px;
            border-radius: 30px;
            font-size: 14px;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .timetable-card, .timetable-card * {
                visibility: visible;
            }
            .timetable-card {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
                background: white;
            }
            .no-print {
                display: none !important;
            }
            .school-header {
                background: #1e3c72;
                color: white;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .exam-table th {
                background: #667eea;
                color: white;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Header -->
        <div class="bg-white rounded-2xl shadow-2xl p-6 mb-8 flex justify-between items-center no-print">
            <div>
                <h1 class="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                    <i class="fas fa-calendar-alt mr-3 text-blue-800"></i>
                    Exam Timetable
                </h1>
                <p class="text-gray-600 mt-1">View and print exam schedules by class</p>
            </div>
            <a href="download.php" class="btn-secondary">
                <i class="fas fa-arrow-left"></i>
                Dashboard
            </a>
        </div>

        <!-- Filter Section -->
        <div class="filter-card no-print">
            <form method="GET" class="space-y-4">
                <div class="flex gap-4 items-end">
                    <div class="flex-1">
                        <label for="class_id" class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-school mr-2 text-blue-600"></i>
                            Select Class
                        </label>
                        <select name="class_id" id="class_id" 
                                class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                                required>
                            <option value="">-- Choose a class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $selected_class == $class['id'] ? 'selected' : '' ?>>
                                    Class <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn-primary px-8 py-3">
                        <i class="fas fa-search mr-2"></i>
                        View Timetable
                    </button>
                    <?php if ($selected_class): ?>
                        <a href="exam-timetable.php" class="bg-gray-500 hover:bg-gray-600 text-white px-8 py-3 rounded-full">
                            <i class="fas fa-times"></i>
                            Clear
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Exam Timetable Display -->
        <?php if ($selected_class): ?>
            <?php if (empty($exams)): ?>
                <div class="timetable-card text-center p-12">
                    <i class="fas fa-calendar-times text-6xl text-gray-400 mb-4"></i>
                    <h3 class="text-2xl font-bold text-gray-700 mb-2">No Exams Scheduled</h3>
                    <p class="text-gray-500">No exams found for Class <?= htmlspecialchars($class_name) ?></p>
                </div>
            <?php else: ?>
                <div class="timetable-card" id="timetable-content">
                    <!-- School Header (for print) -->
                    <div class="school-header">
                        <h1>Ghazali School</h1>
                        <p>Pully Ransikay Campus | 03043955545</p>
                        <h2 class="text-xl mt-2">Exam Timetable - Class <?= htmlspecialchars($class_name) ?></h2>
                    </div>

                    <!-- Timetable by Date -->
                    <?php foreach ($exams_by_date as $date => $date_exams): ?>
                        <div class="date-header">
                            <i class="fas fa-calendar-day"></i>
                            <div>
                                <h3 class="text-xl font-bold"><?= date('l, jS F Y', strtotime($date)) ?></h3>
                                <p class="text-sm opacity-90"><?= count($date_exams) ?> Exams Scheduled</p>
                            </div>
                        </div>

                        <table class="exam-table">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Exam Name</th>
                                    <th>Duration</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                // Sort exams by start time
                                usort($date_exams, function($a, $b) {
                                    return strtotime($a['start_time']) - strtotime($b['start_time']);
                                });
                                
                                foreach ($date_exams as $exam): 
                                    // Calculate duration
                                    $start = new DateTime($exam['start_time']);
                                    $end = new DateTime($exam['end_time']);
                                    $interval = $start->diff($end);
                                    $hours = $interval->h;
                                    $minutes = $interval->i;
                                    $duration = '';
                                    if ($hours > 0) $duration .= $hours . ' hour' . ($hours > 1 ? 's' : '');
                                    if ($minutes > 0) {
                                        if ($hours > 0) $duration .= ' ';
                                        $duration .= $minutes . ' min';
                                    }
                                ?>
                                    <tr>
                                        <td class="time-slot">
                                            <i class="far fa-clock mr-2"></i>
                                            <?= date('h:i A', strtotime($exam['start_time'])) ?> - 
                                            <?= date('h:i A', strtotime($exam['end_time'])) ?>
                                        </td>
                                        <td class="subject-cell">
                                            <i class="fas fa-book mr-2 text-blue-600"></i>
                                            <?= htmlspecialchars($exam['subject_name']) ?>
                                        </td>
                                        <td>
                                            <span class="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
                                                <?= htmlspecialchars($exam['exam_name']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                                                <i class="far fa-hourglass mr-1"></i>
                                                <?= $duration ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endforeach; ?>

                    <!-- Summary -->
                    <div class="mt-8 p-4 bg-gray-50 rounded-lg">
                        <div class="grid grid-cols-3 gap-4 text-center">
                            <div>
                                <div class="text-2xl font-bold text-blue-700"><?= count($exams) ?></div>
                                <div class="text-sm text-gray-600">Total Exams</div>
                            </div>
                            <div>
                                <div class="text-2xl font-bold text-green-700"><?= count($exams_by_date) ?></div>
                                <div class="text-sm text-gray-600">Exam Days</div>
                            </div>
                            <div>
                                <div class="text-2xl font-bold text-purple-700">Class <?= htmlspecialchars($class_name) ?></div>
                                <div class="text-sm text-gray-600">Current Class</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Print Button -->
                <div class="text-center no-print">
                    <button onclick="printTimetable()" class="print-btn">
                        <i class="fas fa-print fa-lg"></i>
                        Print Exam Timetable
                    </button>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Welcome Message -->
            <div class="timetable-card text-center p-16">
                <div class="w-24 h-24 bg-gradient-to-r from-blue-700 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-calendar-alt text-white text-4xl"></i>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-4">Exam Timetable Viewer</h3>
                <p class="text-gray-600 text-lg mb-8">Please select a class to view the exam schedule</p>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                    <div class="bg-blue-50 p-6 rounded-xl">
                        <i class="fas fa-school text-3xl text-blue-600 mb-3"></i>
                        <h4 class="font-bold text-lg">Select Class</h4>
                        <p class="text-sm text-gray-600">Choose from available classes</p>
                    </div>
                    <div class="bg-purple-50 p-6 rounded-xl">
                        <i class="fas fa-calendar-week text-3xl text-purple-600 mb-3"></i>
                        <h4 class="font-bold text-lg">View Schedule</h4>
                        <p class="text-sm text-gray-600">See all exams by date</p>
                    </div>
                    <div class="bg-green-50 p-6 rounded-xl">
                        <i class="fas fa-print text-3xl text-green-600 mb-3"></i>
                        <h4 class="font-bold text-lg">Print</h4>
                        <p class="text-sm text-gray-600">Print clean exam timetable</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Auto-submit form when class is selected
        document.getElementById('class_id').addEventListener('change', function() {
            if (this.value) {
                this.form.submit();
            }
        });

        // Print function
        function printTimetable() {
            const printContent = document.getElementById('timetable-content').innerHTML;
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Exam Timetable - Ghazali School</title>
                    <style>
                        * {
                            font-family: 'Poppins', sans-serif;
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        body {
                            padding: 30px;
                            background: white;
                        }
                        .school-header {
                            text-align: center;
                            margin-bottom: 30px;
                            padding: 20px;
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                            color: white;
                            border-radius: 15px;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .school-header h1 {
                            font-size: 32px;
                            font-weight: 700;
                            margin-bottom: 5px;
                        }
                        .date-header {
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                            color: white;
                            padding: 15px 25px;
                            border-radius: 15px;
                            margin: 30px 0 20px;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .exam-table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-bottom: 30px;
                            border-radius: 15px;
                            overflow: hidden;
                        }
                        .exam-table th {
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            color: white;
                            padding: 15px;
                            text-align: left;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .exam-table td {
                            padding: 15px;
                            border: 1px solid #e0e0e0;
                        }
                        .time-slot {
                            background: #f0f9ff;
                            font-weight: 600;
                        }
                        .bg-purple-100 { background: #f3e8ff; padding: 3px 10px; border-radius: 20px; }
                        .bg-green-100 { background: #dcfce7; padding: 3px 10px; border-radius: 20px; }
                        .summary {
                            margin-top: 30px;
                            padding: 20px;
                            background: #f9fafb;
                            border-radius: 15px;
                        }
                        .grid {
                            display: grid;
                            grid-template-columns: repeat(3, 1fr);
                            gap: 20px;
                            text-align: center;
                        }
                        @media print {
                            body { padding: 20px; }
                        }
                    </style>
                </head>
                <body>
                    ${printContent}
                </body>
                </html>
            `);
            
            printWindow.document.close();
            printWindow.focus();
            
            // Wait for content to load then print
            setTimeout(() => {
                printWindow.print();
            }, 500);
        }
    </script>
</body>
</html>