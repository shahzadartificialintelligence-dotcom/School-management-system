<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all teachers for dropdown
$teachers = $pdo->query("SELECT id, name FROM teachers ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Initialize filter parameters
$selected_class = isset($_GET['class_id']) ? intval($_GET['class_id']) : '';
$selected_teacher = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : '';

// Define days of week
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// Fetch timetable based on filters
$timetable_entries = [];
$filter_title = '';
$filter_subtitle = '';
$all_times = [];

if ($selected_class) {
    // Get class name
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$selected_class]);
    $class_name = $stmt->fetchColumn();
    $filter_title = "Class " . htmlspecialchars($class_name);
    $filter_subtitle = "Weekly Timetable";

    // Fetch timetable for selected class
    $stmt = $pdo->prepare("
        SELECT t.*, 
               tc.name as teacher_name,
               s.subject_name,
               TIME_FORMAT(t.start_time, '%H:%i') as start_time_formatted,
               TIME_FORMAT(t.end_time, '%H:%i') as end_time_formatted
        FROM timetable t
        LEFT JOIN teachers tc ON t.teacher_id = tc.id
        LEFT JOIN subjects s ON t.subject_id = s.id
        WHERE t.class_id = ?
        ORDER BY FIELD(t.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), t.start_time
    ");
    $stmt->execute([$selected_class]);
    $timetable_entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} elseif ($selected_teacher) {
    // Get teacher name
    $stmt = $pdo->prepare("SELECT name FROM teachers WHERE id = ?");
    $stmt->execute([$selected_teacher]);
    $teacher_name = $stmt->fetchColumn();
    $filter_title = htmlspecialchars($teacher_name);
    $filter_subtitle = "Teacher's Weekly Schedule";

    // Fetch timetable for selected teacher
    $stmt = $pdo->prepare("
        SELECT t.*, 
               c.class_name,
               s.subject_name,
               TIME_FORMAT(t.start_time, '%H:%i') as start_time_formatted,
               TIME_FORMAT(t.end_time, '%H:%i') as end_time_formatted
        FROM timetable t
        LEFT JOIN classes c ON t.class_id = c.id
        LEFT JOIN subjects s ON t.subject_id = s.id
        WHERE t.teacher_id = ?
        ORDER BY FIELD(t.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'), t.start_time
    ");
    $stmt->execute([$selected_teacher]);
    $timetable_entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get all unique times from the fetched entries
foreach ($timetable_entries as $entry) {
    $time_key = $entry['start_time_formatted'] . ' - ' . $entry['end_time_formatted'];
    if (!in_array($time_key, $all_times)) {
        $all_times[] = $time_key;
    }
}

// Sort times chronologically
usort($all_times, function($a, $b) {
    $time_a = substr($a, 0, 5);
    $time_b = substr($b, 0, 5);
    return strcmp($time_a, $time_b);
});

// Organize timetable by day and time
$timetable_matrix = [];
foreach ($days as $day) {
    $timetable_matrix[$day] = [];
    foreach ($all_times as $time) {
        $timetable_matrix[$day][$time] = null;
    }
}

// Fill the matrix with actual entries
foreach ($timetable_entries as $entry) {
    $time_key = $entry['start_time_formatted'] . ' - ' . $entry['end_time_formatted'];
    $timetable_matrix[$entry['day']][$time_key] = $entry;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timetable - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .main-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .filter-card {
            background: rgba(255,255,255,0.95);
            border-radius: 30px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            margin-bottom: 30px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255,255,255,0.5);
        }
        
        .timetable-card {
            background: white;
            border-radius: 30px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
            overflow-x: auto;
        }
        
        .filter-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 20px 30px;
            border-radius: 20px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .filter-header i {
            font-size: 30px;
            color: #ffd700;
        }
        
        .filter-header h2 {
            font-size: 24px;
            font-weight: 700;
            margin: 0;
        }
        
        .filter-header p {
            margin: 5px 0 0;
            opacity: 0.9;
            font-size: 14px;
        }
        
        .timetable-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .timetable-table th {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            font-weight: 600;
            padding: 15px;
            text-align: center;
            font-size: 16px;
            border-right: 1px solid rgba(255,255,255,0.2);
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .timetable-table th:last-child {
            border-right: none;
        }
        
        .timetable-table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #e0e0e0;
            vertical-align: middle;
            background: white;
            min-width: 180px;
        }
        
        .time-column {
            background: #f8fafc;
            font-weight: 600;
            color: #1e3c72;
            width: 120px;
            font-size: 14px;
            position: sticky;
            left: 0;
            z-index: 5;
        }
        
        .time-column span {
            background: #e9ecef;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 13px;
        }
        
        .subject-cell {
            background: #f0f9ff;
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .subject-cell:hover {
            transform: scale(1.02);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .subject-name {
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 5px;
            font-size: 16px;
        }
        
        .teacher-name {
            font-size: 13px;
            color: #4a5568;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            background: #e9ecef;
            padding: 3px 8px;
            border-radius: 20px;
            width: fit-content;
            margin: 5px auto 0;
        }
        
        .class-name {
            font-size: 13px;
            color: #4a5568;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            background: #e9ecef;
            padding: 3px 8px;
            border-radius: 20px;
            width: fit-content;
            margin: 5px auto 0;
        }
        
        .empty-cell {
            background: #f9f9f9;
            color: #999;
            font-style: italic;
            position: relative;
        }
        
        .empty-cell::after {
            content: '—';
            font-size: 18px;
            color: #ccc;
        }
        
        .day-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-primary:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(30, 60, 114, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: scale(1.05);
        }
        
        .filter-group {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        
        .filter-item {
            flex: 1;
            min-width: 250px;
        }
        
        .filter-item label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .filter-item select {
            width: 100%;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white;
        }
        
        .filter-item select:focus {
            border-color: #1e3c72;
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 60, 114, 0.2);
        }
        
        .print-btn {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        }
        
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 25px;
            border-radius: 15px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .time-slots-count {
            background: rgba(255,255,255,0.2);
            padding: 5px 15px;
            border-radius: 30px;
            font-size: 14px;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .timetable-card, .timetable-card * {
                visibility: visible;
            }
            .timetable-card {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                box-shadow: none;
                padding: 20px;
            }
            .no-print {
                display: none !important;
            }
            .time-column {
                background: #f8fafc;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Header -->
        <div class="bg-white rounded-3xl shadow-2xl p-8 mb-8 flex justify-between items-center no-print">
            <div>
                <h1 class="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                    <i class="fas fa-calendar-alt mr-3 text-blue-800"></i>
                    Timetable Management
                </h1>
                <p class="text-gray-600 mt-2 text-lg">View flexible timetables with any time slots</p>
            </div>
            <a href="download.php" class="btn-secondary">
                <i class="fas fa-arrow-left"></i>
                Dashboard
            </a>
        </div>

        <!-- Filter Section -->
        <div class="filter-card no-print">
            <form method="GET" class="space-y-6">
                <div class="filter-group">
                    <div class="filter-item">
                        <label>
                            <i class="fas fa-school mr-2 text-blue-700"></i>
                            Filter by Class
                        </label>
                        <select name="class_id" id="class_filter">
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $selected_class == $class['id'] ? 'selected' : '' ?>>
                                    Class <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-item">
                        <label>
                            <i class="fas fa-chalkboard-teacher mr-2 text-purple-700"></i>
                            Filter by Teacher
                        </label>
                        <select name="teacher_id" id="teacher_filter">
                            <option value="">-- Select Teacher --</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?= $teacher['id'] ?>" <?= $selected_teacher == $teacher['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($teacher['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-item">
                        <button type="submit" class="btn-primary w-full justify-center">
                            <i class="fas fa-search"></i>
                            View Timetable
                        </button>
                    </div>
                    
                    <?php if ($selected_class || $selected_teacher): ?>
                        <div class="filter-item">
                            <a href="timetable.php" class="btn-secondary w-full justify-center">
                                <i class="fas fa-times"></i>
                                Clear Filter
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Timetable Display -->
        <?php if ($selected_class || $selected_teacher): ?>
            <?php if (empty($timetable_entries)): ?>
                <div class="timetable-card text-center p-12">
                    <i class="fas fa-calendar-times text-6xl text-gray-400 mb-4"></i>
                    <h3 class="text-2xl font-bold text-gray-700 mb-2">No Timetable Found</h3>
                    <p class="text-gray-500">No timetable entries available for the selected filter.</p>
                </div>
            <?php else: ?>
                <div class="timetable-card">
                    <!-- Filter Header -->
                    <div class="filter-header">
                        <i class="fas fa-<?= $selected_class ? 'school' : 'chalkboard-teacher' ?>"></i>
                        <div>
                            <h2><?= $filter_title ?></h2>
                            <p><?= $filter_subtitle ?></p>
                        </div>
                        <div class="time-slots-count">
                            <i class="fas fa-clock mr-1"></i>
                            <?= count($all_times) ?> Time Slots
                        </div>
                    </div>

                    <!-- Stats Card -->
                    <div class="stats-card no-print">
                        <span>
                            <i class="fas fa-calendar-week mr-2"></i>
                            Showing schedule for <?= count(array_filter($timetable_matrix)) ?> days
                        </span>
                        <span>
                            <i class="fas fa-clock mr-2"></i>
                            Flexible time slots: <?= implode(', ', $all_times) ?>
                        </span>
                    </div>

                    <!-- Timetable Table -->
                    <table class="timetable-table">
                        <thead>
                            <tr>
                                <th>Time Slot</th>
                                <?php foreach ($days as $day): ?>
                                    <?php if (array_filter($timetable_matrix[$day])): ?>
                                        <th>
                                            <?= $day ?>
                                            <span class="day-badge bg-white/20">
                                                <?= count(array_filter($timetable_matrix[$day])) ?> classes
                                            </span>
                                        </th>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_times as $time_slot): ?>
                                <tr>
                                    <td class="time-column">
                                        <span><?= $time_slot ?></span>
                                    </td>
                                    
                                    <?php foreach ($days as $day): ?>
                                        <?php if (array_filter($timetable_matrix[$day])): ?>
                                            <td class="<?= isset($timetable_matrix[$day][$time_slot]) ? 'subject-cell' : 'empty-cell' ?>">
                                                <?php if (isset($timetable_matrix[$day][$time_slot])): 
                                                    $entry = $timetable_matrix[$day][$time_slot];
                                                ?>
                                                    <div class="subject-name"><?= htmlspecialchars($entry['subject_name']) ?></div>
                                                    
                                                    <?php if ($selected_class): ?>
                                                        <div class="teacher-name">
                                                            <i class="fas fa-chalkboard-teacher"></i>
                                                            <?= htmlspecialchars($entry['teacher_name']) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <?php if ($selected_teacher): ?>
                                                        <div class="class-name">
                                                            <i class="fas fa-school"></i>
                                                            Class <?= htmlspecialchars($entry['class_name']) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Print Button -->
                    <div class="text-center mt-8 no-print">
                        <button onclick="window.print()" class="btn-primary print-btn">
                            <i class="fas fa-print"></i>
                            Print Timetable
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Welcome Message -->
            <div class="timetable-card text-center p-16">
                <div class="w-32 h-32 bg-gradient-to-r from-blue-700 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-8">
                    <i class="fas fa-calendar-alt text-white text-5xl"></i>
                </div>
                <h3 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Timetable Viewer</h3>
                <p class="text-gray-600 text-xl mb-10 max-w-2xl mx-auto">Select a class or teacher to view their complete schedule with flexible time slots</p>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
                    <div class="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-2xl">
                        <div class="w-20 h-20 bg-blue-700 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-school text-white text-3xl"></i>
                        </div>
                        <h4 class="font-bold text-2xl mb-3">By Class</h4>
                        <p class="text-gray-600">View complete weekly schedule for any class with any time slots like 8:30, 9:15, 10:45</p>
                    </div>
                    <div class="bg-gradient-to-br from-purple-50 to-pink-50 p-8 rounded-2xl">
                        <div class="w-20 h-20 bg-purple-700 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-chalkboard-teacher text-white text-3xl"></i>
                        </div>
                        <h4 class="font-bold text-2xl mb-3">By Teacher</h4>
                        <p class="text-gray-600">View complete teaching schedule for any teacher across all classes with flexible timing</p>
                    </div>
                </div>
                
                <div class="mt-8 bg-yellow-50 p-4 rounded-xl inline-block">
                    <i class="fas fa-clock text-yellow-600 mr-2"></i>
                    <span class="text-yellow-800">Supports any time format: 8:30, 8:45, 9:15, 10:00, 11:30 etc.</span>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Auto-submit form when class or teacher is selected
        document.getElementById('class_filter').addEventListener('change', function() {
            if (this.value) {
                document.getElementById('teacher_filter').value = '';
                this.form.submit();
            }
        });
        
        document.getElementById('teacher_filter').addEventListener('change', function() {
            if (this.value) {
                document.getElementById('class_filter').value = '';
                this.form.submit();
            }
        });
        
        // Print function
        function printTimetable() {
            window.print();
        }
    </script>
</body>
</html>