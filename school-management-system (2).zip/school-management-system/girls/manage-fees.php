<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// AJAX endpoint for fetching students by class
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_students') {
    header('Content-Type: application/json');
    $class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    
    if ($class_id > 0) {
        $stmt = $pdo->prepare("SELECT id, student_name, roll_no FROM students WHERE class_id = ? ORDER BY student_name");
        $stmt->execute([$class_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($students);
    } else {
        echo json_encode([]);
    }
    exit();
}

// AJAX endpoint for getting student details (including std_id and total_fees)
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_student_details') {
    header('Content-Type: application/json');
    $student_id = isset($_GET['student_id']) ? intval($_GET['student_id']) : 0;
    
    if ($student_id > 0) {
        $stmt = $pdo->prepare("SELECT s.*, c.class_name FROM students s LEFT JOIN classes c ON s.class_id = c.id WHERE s.id = ?");
        $stmt->execute([$student_id]);
        $student = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode($student);
    } else {
        echo json_encode([]);
    }
    exit();
}

// Initialize filter parameters
$filter_class = isset($_GET['class_id']) ? intval($_GET['class_id']) : '';
$filter_search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Handle fee submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_fee'])) {
    $student_id = $_POST['student_id'];
    $std_id = $_POST['std_id']; // Get std_id from students table
    $student_name = $_POST['student_name'];
    $class_name = $_POST['class_name'];
    $roll_no = $_POST['roll_no'];
    $total_amount = floatval($_POST['total_amount']);
    $paid_amount = !empty($_POST['paid_amount']) ? floatval($_POST['paid_amount']) : 0;
    $due_date = $_POST['due_date'];
    $remarks = trim($_POST['remarks'] ?? '');
    
    // Calculate remaining amount and status
    $remaining_amount = $total_amount - $paid_amount;
    
    if ($paid_amount >= $total_amount) {
        $status = 'Paid';
        $remaining_amount = 0;
    } elseif ($paid_amount > 0) {
        $status = 'Partially Paid';
    } else {
        $status = 'Pending';
    }
    
    // Insert into fees table with std_id
    $stmt = $pdo->prepare("
        INSERT INTO fees (student_id, std_id, student_name, class_name, roll_no, total_amount, paid_amount, remaining_amount, due_date, status, remarks, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    if ($stmt->execute([$student_id, $std_id, $student_name, $class_name, $roll_no, $total_amount, $paid_amount, $remaining_amount, $due_date, $status, $remarks])) {
        $_SESSION['success'] = "Fee record added successfully! Status: " . $status;
    } else {
        $_SESSION['error'] = "Error adding fee record.";
    }
    
    header("Location: manage-fees.php" . ($filter_class ? "?class_id=$filter_class" : ""));
    exit();
}

// Handle payment update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payment'])) {
    $fee_id = $_POST['fee_id'];
    $additional_payment = floatval($_POST['additional_payment']);
    
    // Get current fee record
    $stmt = $pdo->prepare("SELECT * FROM fees WHERE id = ?");
    $stmt->execute([$fee_id]);
    $fee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($fee) {
        $new_paid = $fee['paid_amount'] + $additional_payment;
        $new_remaining = $fee['total_amount'] - $new_paid;
        
        if ($new_paid >= $fee['total_amount']) {
            $new_status = 'Paid';
            $new_remaining = 0;
        } else {
            $new_status = 'Partially Paid';
        }
        
        $update = $pdo->prepare("UPDATE fees SET paid_amount = ?, remaining_amount = ?, status = ? WHERE id = ?");
        $update->execute([$new_paid, $new_remaining, $new_status, $fee_id]);
        
        $_SESSION['success'] = "Payment updated successfully! New status: " . $new_status;
    }
    
    header("Location: manage-fees.php" . ($filter_class ? "?class_id=$filter_class" : ""));
    exit();
}

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_fee'])) {
    $fee_id = $_POST['fee_id'];
    
    $stmt = $pdo->prepare("DELETE FROM fees WHERE id = ?");
    $stmt->execute([$fee_id]);
    
    $_SESSION['success'] = "Fee record deleted successfully!";
    header("Location: manage-fees.php" . ($filter_class ? "?class_id=$filter_class" : ""));
    exit();
}

// Fetch filtered fee records
$query = "SELECT f.* FROM fees f WHERE 1=1";
$params = [];

if ($filter_class) {
    $query .= " AND f.class_name = (SELECT class_name FROM classes WHERE id = ?)";
    $params[] = $filter_class;
}

if ($filter_search) {
    $query .= " AND (f.student_name LIKE ? OR f.roll_no LIKE ?)";
    $search_term = "%$filter_search%";
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY f.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$fee_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate summary statistics
$total_fees = 0;
$total_paid = 0;
$total_remaining = 0;
$paid_count = 0;
$partial_count = 0;
$pending_count = 0;

foreach ($fee_records as $record) {
    $total_fees += $record['total_amount'];
    $total_paid += $record['paid_amount'];
    $total_remaining += $record['remaining_amount'];
    
    if ($record['status'] == 'Paid') $paid_count++;
    elseif ($record['status'] == 'Partially Paid') $partial_count++;
    elseif ($record['status'] == 'Pending') $pending_count++;
}

// Get session messages
$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Management - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body { 
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .status-paid {
            background: #c6f6d5;
            color: #22543d;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-partial {
            background: #feebc8;
            color: #744210;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-pending {
            background: #fed7d7;
            color: #742a2a;
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .filter-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }
        
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        
        .stats-card.green {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
        }
        
        .stats-card.orange {
            background: linear-gradient(135deg, #f6ad55 0%, #dd6b20 100%);
        }
        
        .stats-card.blue {
            background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
        }
        
        .fee-info {
            background: #f0f9ff;
            border-left: 4px solid #3b82f6;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .print-btn {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 30px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .print-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(30, 60, 114, 0.3);
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<div class="container">
    <!-- Header -->
    <div class="bg-white rounded-2xl shadow-2xl p-6 mb-8 flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                <i class="fas fa-money-bill-wave mr-3 text-green-600"></i>
                Fee Management System
            </h1>
            <p class="text-gray-600 mt-1">Track and manage student fees with partial payments</p>
        </div>
        <a href="girls_dashboard.php" class="bg-gray-700 hover:bg-gray-800 text-white font-bold py-3 px-6 rounded-full transition-all duration-300">
            <i class="fas fa-arrow-left mr-2"></i>Dashboard
        </a>
    </div>

    <!-- Messages -->
    <?php if (!empty($success)): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg shadow flex justify-between items-center">
            <span><i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success); ?></span>
            <button onclick="this.parentElement.remove()" class="text-green-700">&times;</button>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($error)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg shadow flex justify-between items-center">
            <span><i class="fas fa-exclamation-circle mr-2"></i><?= htmlspecialchars($error); ?></span>
            <button onclick="this.parentElement.remove()" class="text-red-700">&times;</button>
        </div>
    <?php endif; ?>

    <!-- Fee Entry Form -->
    <div class="filter-card">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <i class="fas fa-plus-circle text-green-600 mr-3"></i>
            Add New Fee Record
        </h2>
        
        <form method="POST" id="feeForm" class="space-y-6">
            <input type="hidden" name="add_fee" value="1">
            <input type="hidden" name="student_id" id="student_id">
            <input type="hidden" name="std_id" id="std_id"> <!-- New field for std_id -->
            <input type="hidden" name="student_name" id="student_name">
            <input type="hidden" name="class_name" id="class_name">
            <input type="hidden" name="roll_no" id="roll_no">
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Class Selection -->
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-school mr-2 text-blue-600"></i>
                        Select Class *
                    </label>
                    <select id="class_select" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500" required>
                        <option value="">-- Choose Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= $class['id'] ?>">Class <?= htmlspecialchars($class['class_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Student Selection -->
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-user-graduate mr-2 text-blue-600"></i>
                        Select Student *
                    </label>
                    <select name="student_select" id="student_select" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500" required disabled>
                        <option value="">First select a class</option>
                    </select>
                    <div id="student-loading" class="text-sm text-gray-500 mt-1 hidden">
                        <i class="fas fa-spinner fa-spin mr-2"></i>Loading students...
                    </div>
                </div>
                
                <!-- Student ID Display (for reference) -->
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-id-card mr-2 text-purple-600"></i>
                        Student ID
                    </label>
                    <div id="student_id_display" class="w-full border-2 border-gray-300 rounded-xl p-3 bg-gray-50">
                        Not selected
                    </div>
                </div>
            </div>
            
            <!-- Auto-loaded Fee Information -->
            <div id="fee_info_section" class="fee-info hidden">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-sm text-gray-600">Registered Fee from Students Table:</p>
                        <p class="text-2xl font-bold text-blue-600" id="registered_fee">0.00</p>
                    </div>
                    <div>
                        <span class="text-sm text-gray-600">Student ID:</span>
                        <span class="font-mono font-bold text-purple-600" id="display_std_id">---</span>
                    </div>
                </div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Total Amount (pre-filled from students table) -->
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-rupee-sign mr-2 text-green-600"></i>
                        Total Fee Amount *
                    </label>
                    <input type="number" name="total_amount" id="total_amount" step="0.01" min="0" 
                           class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 bg-yellow-50 font-bold" 
                           readonly required>
                    <p class="text-xs text-gray-500 mt-1">Auto-loaded from student record</p>
                </div>
                
                <!-- Paid Amount -->
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-hand-holding-usd mr-2 text-yellow-600"></i>
                        Paying Amount
                    </label>
                    <input type="number" name="paid_amount" id="paid_amount" step="0.01" min="0" value="0"
                           class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
                    <p class="text-xs text-gray-500 mt-1">Leave 0 for pending payment</p>
                </div>
                
                <!-- Due Date -->
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-calendar-alt mr-2 text-red-600"></i>
                        Due Date *
                    </label>
                    <input type="date" name="due_date" id="due_date" 
                           class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500" 
                           min="<?= date('Y-m-d') ?>" required>
                </div>
            </div>
            
            <!-- Status Preview -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-info-circle mr-2 text-blue-600"></i>
                        Payment Status
                    </label>
                    <div id="status_preview" class="w-full border-2 border-gray-300 rounded-xl p-3 bg-gray-50">
                        <span class="status-pending">Pending</span>
                    </div>
                </div>
                
                <!-- Remaining Amount Display -->
                <div id="remaining_display" class="hidden">
                    <label class="block font-semibold mb-2 text-gray-700">
                        <i class="fas fa-clock mr-2 text-orange-600"></i>
                        Remaining Amount
                    </label>
                    <div class="w-full border-2 border-orange-300 rounded-xl p-3 bg-orange-50">
                        <span class="text-xl font-bold text-orange-700" id="remaining_amount">0.00</span>
                    </div>
                </div>
            </div>
            
            <!-- Remarks -->
            <div>
                <label class="block font-semibold mb-2 text-gray-700">
                    <i class="fas fa-comment mr-2 text-gray-600"></i>
                    Remarks (Optional)
                </label>
                <textarea name="remarks" rows="2" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500" placeholder="Any notes about this fee..."></textarea>
            </div>
            
            <div class="flex justify-end">
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-10 rounded-full transition-all transform hover:scale-105 shadow-lg text-lg">
                    <i class="fas fa-save mr-2"></i>
                    Save Fee Record
                </button>
            </div>
        </form>
    </div>

    <!-- Filters and Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="stats-card">
            <div class="text-3xl font-bold"><?= count($fee_records) ?></div>
            <div class="text-sm opacity-90">Total Records</div>
        </div>
        <div class="stats-card green">
            <div class="text-3xl font-bold">Rs. <?= number_format($total_paid, 2) ?></div>
            <div class="text-sm opacity-90">Total Collected</div>
        </div>
        <div class="stats-card orange">
            <div class="text-3xl font-bold">Rs. <?= number_format($total_remaining, 2) ?></div>
            <div class="text-sm opacity-90">Total Remaining</div>
        </div>
        <div class="stats-card blue">
            <div class="text-3xl font-bold">Rs. <?= number_format($total_fees, 2) ?></div>
            <div class="text-sm opacity-90">Total Fees</div>
        </div>
    </div>

    <!-- Status Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-green-50 p-4 rounded-lg text-center border border-green-200">
            <div class="text-2xl font-bold text-green-700"><?= $paid_count ?></div>
            <div class="text-sm text-gray-600">Paid</div>
        </div>
        <div class="bg-yellow-50 p-4 rounded-lg text-center border border-yellow-200">
            <div class="text-2xl font-bold text-yellow-700"><?= $partial_count ?></div>
            <div class="text-sm text-gray-600">Partially Paid</div>
        </div>
        <div class="bg-red-50 p-4 rounded-lg text-center border border-red-200">
            <div class="text-2xl font-bold text-red-700"><?= $pending_count ?></div>
            <div class="text-sm text-gray-600">Pending</div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-card">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <label class="block font-semibold mb-2 text-gray-700">
                    <i class="fas fa-filter mr-2 text-blue-600"></i>
                    Filter by Class
                </label>
                <select name="class_id" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?= $class['id'] ?>" <?= $filter_class == $class['id'] ? 'selected' : '' ?>>
                            Class <?= htmlspecialchars($class['class_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div>
                <label class="block font-semibold mb-2 text-gray-700">
                    <i class="fas fa-search mr-2 text-blue-600"></i>
                    Search by Name or Roll No
                </label>
                <input type="text" name="search" value="<?= htmlspecialchars($filter_search) ?>" 
                       placeholder="Type to search..." 
                       class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
            </div>
            
            <div class="flex items-end gap-3">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl transition-all">
                    <i class="fas fa-search mr-2"></i>Apply Filters
                </button>
                <a href="manage-fees.php" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-xl transition-all">
                    <i class="fas fa-times"></i> Clear
                </a>
            </div>
        </form>
    </div>

    <!-- Fee Records Table -->
    <div class="bg-white rounded-2xl shadow-xl p-6">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800 flex items-center">
                <i class="fas fa-list-alt mr-3 text-blue-600"></i>
                Fee Records
            </h2>
            <span class="bg-blue-100 text-blue-800 text-sm font-semibold px-4 py-2 rounded-full">
                Total: <?= count($fee_records) ?>
            </span>
        </div>
        
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white rounded-lg border border-gray-200">
                <thead class="bg-gradient-to-r from-blue-700 to-purple-700 text-white">
                    <tr>
                        <th class="py-4 px-4 text-left font-semibold">Student ID</th>
                        <th class="py-4 px-4 text-left font-semibold">Student Name</th>
                        <th class="py-4 px-4 text-left font-semibold">Class</th>
                        <th class="py-4 px-4 text-left font-semibold">Roll No</th>
                        <th class="py-4 px-4 text-left font-semibold">Total Fee</th>
                        <th class="py-4 px-4 text-left font-semibold">Paid</th>
                        <th class="py-4 px-4 text-left font-semibold">Remaining</th>
                        <th class="py-4 px-4 text-left font-semibold">Due Date</th>
                        <th class="py-4 px-4 text-left font-semibold">Status</th>
                        <th class="py-4 px-4 text-left font-semibold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if ($fee_records): ?>
                        <?php foreach ($fee_records as $row): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-4 text-sm font-mono"><?= htmlspecialchars($row['std_id']); ?></td>
                                <td class="py-4 px-4 text-sm font-medium"><?= htmlspecialchars($row['student_name']); ?></td>
                                <td class="py-4 px-4 text-sm">Class <?= htmlspecialchars($row['class_name']); ?></td>
                                <td class="py-4 px-4 text-sm"><?= htmlspecialchars($row['roll_no']); ?></td>
                                <td class="py-4 px-4 text-sm font-semibold">Rs. <?= number_format($row['total_amount'], 2); ?></td>
                                <td class="py-4 px-4 text-sm text-green-600 font-semibold">Rs. <?= number_format($row['paid_amount'], 2); ?></td>
                                <td class="py-4 px-4 text-sm text-red-600 font-semibold">Rs. <?= number_format($row['remaining_amount'], 2); ?></td>
                                <td class="py-4 px-4 text-sm">
                                    <i class="far fa-calendar-alt mr-1 text-gray-500"></i>
                                    <?= date('d M Y', strtotime($row['due_date'])); ?>
                                </td>
                                <td class="py-4 px-4 text-sm">
                                    <span class="<?php 
                                        echo $row['status'] == 'Paid' ? 'status-paid' : 
                                            ($row['status'] == 'Partially Paid' ? 'status-partial' : 'status-pending'); 
                                    ?>">
                                        <?= $row['status']; ?>
                                    </span>
                                </td>
                                <td class="py-4 px-4 text-sm">
                                    <div class="flex gap-2">
                                       <a href="fees-slip.php?id=<?= $row['id'] ?>" target="_blank" 
                                        class="print-btn" title="Print Fee Slip">
                                       <i class="fas fa-print"></i>
                                         </a>
                                        <?php if ($row['status'] != 'Paid'): ?>
                                            <button onclick="showPaymentModal(<?= $row['id'] ?>, '<?= $row['student_name'] ?>', <?= $row['remaining_amount'] ?>)" 
                                                    class="bg-green-500 text-white px-3 py-1 rounded-full hover:bg-green-600 text-xs font-semibold">
                                                <i class="fas fa-plus-circle mr-1"></i>Pay
                                            </button>
                                        <?php endif; ?>
                                        <form method="POST" class="inline" onsubmit="return confirm('Delete this fee record?')">
                                            <input type="hidden" name="fee_id" value="<?= $row['id']; ?>">
                                            <button type="submit" name="delete_fee" class="bg-red-500 text-white px-3 py-1 rounded-full hover:bg-red-600 text-xs font-semibold">
                                                <i class="fas fa-trash mr-1"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="text-center py-12 text-gray-500">
                                <i class="fas fa-money-bill-wave text-5xl mb-3 text-gray-300"></i>
                                <p>No fee records found</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="paymentModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-lg bg-white">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-bold text-gray-900">Add Payment</h3>
            <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form method="POST" id="paymentForm">
            <input type="hidden" name="update_payment" value="1">
            <input type="hidden" name="fee_id" id="modal_fee_id">
            
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Student</label>
                <p id="modal_student_name" class="bg-gray-50 p-3 rounded-lg"></p>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Remaining Amount</label>
                <p id="modal_remaining" class="bg-gray-50 p-3 rounded-lg font-bold text-red-600"></p>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm font-semibold mb-2">Payment Amount</label>
                <input type="number" name="additional_payment" id="payment_amount" step="0.01" min="0.01" 
                       class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500" required>
            </div>
            
            <div class="flex gap-3">
                <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 flex-1">
                    Submit Payment
                </button>
                <button type="button" onclick="closeModal()" class="bg-gray-500 text-white px-6 py-3 rounded-lg hover:bg-gray-600">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    // Load students when class is selected
    $('#class_select').change(function() {
        var classId = $(this).val();
        
        if (classId) {
            $('#student_select').prop('disabled', true);
            $('#student-loading').removeClass('hidden');
            
            $.ajax({
                url: window.location.href,
                type: 'GET',
                dataType: 'json',
                data: {
                    ajax: 'get_students',
                    class_id: classId
                },
                success: function(students) {
                    var options = '<option value="">Select Student</option>';
                    
                    if (students.length > 0) {
                        $.each(students, function(index, student) {
                            options += '<option value="' + student.id + '" data-roll="' + student.roll_no + '">' + student.student_name + ' (Roll: ' + student.roll_no + ')</option>';
                        });
                        $('#student_select').prop('disabled', false);
                    } else {
                        options = '<option value="">No students found in this class</option>';
                    }
                    
                    $('#student_select').html(options);
                    $('#student-loading').addClass('hidden');
                },
                error: function() {
                    $('#student_select').html('<option value="">Error loading students</option>');
                    $('#student-loading').addClass('hidden');
                }
            });
        } else {
            $('#student_select').prop('disabled', true);
            $('#student_select').html('<option value="">First select a class</option>');
        }
    });
    
    // Load student details when student is selected
    $('#student_select').change(function() {
        var studentId = $(this).val();
        var selectedOption = $(this).find('option:selected');
        var rollNo = selectedOption.data('roll');
        
        if (studentId) {
            $.ajax({
                url: window.location.href,
                type: 'GET',
                dataType: 'json',
                data: {
                    ajax: 'get_student_details',
                    student_id: studentId
                },
                success: function(student) {
                    $('#student_id').val(student.id);
                    $('#std_id').val(student.std_id); // Set std_id
                    $('#student_name').val(student.student_name);
                    $('#class_name').val(student.class_name);
                    $('#roll_no').val(student.roll_no);
                    $('#total_amount').val(student.total_fees); // Auto-load total fees
                    
                    // Update displays
                    $('#student_id_display').text(student.std_id);
                    $('#registered_fee').text(Number(student.total_fees).toFixed(2));
                    $('#display_std_id').text(student.std_id);
                    $('#fee_info_section').removeClass('hidden');
                    
                    // Trigger status update
                    updateStatusPreview();
                }
            });
        }
    });
    
    // Calculate status based on paid amount
    function updateStatusPreview() {
        var total = parseFloat($('#total_amount').val()) || 0;
        var paid = parseFloat($('#paid_amount').val()) || 0;
        var remaining = total - paid;
        
        if (remaining < 0) {
            $('#paid_amount').val(total);
            paid = total;
            remaining = 0;
        }
        
        if (paid >= total && total > 0) {
            $('#status_preview').html('<span class="status-paid">Paid</span>');
            $('#remaining_display').addClass('hidden');
        } else if (paid > 0) {
            $('#status_preview').html('<span class="status-partial">Partially Paid</span>');
            $('#remaining_amount').text(remaining.toFixed(2));
            $('#remaining_display').removeClass('hidden');
        } else {
            $('#status_preview').html('<span class="status-pending">Pending</span>');
            $('#remaining_amount').text(total.toFixed(2));
            $('#remaining_display').removeClass('hidden');
        }
    }
    
    $('#paid_amount').on('input', updateStatusPreview);
    
    // Set default due date to today
    $('#due_date').val(new Date().toISOString().split('T')[0]);
});

function showPaymentModal(feeId, studentName, remaining) {
    $('#modal_fee_id').val(feeId);
    $('#modal_student_name').text(studentName);
    $('#modal_remaining').text('Rs. ' + remaining.toFixed(2));
    $('#paymentModal').removeClass('hidden');
}

function closeModal() {
    $('#paymentModal').addClass('hidden');
    $('#paymentForm')[0].reset();
}

function printFeeSlip(feeId) {
    // This will be implemented later for printing fee slips
    window.open('print-fee.php?id=' + feeId, '_blank');
}

// Auto-hide messages after 5 seconds
setTimeout(function() {
    $('.bg-green-100, .bg-red-100').fadeOut(500, function() {
        $(this).remove();
    });
}, 5000);
</script>
</body>
</html>