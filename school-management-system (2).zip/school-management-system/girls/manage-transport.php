<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// Handle Add Transport Route
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_route'])) {
    $vehicle_no = trim($_POST['vehicle_no']);
    $driver_name = trim($_POST['driver_name']);
    $driver_phone = trim($_POST['driver_phone']);
    $start_point = trim($_POST['start_point']);
    $end_point = trim($_POST['end_point']);
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $route_days = isset($_POST['route_days']) ? implode(',', $_POST['route_days']) : '';
    $capacity = intval($_POST['capacity']);
    $status = $_POST['status'];

    // Validate time
    if (strtotime($start_time) >= strtotime($end_time)) {
        $_SESSION['error'] = "End time must be after start time!";
    } else {
        $stmt = $pdo->prepare("INSERT INTO transport_routes 
            (vehicle_no, driver_name, driver_phone, start_point, end_point, start_time, end_time, route_days, capacity, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        if ($stmt->execute([$vehicle_no, $driver_name, $driver_phone, $start_point, $end_point, $start_time, $end_time, $route_days, $capacity, $status])) {
            $_SESSION['success'] = "Transport route added successfully!";
        } else {
            $_SESSION['error'] = "Error adding transport route.";
        }
    }
    header("Location: manage-transport.php");
    exit();
}

// Handle Edit Route
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_route'])) {
    $id = intval($_POST['id']);
    $vehicle_no = trim($_POST['vehicle_no']);
    $driver_name = trim($_POST['driver_name']);
    $driver_phone = trim($_POST['driver_phone']);
    $start_point = trim($_POST['start_point']);
    $end_point = trim($_POST['end_point']);
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $route_days = isset($_POST['route_days']) ? implode(',', $_POST['route_days']) : '';
    $capacity = intval($_POST['capacity']);
    $status = $_POST['status'];

    // Validate time
    if (strtotime($start_time) >= strtotime($end_time)) {
        $_SESSION['error'] = "End time must be after start time!";
    } else {
        $stmt = $pdo->prepare("UPDATE transport_routes SET 
            vehicle_no = ?, driver_name = ?, driver_phone = ?, start_point = ?, end_point = ?, 
            start_time = ?, end_time = ?, route_days = ?, capacity = ?, status = ? 
            WHERE id = ?");
        
        if ($stmt->execute([$vehicle_no, $driver_name, $driver_phone, $start_point, $end_point, $start_time, $end_time, $route_days, $capacity, $status, $id])) {
            $_SESSION['success'] = "Transport route updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating transport route.";
        }
    }
    header("Location: manage-transport.php");
    exit();
}

// Handle Delete Route
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM transport_routes WHERE id = ?");
    if ($stmt->execute([$id])) {
        $_SESSION['success'] = "Transport route deleted successfully!";
    } else {
        $_SESSION['error'] = "Error deleting transport route.";
    }
    header("Location: manage-transport.php");
    exit();
}

// Fetch edit data
$edit_route = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM transport_routes WHERE id = ?");
    $stmt->execute([$id]);
    $edit_route = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch all routes
$stmt = $pdo->query("SELECT * FROM transport_routes ORDER BY start_time");
$routes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get session messages
$success_message = $_SESSION['success'] ?? '';
$error_message = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

// Days of week for checkbox
$week_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transport Management - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .main-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .form-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }
        
        .table-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
            overflow-x: auto;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-active {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .status-inactive {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .route-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
        }
        
        .time-badge {
            background: rgba(255,255,255,0.2);
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 13px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(30, 60, 114, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: scale(1.05);
        }
        
        .day-checkbox {
            display: inline-flex;
            align-items: center;
            margin-right: 15px;
            margin-bottom: 10px;
        }
        
        .day-checkbox input {
            margin-right: 5px;
        }
        
        .route-marker {
            width: 12px;
            height: 12px;
            background: #48bb78;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Header -->
        <div class="bg-white rounded-2xl shadow-2xl p-6 mb-8 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                    <i class="fas fa-bus mr-3 text-blue-800"></i>
                    Transport Management
                </h1>
                <p class="text-gray-600 mt-1">Manage vehicles, routes, and schedules</p>
            </div>
            <a href="girls_dashboard.php" class="btn-secondary">
                <i class="fas fa-arrow-left"></i>
                Dashboard
            </a>
        </div>

        <!-- Success/Error Messages -->
        <?php if ($success_message): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg shadow flex justify-between items-center">
                <span><i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success_message) ?></span>
                <button onclick="this.parentElement.remove()" class="text-green-700">&times;</button>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg shadow flex justify-between items-center">
                <span><i class="fas fa-exclamation-circle mr-2"></i><?= htmlspecialchars($error_message) ?></span>
                <button onclick="this.parentElement.remove()" class="text-red-700">&times;</button>
            </div>
        <?php endif; ?>

        <!-- Add/Edit Route Form -->
        <div class="form-card">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-<?= $edit_route ? 'edit' : 'plus-circle' ?> mr-3 text-<?= $edit_route ? 'blue' : 'green' ?>-600"></i>
                <?= $edit_route ? 'Edit Transport Route' : 'Add New Transport Route' ?>
            </h2>
            
            <form method="POST" action="manage-transport.php" class="space-y-6">
                <?php if ($edit_route): ?>
                    <input type="hidden" name="id" value="<?= $edit_route['id'] ?>">
                <?php endif; ?>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Vehicle Number -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-truck mr-2 text-blue-600"></i>
                            Vehicle Number *
                        </label>
                        <input type="text" name="vehicle_no" 
                               value="<?= $edit_route ? htmlspecialchars($edit_route['vehicle_no']) : '' ?>"
                               placeholder="e.g., LEA-1234" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>

                    <!-- Driver Name -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-user mr-2 text-blue-600"></i>
                            Driver Name *
                        </label>
                        <input type="text" name="driver_name" 
                               value="<?= $edit_route ? htmlspecialchars($edit_route['driver_name']) : '' ?>"
                               placeholder="Driver full name" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>

                    <!-- Driver Phone -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-phone mr-2 text-blue-600"></i>
                            Driver Phone *
                        </label>
                        <input type="text" name="driver_phone" 
                               value="<?= $edit_route ? htmlspecialchars($edit_route['driver_phone']) : '' ?>"
                               placeholder="e.g., 03001234567" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Start Point -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-map-marker-alt mr-2 text-green-600"></i>
                            Start Point *
                        </label>
                        <input type="text" name="start_point" 
                               value="<?= $edit_route ? htmlspecialchars($edit_route['start_point']) : '' ?>"
                               placeholder="e.g., Main City Terminal" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>

                    <!-- End Point -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-map-marker-alt mr-2 text-red-600"></i>
                            End Point *
                        </label>
                        <input type="text" name="end_point" 
                               value="<?= $edit_route ? htmlspecialchars($edit_route['end_point']) : '' ?>"
                               placeholder="e.g., School Campus" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Start Time -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-clock mr-2 text-green-600"></i>
                            Start Time *
                        </label>
                        <input type="time" name="start_time" 
                               value="<?= $edit_route ? date('H:i', strtotime($edit_route['start_time'])) : '' ?>"
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>

                    <!-- End Time -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-clock mr-2 text-red-600"></i>
                            End Time *
                        </label>
                        <input type="time" name="end_time" 
                               value="<?= $edit_route ? date('H:i', strtotime($edit_route['end_time'])) : '' ?>"
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                               required>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Route Days -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            <i class="fas fa-calendar-week mr-2 text-blue-600"></i>
                            Operating Days *
                        </label>
                        <div class="border-2 border-gray-300 rounded-xl p-4">
                            <?php 
                            $selected_days = $edit_route ? explode(',', $edit_route['route_days']) : ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                            foreach ($week_days as $day): 
                            ?>
                                <label class="day-checkbox">
                                    <input type="checkbox" name="route_days[]" value="<?= $day ?>" 
                                           <?= in_array($day, $selected_days) ? 'checked' : '' ?>>
                                    <?= $day ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Capacity & Status -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="fas fa-users mr-2 text-blue-600"></i>
                                Capacity *
                            </label>
                            <input type="number" name="capacity" 
                                   value="<?= $edit_route ? $edit_route['capacity'] : '40' ?>"
                                   min="1" max="100"
                                   class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500"
                                   required>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                <i class="fas fa-toggle-on mr-2 text-blue-600"></i>
                                Status
                            </label>
                            <select name="status" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
                                <option value="Active" <?= ($edit_route && $edit_route['status'] == 'Active') ? 'selected' : '' ?>>Active</option>
                                <option value="Inactive" <?= ($edit_route && $edit_route['status'] == 'Inactive') ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="flex gap-4">
                    <button type="submit" name="<?= $edit_route ? 'edit_route' : 'add_route' ?>" 
                            class="btn-primary px-8 py-3">
                        <i class="fas fa-<?= $edit_route ? 'save' : 'plus' ?> mr-2"></i>
                        <?= $edit_route ? 'Update Route' : 'Add Route' ?>
                    </button>
                    <?php if ($edit_route): ?>
                        <a href="manage-transport.php" class="bg-gray-500 hover:bg-gray-600 text-white px-8 py-3 rounded-full">
                            <i class="fas fa-times mr-2"></i>
                            Cancel
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Routes List -->
        <div class="table-card">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-list-alt mr-3 text-blue-600"></i>
                Transport Routes
                <span class="ml-4 bg-blue-100 text-blue-800 text-sm font-semibold px-4 py-2 rounded-full">
                    Total: <?= count($routes) ?>
                </span>
            </h2>

            <?php if (count($routes) > 0): ?>
                <div class="grid grid-cols-1 gap-4">
                    <?php foreach ($routes as $route): 
                        $days = explode(',', $route['route_days']);
                    ?>
                        <div class="bg-white border-2 border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                            <div class="flex flex-wrap justify-between items-start gap-4">
                                <!-- Vehicle Info -->
                                <div class="flex-1">
                                    <div class="flex items-center gap-3 mb-3">
                                        <div class="bg-blue-100 p-3 rounded-lg">
                                            <i class="fas fa-bus text-blue-600 text-xl"></i>
                                        </div>
                                        <div>
                                            <h3 class="text-xl font-bold text-gray-800"><?= htmlspecialchars($route['vehicle_no']) ?></h3>
                                            <p class="text-sm text-gray-500">
                                                <i class="fas fa-user mr-1"></i> <?= htmlspecialchars($route['driver_name']) ?>
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <!-- Route Points -->
                                    <div class="space-y-2">
                                        <div class="flex items-center gap-2">
                                            <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                                            <span class="text-sm text-gray-600">From: <span class="font-semibold"><?= htmlspecialchars($route['start_point']) ?></span></span>
                                        </div>
                                        <div class="flex items-center gap-2">
                                            <span class="w-2 h-2 bg-red-500 rounded-full"></span>
                                            <span class="text-sm text-gray-600">To: <span class="font-semibold"><?= htmlspecialchars($route['end_point']) ?></span></span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Time Info -->
                                <div class="flex-1">
                                    <div class="bg-gray-50 p-4 rounded-lg">
                                        <div class="flex items-center gap-4 mb-3">
                                            <div class="flex items-center gap-2">
                                                <i class="fas fa-clock text-green-600"></i>
                                                <span class="text-sm font-semibold">Start:</span>
                                                <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                                                    <?= date('h:i A', strtotime($route['start_time'])) ?>
                                                </span>
                                            </div>
                                            <div class="flex items-center gap-2">
                                                <i class="fas fa-clock text-red-600"></i>
                                                <span class="text-sm font-semibold">End:</span>
                                                <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm">
                                                    <?= date('h:i A', strtotime($route['end_time'])) ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <!-- Operating Days -->
                                        <div class="mt-3">
                                            <p class="text-sm font-semibold mb-2">Operating Days:</p>
                                            <div class="flex flex-wrap gap-2">
                                                <?php foreach ($days as $day): ?>
                                                    <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs">
                                                        <?= $day ?>
                                                    </span>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Additional Info -->
                                <div class="w-48">
                                    <div class="space-y-3">
                                        <div class="flex items-center justify-between">
                                            <span class="text-sm text-gray-600">
                                                <i class="fas fa-phone mr-1"></i> Driver:
                                            </span>
                                            <span class="font-semibold"><?= htmlspecialchars($route['driver_phone']) ?></span>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <span class="text-sm text-gray-600">
                                                <i class="fas fa-users mr-1"></i> Capacity:
                                            </span>
                                            <span class="font-semibold"><?= $route['capacity'] ?> seats</span>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <span class="text-sm text-gray-600">Status:</span>
                                            <span class="status-badge <?= $route['status'] == 'Active' ? 'status-active' : 'status-inactive' ?>">
                                                <?= $route['status'] ?>
                                            </span>
                                        </div>
                                    </div>
                                    
                                    <!-- Actions -->
                                    <div class="flex gap-2 mt-4">
                                        <a href="?edit=<?= $route['id'] ?>" 
                                           class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-full text-sm transition-colors">
                                            <i class="fas fa-edit mr-1"></i> Edit
                                        </a>
                                        <a href="?delete=<?= $route['id'] ?>" 
                                           onclick="return confirm('Are you sure you want to delete this route?')"
                                           class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full text-sm transition-colors">
                                            <i class="fas fa-trash mr-1"></i> Delete
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-bus text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500 text-lg">No transport routes added yet.</p>
                    <p class="text-gray-400">Use the form above to add your first route.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Auto-hide messages after 5 seconds
        setTimeout(function() {
            $('.bg-green-100, .bg-red-100').fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    </script>
</body>
</html>