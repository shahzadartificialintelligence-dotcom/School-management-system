<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// Get fee record ID from URL
$fee_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$fee_id) {
    die("Invalid fee record ID");
}

// Fetch fee record with student details
$stmt = $pdo->prepare("
    SELECT f.*, s.parent_name, s.address, s.phone 
    FROM fees f 
    LEFT JOIN students s ON f.student_id = s.id 
    WHERE f.id = ?
");
$stmt->execute([$fee_id]);
$fee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$fee) {
    die("Fee record not found");
}

// Calculate remaining amount
$remaining = $fee['total_amount'] - $fee['paid_amount'];
$status = $fee['status'];

// Format dates
$issue_date = date('d-M-Y', strtotime($fee['created_at']));
$due_date = date('d-M-Y', strtotime($fee['due_date']));
$month_year = date('F, Y', strtotime($fee['due_date']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Slip - <?= htmlspecialchars($fee['student_name']) ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            background: #f0f2f5;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .fee-slip {
            width: 800px;
            background: white;
            border: 2px solid #000;
            padding: 20px;
            margin: 20px auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
        }
        
        .school-name {
            font-size: 28px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #000;
        }
        
        .campus {
            font-size: 16px;
            font-weight: 600;
            margin-top: 5px;
            color: #333;
        }
        
        .phone {
            font-size: 14px;
            margin-top: 5px;
            color: #555;
        }
        
        .title-section {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
            padding: 10px 0;
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
        }
        
        .copy-type {
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
        }
        
        .comp-no {
            font-size: 16px;
            font-weight: 600;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #000;
            background: #f9f9f9;
        }
        
        .info-item {
            display: flex;
            align-items: center;
        }
        
        .info-label {
            font-weight: 700;
            min-width: 100px;
            color: #333;
        }
        
        .info-value {
            font-weight: 600;
            color: #000;
            border-bottom: 1px dotted #999;
            padding-bottom: 3px;
        }
        
        .student-id-box {
            background: #e3f2fd;
            border: 2px solid #1976d2;
            padding: 10px 15px;
            margin: 15px 0;
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 18px;
        }
        
        .student-id-label {
            font-weight: 700;
            color: #1976d2;
        }
        
        .student-id-value {
            font-family: 'Courier New', monospace;
            font-weight: 800;
            font-size: 22px;
            color: #0d47a1;
        }
        
        .fee-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .fee-table th {
            background: #000;
            color: white;
            padding: 12px;
            text-align: left;
            font-size: 16px;
        }
        
        .fee-table td {
            padding: 12px;
            border: 1px solid #999;
        }
        
        .fee-table .amount {
            text-align: right;
            font-weight: 700;
        }
        
        .total-row {
            background: #f0f0f0;
            font-weight: 700;
        }
        
        .payment-status {
            margin: 20px 0;
            padding: 15px;
            border: 2px solid #000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .status-badge {
            padding: 8px 20px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 16px;
        }
        
        .status-paid {
            background: #4caf50;
            color: white;
        }
        
        .status-partial {
            background: #ff9800;
            color: white;
        }
        
        .status-pending {
            background: #f44336;
            color: white;
        }
        
        .footer {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #666;
            border-top: 1px dashed #000;
            padding-top: 15px;
        }
        
        .signature {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature-line {
            width: 200px;
            border-top: 1px solid #000;
            margin-top: 5px;
        }
        
        .print-btn {
            background: #2196F3;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 30px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin: 20px auto;
            display: block;
            transition: all 0.3s ease;
        }
        
        .print-btn:hover {
            background: #1976D2;
            transform: scale(1.05);
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .fee-slip {
                box-shadow: none;
                border: 2px solid #000;
                margin: 0;
            }
            
            .print-btn {
                display: none;
            }
            
            .no-print {
                display: none;
            }
        }
        
        .office-copy, .student-copy {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        
        .duplicate-watermark {
            position: relative;
        }
        
        .duplicate-watermark::before {
            content: "DUPLICATE";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-size: 60px;
            color: rgba(255, 0, 0, 0.1);
            font-weight: 800;
            pointer-events: none;
            z-index: 1;
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" class="print-btn">
            <i class="fas fa-print"></i> Print Fee Slip
        </button>
        <a href="manage-fees.php" style="background: #6c757d; color: white; text-decoration: none; padding: 12px 30px; border-radius: 30px; margin-left: 10px;">Back to Fees</a>
    </div>

    <!-- Student Copy -->
    <div class="fee-slip student-copy">
        <div class="header">
            <div class="school-name">GHAZALI MODEL HIGH SCHOOL</div>
            <div class="campus">Boys Campus</div>
            <div class="phone">Ph: 0346533623</div>
        </div>
        
        <div style="text-align: center; font-size: 20px; font-weight: 700; margin: 10px 0; text-transform: uppercase;">
            Student Copy
        </div>
        
        <div class="student-id-box">
            <span class="student-id-label">Student ID:</span>
            <span class="student-id-value"><?= htmlspecialchars($fee['std_id']) ?></span>
        </div>
        
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Student's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['student_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Father's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['parent_name'] ?? 'N/A') ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Class:</span>
                <span class="info-value"><?= htmlspecialchars($fee['class_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Roll No:</span>
                <span class="info-value"><?= htmlspecialchars($fee['roll_no']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Comp No:</span>
                <span class="info-value"><?= str_pad($fee['id'], 3, '0', STR_PAD_LEFT) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Month:</span>
                <span class="info-value"><?= $month_year ?></span>
            </div>
        </div>
        
        <div style="display: flex; justify-content: flex-end; margin-bottom: 15px;">
            <div style="background: #ffeb3b; padding: 8px 15px; font-weight: 700; border: 1px solid #000;">
                Due Date: <?= $due_date ?>
            </div>
        </div>
        
        <table class="fee-table">
            <thead>
                <tr>
                    <th>Particulars</th>
                    <th style="width: 150px; text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Monthly Fee - <?= $month_year ?></td>
                    <td class="amount">Rs. <?= number_format($fee['total_amount'], 2) ?></td>
                </tr>
                <?php if ($fee['paid_amount'] > 0): ?>
                <tr>
                    <td>Paid Amount</td>
                    <td class="amount" style="color: #4caf50;">- Rs. <?= number_format($fee['paid_amount'], 2) ?></td>
                </tr>
                <?php endif; ?>
                <tr class="total-row">
                    <td><strong>Remaining Amount</strong></td>
                    <td class="amount"><strong>Rs. <?= number_format($remaining, 2) ?></strong></td>
                </tr>
            </tbody>
        </table>
        
        <div class="payment-status">
            <span style="font-weight: 700;">Payment Status:</span>
            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $status)) ?>">
                <?= $status ?>
            </span>
        </div>
        
        <div class="footer">
            <span>Generated on: <?= date('d-M-Y h:i A') ?></span>
            <span>This is a computer generated slip</span>
        </div>
        
        <div class="signature">
            <div>
                <div>Student's Signature</div>
                <div class="signature-line"></div>
            </div>
            <div>
                <div>Authorized Signature</div>
                <div class="signature-line"></div>
            </div>
        </div>
    </div>

    <!-- Office Copy (Duplicate) -->
    <div class="fee-slip office-copy duplicate-watermark" style="margin-top: 30px;">
        <div class="header">
            <div class="school-name">GHAZALI MODEL HIGH SCHOOL</div>
            <div class="campus">Boys Campus</div>
            <div class="phone">Ph: 0346533623</div>
        </div>
        
        <div style="text-align: center; font-size: 20px; font-weight: 700; margin: 10px 0; text-transform: uppercase; color: #d32f2f;">
            Office Copy
        </div>
        
        <div class="student-id-box">
            <span class="student-id-label">Student ID:</span>
            <span class="student-id-value"><?= htmlspecialchars($fee['std_id']) ?></span>
        </div>
        
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Student's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['student_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Father's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['parent_name'] ?? 'N/A') ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Class:</span>
                <span class="info-value"><?= htmlspecialchars($fee['class_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Roll No:</span>
                <span class="info-value"><?= htmlspecialchars($fee['roll_no']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Comp No:</span>
                <span class="info-value"><?= str_pad($fee['id'], 3, '0', STR_PAD_LEFT) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Month:</span>
                <span class="info-value"><?= $month_year ?></span>
            </div>
        </div>
        
        <div style="display: flex; justify-content: flex-end; margin-bottom: 15px;">
            <div style="background: #ffeb3b; padding: 8px 15px; font-weight: 700; border: 1px solid #000;">
                Due Date: <?= $due_date ?>
            </div>
        </div>
        
        <table class="fee-table">
            <thead>
                <tr>
                    <th>Particulars</th>
                    <th style="width: 150px; text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Monthly Fee - <?= $month_year ?></td>
                    <td class="amount">Rs. <?= number_format($fee['total_amount'], 2) ?></td>
                </tr>
                <?php if ($fee['paid_amount'] > 0): ?>
                <tr>
                    <td>Paid Amount</td>
                    <td class="amount" style="color: #4caf50;">- Rs. <?= number_format($fee['paid_amount'], 2) ?></td>
                </tr>
                <?php endif; ?>
                <tr class="total-row">
                    <td><strong>Remaining Amount</strong></td>
                    <td class="amount"><strong>Rs. <?= number_format($remaining, 2) ?></strong></td>
                </tr>
            </tbody>
        </table>
        
        <div class="payment-status">
            <span style="font-weight: 700;">Payment Status:</span>
            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $status)) ?>">
                <?= $status ?>
            </span>
        </div>
        
        <div style="margin-top: 20px; padding: 10px; background: #f0f0f0; border: 1px dashed #000;">
            <p><strong>Office Use Only:</strong></p>
            <p>Received by: ____________________ Date: _____________</p>
        </div>
        
        <div class="footer">
            <span>Generated on: <?= date('d-M-Y h:i A') ?></span>
            <span>Comp #: <?= str_pad($fee['id'], 3, '0', STR_PAD_LEFT) ?></span>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</body>
</html>