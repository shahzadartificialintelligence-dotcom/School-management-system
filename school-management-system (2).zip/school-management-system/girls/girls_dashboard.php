<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check


// Get admin's full name from users table
$admin_full_name = $_SESSION['full_name'] ?? 'Admin';

// If full_name is not in session, fetch from database
if (!isset($_SESSION['full_name']) && isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT full_name FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && !empty($user['full_name'])) {
            $admin_full_name = $user['full_name'];
            $_SESSION['full_name'] = $admin_full_name;
        }
    } catch (Exception $e) {
        // Silently fail and keep default
    }
}

// Get first name for a more personalized greeting
$first_name = explode(' ', $admin_full_name)[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - School Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .dashboard-card {
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
        }
        
        .dashboard-card:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            background: white;
        }
        
        .greeting-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 1.1rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .date-time {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(5px);
            padding: 8px 20px;
            border-radius: 50px;
            color: white;
            font-size: 0.95rem;
        }
    </style>
</head>
<body class="bg-gray-100">

    <header class="bg-white shadow-lg p-6">
        <div class="max-w-7xl mx-auto">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                <div class="flex items-center gap-4">
                    <div class="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                        <i class="fas fa-user-shield text-white text-3xl"></i>
                    </div>
                    <div>
                        <h1 class="text-3xl font-extrabold text-gray-800">
                            Welcome back, <?= htmlspecialchars($first_name) ?>! 👋
                        </h1>
                        <p class="text-gray-600 mt-1">
                            <i class="fas fa-user-circle mr-2 text-blue-500"></i>
                            <?= htmlspecialchars($admin_full_name) ?> (Administrator)
                        </p>
                    </div>
                </div>
                <div class="flex space-x-4">
                    <a href="../index.php" class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-6 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
                        <i class="fas fa-home mr-2"></i>Home
                    </a>
                    <a href="../auth/logout.php" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-6 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
                <div class="bg-blue-50 rounded-lg p-4 flex items-center gap-4">
                    <div class="bg-blue-600 w-12 h-12 rounded-full flex items-center justify-center">
                        <i class="fas fa-users text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Total Students</p>
                        <p class="text-2xl font-bold text-gray-800"><?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM students");
                            echo $stmt->fetchColumn();
                        ?></p>
                    </div>
                </div>
                <div class="bg-purple-50 rounded-lg p-4 flex items-center gap-4">
                    <div class="bg-purple-600 w-12 h-12 rounded-full flex items-center justify-center">
                        <i class="fas fa-chalkboard-teacher text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Total Teachers</p>
                        <p class="text-2xl font-bold text-gray-800"><?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM teachers");
                            echo $stmt->fetchColumn();
                        ?></p>
                    </div>
                </div>
                <div class="bg-green-50 rounded-lg p-4 flex items-center gap-4">
                    <div class="bg-green-600 w-12 h-12 rounded-full flex items-center justify-center">
                        <i class="fas fa-school text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Total Classes</p>
                        <p class="text-2xl font-bold text-gray-800"><?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM classes");
                            echo $stmt->fetchColumn();
                        ?></p>
                    </div>
                </div>
                <div class="bg-yellow-50 rounded-lg p-4 flex items-center gap-4">
                    <div class="bg-yellow-600 w-12 h-12 rounded-full flex items-center justify-center">
                        <i class="fas fa-users-cog text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Total Users</p>
                        <p class="text-2xl font-bold text-gray-800"><?php
                            $stmt = $pdo->query("SELECT COUNT(*) FROM users");
                            echo $stmt->fetchColumn();
                        ?></p>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto p-8">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-2xl font-bold text-gray-800">
                <i class="fas fa-th-large mr-3 text-blue-600"></i>
                Dashboard Menu
            </h2>
            <div class="date-time bg-white shadow-md px-6 py-2 rounded-full">
                <i class="far fa-calendar-alt mr-2 text-blue-600"></i>
                <?= date('l, F j, Y') ?>
            </div>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <!-- Manage Users -->
            <a href="manage-users.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-indigo-600 mb-4">
                    <i class="fas fa-users text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Users</h3>
                <p class="text-sm text-gray-500 mt-2">Add, edit, or remove users</p>
            </a>
            
            <!-- Manage Students -->
            <a href="manage-students.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-purple-600 mb-4">
                    <i class="fas fa-user-graduate text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Students</h3>
                <p class="text-sm text-gray-500 mt-2">Student records and enrollment</p>
            </a>
            
            <!-- Manage Teachers -->
            <a href="manage-teachers.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-blue-500 mb-4">
                    <i class="fas fa-chalkboard-teacher text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Teachers</h3>
                <p class="text-sm text-gray-500 mt-2">Teacher profiles and assignments</p>
            </a>
            
            <!-- Manage Classes -->
            <a href="manage-classes.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-green-500 mb-4">
                    <i class="fas fa-school text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Classes</h3>
                <p class="text-sm text-gray-500 mt-2">Class sections and divisions</p>
            </a>
            
            <!-- Manage Subjects -->
            <a href="manage-subjects.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-orange-500 mb-4">
                    <i class="fas fa-book text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Subjects</h3>
                <p class="text-sm text-gray-500 mt-2">Subject management</p>
            </a>
            

            <!-- Manage Exams -->
            <a href="manage-exams.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-red-500 mb-4">
                    <i class="fas fa-pen-to-square text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Exams</h3>
                <p class="text-sm text-gray-500 mt-2">Exam schedules and results</p>
            </a>
            
            <!-- Manage Timetable -->
            <a href="manage-timetable.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-sky-500 mb-4">
                    <i class="fas fa-calendar-days text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Timetable</h3>
                <p class="text-sm text-gray-500 mt-2">Class schedules</p>
            </a>
            
            <!-- Manage Fees -->
            <a href="manage-fees.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <div class="text-fuchsia-500 mb-4">
                    <i class="fas fa-money-bill-wave text-5xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-800">Manage Fees</h3>
                <p class="text-sm text-gray-500 mt-2">Fee collection and records</p>
            </a>
    
<a href="manage-transport.php" class="bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
    <div class="text-orange-600 mb-4">
        <i class="fas fa-bus text-5xl"></i>
    </div>
    <h3 class="text-xl font-semibold text-gray-800">Transport Management</h3>
    <p class="text-sm text-gray-500 mt-2">Manage vehicles & routes</p>
    <span class="inline-block mt-3 bg-orange-100 text-orange-800 text-xs px-3 py-1 rounded-full">
        <i class="fas fa-route mr-1"></i> Routes
    </span>
</a>
        <a href="download.php" class="dashboard-card bg-white rounded-xl shadow-lg p-6 text-center transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
    <div class="text-indigo-600 mb-4">
        <i class="fas fa-download text-5xl"></i>
    </div>
    <h3 class="text-xl font-semibold text-gray-800">Download Center</h3>
    <p class="text-sm text-gray-500 mt-2">Reports & Documents</p>
</a>
        </div>

        <!-- Recent Activities Section -->
        <div class="mt-12 bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-history mr-3 text-blue-600"></i>
                Recent Activities
            </h3>
            <div class="space-y-3">
                <?php
                try {
                    $stmt = $pdo->query("SELECT * FROM activities ORDER BY created_at DESC LIMIT 5");
                    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if ($activities) {
                        foreach ($activities as $activity) {
                            echo '<div class="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">';
                            echo '<div class="w-2 h-2 bg-green-500 rounded-full"></div>';
                            echo '<div class="flex-1">';
                            echo '<p class="text-gray-800">' . htmlspecialchars($activity['description']) . '</p>';
                            echo '<p class="text-xs text-gray-500">' . date('M d, Y h:i A', strtotime($activity['created_at'])) . '</p>';
                            echo '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p class="text-gray-500 text-center py-4">No recent activities</p>';
                    }
                } catch (Exception $e) {
                    // Activities table might not exist - ignore
                }
                ?>
            </div>
        </div>
    </main>

    <script>
        // Update time every minute
        setInterval(function() {
            const now = new Date();
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            document.querySelector('.date-time').innerHTML = '<i class="far fa-calendar-alt mr-2 text-blue-600"></i>' + 
                now.toLocaleDateString('en-US', options);
        }, 60000);
    </script>
</body>
</html>