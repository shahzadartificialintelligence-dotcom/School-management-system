<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);

// AJAX endpoint for fetching subjects based on class
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_subjects') {
    header('Content-Type: application/json');
    $class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    
    if ($class_id > 0) {
        $stmt = $pdo->prepare("SELECT id, subject_name FROM subjects WHERE class_id = ? ORDER BY subject_name");
        $stmt->execute([$class_id]);
        $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($subjects);
    } else {
        echo json_encode([]);
    }
    exit();
}

// Add new exam
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_exam'])) {
    $exam_name = trim($_POST['exam_name']);
    $class_id = intval($_POST['class_id']);
    $subject_id = intval($_POST['subject_id']);
    $exam_date = $_POST['exam_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // Validate time format - ensure it's in proper format for database
    if (!preg_match('/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/', $start_time)) {
        $_SESSION['error'] = "Invalid start time format. Please use format like 08:30 or 14:30";
        header("Location: manage-exams.php");
        exit();
    }
    
    if (!preg_match('/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/', $end_time)) {
        $_SESSION['error'] = "Invalid end time format. Please use format like 10:30 or 16:00";
        header("Location: manage-exams.php");
        exit();
    }

    // Convert to 24-hour format with leading zeros for database storage
    $start_time_db = date('H:i:s', strtotime($start_time));
    $end_time_db = date('H:i:s', strtotime($end_time));

    // Get class name
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    $class_name = $stmt->fetchColumn();

    // Get subject name
    $stmt = $pdo->prepare("SELECT subject_name FROM subjects WHERE id = ?");
    $stmt->execute([$subject_id]);
    $subject_name = $stmt->fetchColumn();

    if (!empty($exam_name) && !empty($class_id) && !empty($subject_id) && !empty($exam_date) && !empty($start_time_db) && !empty($end_time_db)) {
        
        // Validate that end time is after start time
        if (strtotime($start_time_db) >= strtotime($end_time_db)) {
            $_SESSION['error'] = "End time must be after start time!";
        } else {
            // Check if exam already exists at this time for this class/subject
            $check_stmt = $pdo->prepare("SELECT id FROM exams WHERE class_id = ? AND exam_date = ? AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))");
            $check_stmt->execute([$class_id, $exam_date, $start_time_db, $start_time_db, $end_time_db, $end_time_db]);
            
            if ($check_stmt->rowCount() > 0) {
                $_SESSION['error'] = "An exam is already scheduled at this time for this class!";
            } else {
                $stmt = $pdo->prepare("INSERT INTO exams (exam_name, class_id, class_name, subject_id, subject_name, exam_date, start_time, end_time) VALUES (:exam_name, :class_id, :class_name, :subject_id, :subject_name, :exam_date, :start_time, :end_time)");
                
                if (!$stmt->execute([
                    'exam_name' => $exam_name,
                    'class_id' => $class_id,
                    'class_name' => $class_name,
                    'subject_id' => $subject_id,
                    'subject_name' => $subject_name,
                    'exam_date' => $exam_date,
                    'start_time' => $start_time_db,
                    'end_time' => $end_time_db
                ])) {
                    $_SESSION['error'] = "Error adding exam.";
                } else {
                    $_SESSION['success'] = "Exam added successfully!";
                }
            }
        }
        header("Location: manage-exams.php");
        exit();
    } else {
        $_SESSION['error'] = "Please fill in all required fields.";
        header("Location: manage-exams.php");
        exit();
    }
}

// Delete exam
if (isset($_GET['delete'])) {
    $exam_id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = :id");
    $stmt->execute(['id' => $exam_id]);
    $_SESSION['success'] = "Exam deleted successfully!";
    header("Location: manage-exams.php");
    exit();
}

// Fetch exams with proper formatting
$stmt = $pdo->query("SELECT * FROM exams ORDER BY exam_date DESC, start_time");
$exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get session messages
$success_message = $_SESSION['success'] ?? '';
$error_message = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Exams - Ghazali School</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Inter Font -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
    </style>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- jQuery for AJAX -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="p-8">

    <!-- Header Section -->
    <header class="bg-white rounded-2xl shadow-2xl p-6 mb-8 flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                <i class="fas fa-pen-to-square mr-3 text-blue-800"></i>
                Exam Management
            </h1>
            <p class="text-gray-600 mt-1">Schedule and manage exams with proper time slots</p>
        </div>
        <a href="girls_dashboard.php" class="bg-gray-700 hover:bg-gray-800 text-white font-bold py-3 px-6 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
            <i class="fas fa-arrow-left mr-2"></i>
            Dashboard
        </a>
    </header>

    <main class="max-w-6xl mx-auto">
        <!-- Success/Error Messages -->
        <?php if ($success_message): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg shadow flex justify-between items-center">
                <span><i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success_message) ?></span>
                <button onclick="this.parentElement.remove()" class="text-green-700">&times;</button>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg shadow flex justify-between items-center">
                <span><i class="fas fa-exclamation-circle mr-2"></i><?= htmlspecialchars($error_message) ?></span>
                <button onclick="this.parentElement.remove()" class="text-red-700">&times;</button>
            </div>
        <?php endif; ?>

        <!-- Add Exam Form Section -->
        <div class="bg-white rounded-3xl shadow-2xl p-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-plus-circle text-green-600 mr-3"></i>
                Schedule New Exam
            </h2>
            
            <form method="POST" action="manage-exams.php" class="space-y-6" id="examForm">
                <input type="hidden" name="add_exam" value="1">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Exam Name -->
                    <div>
                        <label for="exam_name" class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-file-signature mr-2 text-blue-600"></i>
                            Exam Name
                        </label>
                        <input type="text" name="exam_name" id="exam_name" 
                               placeholder="e.g., Mid-Term Examination" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200"
                               required>
                    </div>

                    <!-- Class Dropdown -->
                    <div>
                        <label for="class_id" class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-school mr-2 text-blue-600"></i>
                            Select Class
                        </label>
                        <select name="class_id" id="class_id" 
                                class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200"
                                required>
                            <option value="">-- Choose a class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>">
                                    Class <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Subject Dropdown (Dynamic) -->
                    <div>
                        <label for="subject_id" class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-book mr-2 text-blue-600"></i>
                            Select Subject
                        </label>
                        <select name="subject_id" id="subject_id" 
                                class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200"
                                required disabled>
                            <option value="">First select a class</option>
                        </select>
                        <div id="subject-loading" class="text-sm text-gray-500 mt-1 hidden">
                            <i class="fas fa-spinner fa-spin mr-2"></i>Loading subjects...
                        </div>
                    </div>

                    <!-- Exam Date -->
                    <div>
                        <label for="exam_date" class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-calendar-alt mr-2 text-blue-600"></i>
                            Exam Date
                        </label>
                        <input type="date" name="exam_date" id="exam_date" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200"
                               min="<?= date('Y-m-d') ?>" required>
                    </div>

                    <!-- Start Time -->
                    <div>
                        <label for="start_time" class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-clock mr-2 text-green-600"></i>
                            Start Time
                        </label>
                        <input type="time" name="start_time" id="start_time" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200"
                               step="60" required>
                        <p class="text-xs text-gray-500 mt-1">Format: HH:MM (e.g., 08:30, 09:15)</p>
                    </div>

                    <!-- End Time -->
                    <div>
                        <label for="end_time" class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-clock mr-2 text-red-600"></i>
                            End Time
                        </label>
                        <input type="time" name="end_time" id="end_time" 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200"
                               step="60" required>
                        <p class="text-xs text-gray-500 mt-1">Format: HH:MM (e.g., 10:30, 12:15)</p>
                    </div>
                </div>

                <!-- Time Validation Message -->
                <div id="time-error" class="text-red-500 text-sm hidden">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    End time must be after start time
                </div>

                <div class="flex justify-end">
                    <button type="submit" name="add_exam" id="submitBtn"
                            class="bg-gradient-to-r from-green-600 to-green-700 text-white font-bold py-4 px-10 rounded-full shadow-lg hover:from-green-700 hover:to-green-800 transition-all duration-300 transform hover:scale-105 text-lg">
                        <i class="fas fa-plus-circle mr-2"></i>
                        Schedule Exam
                    </button>
                </div>
            </form>
        </div>

        <!-- Exams Table Section -->
        <div class="bg-white rounded-3xl shadow-2xl p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-list-alt text-blue-600 mr-3"></i>
                Scheduled Exams
                <span class="ml-4 bg-blue-100 text-blue-800 text-sm font-semibold px-4 py-2 rounded-full">
                    Total: <?= count($exams) ?>
                </span>
            </h2>
            
            <div class="overflow-x-auto">
                <?php if (count($exams) > 0): ?>
                    <table class="min-w-full bg-white rounded-xl overflow-hidden border border-gray-200">
                        <thead class="bg-gradient-to-r from-blue-700 to-purple-700 text-white">
                            <tr>
                                <th class="py-4 px-4 text-left font-semibold">ID</th>
                                <th class="py-4 px-4 text-left font-semibold">Exam Name</th>
                                <th class="py-4 px-4 text-left font-semibold">Class</th>
                                <th class="py-4 px-4 text-left font-semibold">Subject</th>
                                <th class="py-4 px-4 text-left font-semibold">Date</th>
                                <th class="py-4 px-4 text-left font-semibold">Start Time</th>
                                <th class="py-4 px-4 text-left font-semibold">End Time</th>
                                <th class="py-4 px-4 text-left font-semibold">Duration</th>
                                <th class="py-4 px-4 text-left font-semibold">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php foreach ($exams as $row): 
                                // Calculate duration correctly
                                $start = new DateTime($row['start_time']);
                                $end = new DateTime($row['end_time']);
                                $interval = $start->diff($end);
                                $hours = $interval->h;
                                $minutes = $interval->i;
                                $duration_text = '';
                                
                                if ($hours > 0) {
                                    $duration_text .= $hours . ' hour' . ($hours > 1 ? 's' : '');
                                }
                                if ($minutes > 0) {
                                    if ($hours > 0) $duration_text .= ' ';
                                    $duration_text .= $minutes . ' min';
                                }
                                if ($hours == 0 && $minutes == 0) {
                                    $duration_text = '0 min';
                                }
                            ?>
                                <tr class="hover:bg-gray-50 transition-colors duration-150">
                                    <td class="py-4 px-4 text-sm text-gray-800"><?= $row['id']; ?></td>
                                    <td class="py-4 px-4 text-sm font-semibold text-gray-800"><?= htmlspecialchars($row['exam_name']); ?></td>
                                    <td class="py-4 px-4 text-sm">
                                        <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-semibold">
                                            Class <?= htmlspecialchars($row['class_name']); ?>
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 text-sm">
                                        <span class="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-semibold">
                                            <?= htmlspecialchars($row['subject_name']); ?>
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 text-sm">
                                        <i class="far fa-calendar-alt mr-1 text-gray-500"></i>
                                        <?= date('d M Y', strtotime($row['exam_date'])); ?>
                                    </td>
                                    <td class="py-4 px-4 text-sm">
                                        <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-semibold">
                                            <i class="far fa-clock mr-1"></i>
                                            <?= date('h:i A', strtotime($row['start_time'])); ?>
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 text-sm">
                                        <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-semibold">
                                            <i class="far fa-clock mr-1"></i>
                                            <?= date('h:i A', strtotime($row['end_time'])); ?>
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 text-sm">
                                        <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-semibold">
                                            <?= $duration_text ?>
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 text-sm">
                                        <a href="?delete=<?= $row['id']; ?>" 
                                           class="bg-red-500 text-white px-4 py-2 rounded-full hover:bg-red-600 transition-colors duration-200 text-xs font-semibold inline-flex items-center"
                                           onclick="return confirm('Are you sure you want to delete this exam?')">
                                            <i class="fas fa-trash-alt mr-1"></i>
                                            Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-center py-12">
                        <i class="fas fa-calendar-times text-6xl text-gray-300 mb-4"></i>
                        <p class="text-gray-500 text-lg">No exams scheduled yet.</p>
                        <p class="text-gray-400">Use the form above to schedule your first exam.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script>
        $(document).ready(function() {
            // Load subjects when class is selected
            $('#class_id').change(function() {
                var classId = $(this).val();
                
                if (classId) {
                    $('#subject_id').prop('disabled', true);
                    $('#subject-loading').removeClass('hidden');
                    
                    $.ajax({
                        url: window.location.href,
                        type: 'GET',
                        dataType: 'json',
                        data: {
                            ajax: 'get_subjects',
                            class_id: classId
                        },
                        success: function(subjects) {
                            var options = '<option value="">Select Subject</option>';
                            
                            if (subjects.length > 0) {
                                $.each(subjects, function(index, subject) {
                                    options += '<option value="' + subject.id + '">' + subject.subject_name + '</option>';
                                });
                                $('#subject_id').prop('disabled', false);
                            } else {
                                options = '<option value="">No subjects found for this class</option>';
                            }
                            
                            $('#subject_id').html(options);
                            $('#subject-loading').addClass('hidden');
                        },
                        error: function() {
                            $('#subject_id').html('<option value="">Error loading subjects</option>');
                            $('#subject-loading').addClass('hidden');
                        }
                    });
                } else {
                    $('#subject_id').prop('disabled', true);
                    $('#subject_id').html('<option value="">First select a class</option>');
                }
            });

            // Time validation
            function validateTime() {
                var startTime = $('#start_time').val();
                var endTime = $('#end_time').val();
                
                if (startTime && endTime) {
                    // Convert times to comparable format
                    if (startTime >= endTime) {
                        $('#time-error').removeClass('hidden');
                        $('#submitBtn').prop('disabled', true).addClass('opacity-50 cursor-not-allowed');
                        return false;
                    } else {
                        $('#time-error').addClass('hidden');
                        $('#submitBtn').prop('disabled', false).removeClass('opacity-50 cursor-not-allowed');
                        return true;
                    }
                }
                return true;
            }

            $('#start_time, #end_time').on('change', validateTime);

            // Form validation
            $('#examForm').submit(function(e) {
                if (!validateTime()) {
                    e.preventDefault();
                    alert('Please fix the time error before submitting.');
                    return false;
                }
                
                // Validate time format
                var startTime = $('#start_time').val();
                var endTime = $('#end_time').val();
                
                if (!startTime.match(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)) {
                    e.preventDefault();
                    alert('Please enter start time in valid format (e.g., 08:30, 14:30)');
                    return false;
                }
                
                if (!endTime.match(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)) {
                    e.preventDefault();
                    alert('Please enter end time in valid format (e.g., 10:30, 16:00)');
                    return false;
                }
            });

            // Set minimum date to today
            var today = new Date().toISOString().split('T')[0];
            $('#exam_date').attr('min', today);
        });

        // Auto-hide messages after 5 seconds
        setTimeout(function() {
            $('.bg-green-100, .bg-red-100').fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    </script>
</body>
</html>