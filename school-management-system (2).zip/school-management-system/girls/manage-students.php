<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// AJAX Handler for loading students by class
if (isset($_GET['get_students_by_class'])) {
    $class_id = $_GET['get_students_by_class'];
    $stmt = $pdo->prepare("SELECT id, student_name, parent_name FROM students WHERE class_id = ? ORDER BY student_name");
    $stmt->execute([$class_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// AJAX Handler for fetching parent's name from a specific student
if (isset($_GET['get_parent_by_sibling'])) {
    $sibling_id = $_GET['get_parent_by_sibling'];
    $stmt = $pdo->prepare("SELECT parent_name FROM students WHERE id = ? LIMIT 1");
    $stmt->execute([$sibling_id]);
    echo $stmt->fetchColumn();
    exit;
}

$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);
$editStudent = null;
$error = "";
$success = "";
$search = $_GET['search'] ?? '';

/* ================= EDIT ================= */
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ? LIMIT 1");
    $stmt->execute([$_GET['edit']]);
    $editStudent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If editing, parse sibling_ids for checkboxes
    if ($editStudent && !empty($editStudent['sibling_ids'])) {
        $editStudent['sibling_array'] = explode(',', $editStudent['sibling_ids']);
    }
}

/* ================= DELETE ================= */
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $pdo->beginTransaction();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

        // Get image name to delete the file
        $stmt = $pdo->prepare("SELECT image FROM students WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        $img = $stmt->fetchColumn();
        if ($img && file_exists("uploads/" . $img)) {
            unlink("uploads/" . $img);
        }

        // Delete the student
        $del = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $del->execute([$_GET['delete']]);

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $pdo->commit();
        
        header("Location: manage-students.php?success=Student+deleted+successfully");
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: manage-students.php?error=" . urlencode("Delete failed: " . $e->getMessage()));
        exit();
    }
}

/* ================= ADD / UPDATE ================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $dob = $_POST['dob'];
    $class_id = (int)$_POST['class_id'];
    $roll_input = (int)$_POST['roll_no'];
    $parent_name = trim($_POST['parent_name']);
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $admission_date = $_POST['admission_date'];
    $total_fees = $_POST['total_fees'] ?? 0;
    
    // Sibling IDs from checkboxes (stored as comma separated string)
    $sibling_ids = isset($_POST['siblings']) ? implode(',', $_POST['siblings']) : null;

    // Handle image upload
    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileExt = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $imageName = time() . '_' . uniqid() . '.' . $fileExt;
        $uploadPath = $uploadDir . $imageName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
            // If updating, delete old image
            if ($id && $editStudent && !empty($editStudent['image']) && file_exists($uploadDir . $editStudent['image'])) {
                unlink($uploadDir . $editStudent['image']);
            }
        } else {
            $error = "Failed to upload image.";
        }
    } elseif ($id && !empty($_POST['existing_image'])) {
        // Keep existing image when no new image uploaded
        $imageName = $_POST['existing_image'];
    }

    if (empty($error)) {
        $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id=? LIMIT 1");
        $stmt->execute([$class_id]);
        $class_name = $stmt->fetchColumn();
        $roll_no = $roll_input;

        if (!$id) {
            // Generate unique std_id
            do {
                $std_id = "STD" . rand(1000, 9999);
                $checkStd = $pdo->prepare("SELECT id FROM students WHERE std_id=?");
                $checkStd->execute([$std_id]);
            } while($checkStd->rowCount() > 0);

            $stmt = $pdo->prepare("INSERT INTO students (std_id, student_name, email, dob, class_id, roll_no, parent_name, address, phone, admission_date, total_fees, sibling_ids, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$std_id, $name, $email, $dob, $class_id, $roll_no, $parent_name, $address, $phone, $admission_date, $total_fees, $sibling_ids, $imageName]);
            $success = "Student added successfully!";
        } else {
            $stmt = $pdo->prepare("UPDATE students SET student_name=?, email=?, dob=?, class_id=?, roll_no=?, parent_name=?, address=?, phone=?, admission_date=?, total_fees=?, sibling_ids=?, image=?, updated_at=NOW() WHERE id=?");
            $stmt->execute([$name, $email, $dob, $class_id, $roll_no, $parent_name, $address, $phone, $admission_date, $total_fees, $sibling_ids, $imageName, $id]);
            $success = "Student updated successfully!";
        }
        header("Location: manage-students.php?success=" . urlencode($success));
        exit();
    }
}

// Basic Fetch for Table
$stmt = $pdo->prepare("SELECT s.*, c.class_name FROM students s LEFT JOIN classes c ON s.class_id = c.id WHERE s.student_name LIKE ? ORDER BY s.id DESC");
$stmt->execute(["%$search%"]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Students</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-100 p-8">

<div class="max-w-7xl mx-auto">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800"><i class="fas fa-user-graduate mr-2 text-blue-600"></i>Manage Students</h1>
        <a href="girls_dashboard.php" class="bg-gray-600 text-white px-6 py-2 rounded shadow hover:bg-gray-700 transition">Dashboard</a>
    </div>

    <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"><?= $error ?></div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4"><?= htmlspecialchars($_GET['success']) ?></div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-lg mb-6 overflow-hidden">
        <form method="POST" enctype="multipart/form-data" class="p-6">
            <input type="hidden" name="id" value="<?= $editStudent['id'] ?? '' ?>">
            <?php if ($editStudent && !empty($editStudent['image'])): ?>
                <input type="hidden" name="existing_image" value="<?= $editStudent['image'] ?>">
            <?php endif; ?>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Basic Information -->
                <div>
                    <label class="block font-semibold mb-1">Student Name *</label>
                    <input type="text" name="name" required value="<?= $editStudent['student_name'] ?? '' ?>" class="border p-2 rounded w-full">
                </div>
                <div>
                    <label class="block font-semibold mb-1">Email *</label>
                    <input type="email" name="email" required value="<?= $editStudent['email'] ?? '' ?>" class="border p-2 rounded w-full">
                </div>
                <div>
                    <label class="block font-semibold mb-1">Date of Birth *</label>
                    <input type="date" name="dob" required value="<?= $editStudent['dob'] ?? '' ?>" class="border p-2 rounded w-full">
                </div>
                
                <!-- Class and Roll -->
                <div>
                    <label class="block font-semibold mb-1">Class *</label>
                    <select name="class_id" required class="border p-2 rounded w-full">
                        <option value="">Select Class</option>
                        <?php foreach($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= (isset($editStudent['class_id']) && $editStudent['class_id'] == $c['id']) ? 'selected' : '' ?>>Class <?= $c['class_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block font-semibold mb-1">Roll Number *</label>
                    <input type="number" name="roll_no" required value="<?= $editStudent ? preg_replace('/[^0-9]/', '', $editStudent['roll_no']) : '' ?>" class="border p-2 rounded w-full">
                </div>
                
                <!-- Parent/Father Name -->
                <div>
                    <label class="block font-semibold mb-1">Parent/Father Name *</label>
                    <input type="text" name="parent_name" id="parent_name" required value="<?= $editStudent['parent_name'] ?? '' ?>" class="border p-2 rounded w-full">
                </div>
                
                <!-- Contact Information -->
                <div>
                    <label class="block font-semibold mb-1">Phone Number</label>
                    <input type="text" name="phone" value="<?= $editStudent['phone'] ?? '' ?>" class="border p-2 rounded w-full">
                </div>
                <div>
                    <label class="block font-semibold mb-1">Admission Date</label>
                    <input type="date" name="admission_date" value="<?= $editStudent['admission_date'] ?? date('Y-m-d') ?>" class="border p-2 rounded w-full">
                </div>
                
                <!-- Fees -->
                <div>
                    <label class="block font-semibold mb-1 text-blue-600">Total Fees (Monthly/Annual)</label>
                    <input type="number" name="total_fees" value="<?= $editStudent['total_fees'] ?? '' ?>" class="border border-blue-300 p-2 rounded w-full font-bold">
                </div>
                
                <!-- Student Image -->
                <div>
                    <label class="block font-semibold mb-1">Student Image</label>
                    <input type="file" name="image" accept="image/*" class="border p-2 rounded w-full">
                    <?php if ($editStudent && !empty($editStudent['image'])): ?>
                        <div class="mt-2">
                            <img src="uploads/<?= $editStudent['image'] ?>" class="h-20 w-20 object-cover rounded border">
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Address - Full Width -->
                <div class="col-span-1 md:col-span-3">
                    <label class="block font-semibold mb-1">Address</label>
                    <textarea name="address" rows="2" class="border p-2 rounded w-full"><?= $editStudent['address'] ?? '' ?></textarea>
                </div>

                <!-- Siblings Section -->
                <div class="col-span-1 md:col-span-3 border-t pt-4">
                    <label class="inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="hasSibling" class="h-5 w-5 text-blue-600" 
                            <?= ($editStudent && !empty($editStudent['sibling_ids'])) ? 'checked' : '' ?>
                            onchange="document.getElementById('siblingSection').classList.toggle('hidden')">
                        <span class="ml-2 font-bold text-gray-700">Has Siblings in School?</span>
                    </label>
                    
                    <div id="siblingSection" class="<?= ($editStudent && !empty($editStudent['sibling_ids'])) ? '' : 'hidden' ?> mt-4 bg-gray-50 p-4 rounded-lg">
                        <p class="text-sm text-gray-500 mb-2 font-semibold">Select Sibling's Class to load students:</p>
                        
                        <div class="flex gap-4 mb-4">
                            <select id="siblingClassSelect" onchange="loadClassStudents(this.value)" class="border p-2 rounded w-full md:w-1/3">
                                <option value="">-- Choose Class --</option>
                                <?php foreach($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>">Class <?= $c['class_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            
                            <button type="button" onclick="clearSiblingSelection()" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                                Clear Selection
                            </button>
                        </div>
                        
                        <div id="siblingList" class="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-60 overflow-y-auto p-2 border rounded bg-white">
                            <!-- Siblings will be loaded here via AJAX -->
                            <?php if ($editStudent && !empty($editStudent['sibling_ids'])): ?>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        setTimeout(function() {
                                            loadAllSiblings();
                                        }, 500);
                                    });
                                </script>
                            <?php endif; ?>
                        </div>
                        
                        <p class="text-xs text-gray-500 mt-2">
                            <i class="fas fa-info-circle"></i> Check the siblings of this student. Parent name will auto-fill from selected sibling.
                        </p>
                    </div>
                </div>
            </div>

            <div class="mt-6 flex gap-3">
                <button type="submit" class="bg-green-600 text-white font-bold py-2 px-8 rounded hover:bg-green-700">
                    <i class="fas fa-save mr-2"></i><?= $editStudent ? 'Update Student' : 'Save Student' ?>
                </button>
                <?php if ($editStudent): ?>
                    <a href="manage-students.php" class="bg-gray-500 text-white font-bold py-2 px-6 rounded hover:bg-gray-600">
                        Cancel
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Search Bar -->
    <div class="mb-4">
        <form method="GET" class="flex gap-2">
            <input type="text" name="search" placeholder="Search by student name..." value="<?= htmlspecialchars($search) ?>" class="border p-2 rounded flex-1">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                <i class="fas fa-search"></i> Search
            </button>
            <?php if ($search): ?>
                <a href="manage-students.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">Clear</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Students Table -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <table class="w-full text-left">
            <thead class="bg-gray-200">
                <tr>
                    <th class="p-4">Student ID</th>
                    <th class="p-4">Image</th>
                    <th class="p-4">Name</th>
                    <th class="p-4">Roll No</th>
                    <th class="p-4">Class</th>
                    <th class="p-4">Father Name</th>
                    <th class="p-4">Phone</th>
                    <th class="p-4">Total Fees</th>
                    <th class="p-4">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($students as $s): ?>
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-4 font-mono text-sm"><?= $s['std_id'] ?></td>
                    <td class="p-4">
                        <?php if (!empty($s['image']) && file_exists("uploads/" . $s['image'])): ?>
                            <img src="uploads/<?= $s['image'] ?>" class="h-10 w-10 object-cover rounded-full border">
                        <?php else: ?>
                            <div class="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center text-gray-500">
                                <i class="fas fa-user"></i>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td class="p-4 font-bold"><?= $s['student_name'] ?></td>
                    <td class="p-4"><?= $s['roll_no'] ?></td>
                    <td class="p-4">Class <?= $s['class_name'] ?></td>
                    <td class="p-4"><?= $s['parent_name'] ?></td>
                    <td class="p-4"><?= $s['phone'] ?? '-' ?></td>
                    <td class="p-4 font-semibold text-green-700"><?= $s['total_fees'] ?></td>
                    <td class="p-4 flex gap-3">
                        <a href="?edit=<?= $s['id'] ?>&search=<?= urlencode($search) ?>" class="text-blue-600 hover:text-blue-900" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="?delete=<?= $s['id'] ?>&search=<?= urlencode($search) ?>" onclick="return confirm('Delete this student?')" class="text-red-600 hover:text-red-900" title="Delete">
                            <i class="fas fa-trash"></i>
                        </a>
                        <?php if (!empty($s['sibling_ids'])): ?>
                            <span class="text-green-600" title="Has siblings"><i class="fas fa-users"></i></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if (empty($students)): ?>
                <tr>
                    <td colspan="9" class="p-8 text-center text-gray-500">No students found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Store all loaded siblings for reference
let allLoadedStudents = [];

// Load students when sibling class is selected
function loadClassStudents(classId) {
    if(!classId) return;
    
    const container = document.getElementById('siblingList');
    container.innerHTML = '<div class="col-span-4 text-center py-4"><i class="fas fa-spinner fa-spin mr-2"></i>Loading students...</div>';

    fetch(`?get_students_by_class=${classId}`)
        .then(res => res.json())
        .then(data => {
            allLoadedStudents = data;
            displaySiblings(data);
        })
        .catch(error => {
            container.innerHTML = '<div class="col-span-4 text-center py-4 text-red-500">Error loading students.</div>';
        });
}

// Display siblings in the grid
function displaySiblings(students) {
    const container = document.getElementById('siblingList');
    const currentSiblingIds = <?= json_encode($editStudent['sibling_array'] ?? []) ?>;
    
    if (students.length === 0) {
        container.innerHTML = '<div class="col-span-4 text-center py-4 text-gray-500">No students found in this class.</div>';
        return;
    }
    
    container.innerHTML = "";
    students.forEach(st => {
        const isChecked = currentSiblingIds.includes(String(st.id));
        container.innerHTML += `
            <label class="flex items-center bg-white p-2 border rounded cursor-pointer hover:bg-blue-50 ${isChecked ? 'bg-blue-100 border-blue-300' : ''}">
                <input type="checkbox" name="siblings[]" value="${st.id}" class="mr-2 sibling-checkbox" 
                       onchange="handleSiblingCheck(this, ${st.id}, '${st.parent_name}')"
                       ${isChecked ? 'checked' : ''}>
                <span class="text-sm font-medium">${st.student_name}</span>
            </label>
        `;
    });
}

// Handle sibling checkbox change
function handleSiblingCheck(checkbox, siblingId, parentName) {
    if (checkbox.checked) {
        // Auto-fill parent name if not already filled
        const parentField = document.getElementById('parent_name');
        if (!parentField.value) {
            parentField.value = parentName;
        }
        
        // Highlight the selected sibling
        checkbox.closest('label').classList.add('bg-blue-100', 'border-blue-300');
    } else {
        // Remove highlight
        checkbox.closest('label').classList.remove('bg-blue-100', 'border-blue-300');
    }
}

// Clear sibling selection
function clearSiblingSelection() {
    document.querySelectorAll('input[name="siblings[]"]').forEach(cb => {
        cb.checked = false;
        cb.closest('label').classList.remove('bg-blue-100', 'border-blue-300');
    });
    document.getElementById('siblingClassSelect').value = '';
    document.getElementById('siblingList').innerHTML = '';
}

// Load all siblings when editing (for multiple classes)
function loadAllSiblings() {
    const currentSiblingIds = <?= json_encode($editStudent['sibling_array'] ?? []) ?>;
    if (currentSiblingIds.length === 0) return;
    
    // Fetch each sibling's details
    currentSiblingIds.forEach(id => {
        fetch(`?get_parent_by_sibling=${id}`)
            .then(res => res.text())
            .then(name => {
                // You could load them in a specific way here
                console.log(`Sibling ID ${id}: ${name}`);
            });
    });
}

// Initialize on page load if editing
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($editStudent && !empty($editStudent['sibling_ids'])): ?>
        // Trigger class selection for first sibling's class
        const siblingIds = <?= json_encode($editStudent['sibling_array'] ?? []) ?>;
        if (siblingIds.length > 0) {
            // You could load the first sibling's class
            // This would require an additional AJAX call to get class_id from student id
        }
    <?php endif; ?>
    
    // Add real-time validation
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const email = document.querySelector('input[name="email"]').value;
            const phone = document.querySelector('input[name="phone"]').value;
            
            if (phone && !/^[0-9+\-\s]{10,15}$/.test(phone)) {
                e.preventDefault();
                alert('Please enter a valid phone number (10-15 digits)');
            }
        });
    }
});

// Auto-hide success/error messages after 5 seconds
setTimeout(function() {
    document.querySelectorAll('.bg-green-100, .bg-red-100').forEach(el => {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 500);
    });
}, 5000);
</script>

</body>
</html>