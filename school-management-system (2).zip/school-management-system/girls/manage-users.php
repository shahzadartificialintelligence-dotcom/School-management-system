<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

$success = '';
$error = '';
$editUser = null;

// 2. Delete User Logic
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    if ($_GET['delete'] == $_SESSION['user_id']) {
        $error = "Security Error: You cannot delete your own account.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        header("Location: manage-users.php?msg=User+Deleted");
        exit();
    }
}

// 3. Fetch User for Editing
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editUser = $stmt->fetch(PDO::FETCH_ASSOC);
}

// 4. Handle Add/Update Form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'] ?? 'admin';
    $status = $_POST['status'] ?? 'active';
    $id = $_POST['user_id'] ?? null;

    if (empty($full_name) || empty($email)) {
        $error = "Name and Email are required fields.";
    } else {
        try {
            if ($id) {
                // UPDATE
                if (!empty($password)) {
                    $hashed = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET full_name=?, email=?, password=?, role=?, status=?, updated_at=NOW() WHERE id=?");
                    $stmt->execute([$full_name, $email, $hashed, $role, $status, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET full_name=?, email=?, role=?, status=?, updated_at=NOW() WHERE id=?");
                    $stmt->execute([$full_name, $email, $role, $status, $id]);
                }
                $success = "User updated successfully.";
            } else {
                // INSERT NEW
                $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $check->execute([$email]);
                if ($check->fetch()) {
                    $error = "This email is already in use.";
                } else {
                    $hashed = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$full_name, $email, $hashed, $role, $status]);
                    $success = "New user created successfully.";
                }
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// 5. Fetch All Users for the List
$search = $_GET['search'] ?? '';
$sql = "SELECT * FROM users";
if ($search) {
    $sql .= " WHERE full_name LIKE :s OR email LIKE :s OR role LIKE :s";
}
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
if ($search) $stmt->bindValue(':s', "%$search%");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #f3f4f6; }
        .card-glass { background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.4); }
    </style>
</head>
<body class="p-4 md:p-8">

    <div class="max-w-7xl mx-auto">
        <div class="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-800 tracking-tight">User Management</h1>
                <p class="text-sm text-gray-500">Add, update, or remove system users and admins.</p>
            </div>
            <div class="flex gap-3">
                <a href="girls_dashboard.php" class="bg-white px-4 py-2 rounded-lg shadow-sm border text-sm font-medium text-gray-600 hover:bg-gray-50 transition flex items-center gap-2">
                    <i class="fa-solid fa-house"></i> Dashboard
                </a>
            </div>
        </div>

        <?php if ($success || isset($_GET['msg'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-3 animate-pulse">
                <i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($success ?: $_GET['msg']) ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6 flex items-center gap-3">
                <i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <div class="grid lg:grid-cols-12 gap-8">
            
            <div class="lg:col-span-4">
                <div class="card-glass p-6 rounded-2xl shadow-sm border">
                    <h3 class="text-lg font-bold text-gray-800 mb-6">
                        <i class="fa-solid <?= $editUser ? 'fa-user-pen text-orange-500' : 'fa-user-plus text-blue-500' ?> mr-2"></i>
                        <?= $editUser ? 'Edit User Details' : 'Create New User' ?>
                    </h3>
                    
                    <form method="POST" class="space-y-4">
                        <?php if($editUser): ?>
                            <input type="hidden" name="user_id" value="<?= $editUser['id'] ?>">
                        <?php endif; ?>

                        <div>
                            <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Full Name</label>
                            <input type="text" name="full_name" required value="<?= htmlspecialchars($editUser['full_name'] ?? '') ?>" 
                                   class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition">
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Email Address</label>
                            <input type="email" name="email" required value="<?= htmlspecialchars($editUser['email'] ?? '') ?>" 
                                   class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition">
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Password <?= $editUser ? '(Optional)' : '' ?></label>
                            <input type="password" name="password" <?= $editUser ? '' : 'required' ?> placeholder="<?= $editUser ? 'Leave blank to keep current' : 'Enter password' ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition">
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Role</label>
                                <select name="role" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-blue-500 transition">
                                    <option value="admin" <?= (isset($editUser) && $editUser['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                                    <option value="staff" <?= (isset($editUser) && $editUser['role'] == 'staff') ? 'selected' : '' ?>>Staff</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Status</label>
                                <select name="status" class="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-blue-500 transition">
                                    <option value="active" <?= (isset($editUser) && $editUser['status'] == 'active') ? 'selected' : '' ?>>Active</option>
                                    <option value="inactive" <?= (isset($editUser) && $editUser['status'] == 'inactive') ? 'selected' : '' ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl shadow-lg shadow-blue-200 transition-all active:scale-95">
                            <?= $editUser ? 'Update User' : 'Create User' ?>
                        </button>
                        
                        <?php if($editUser): ?>
                            <a href="manage-users.php" class="block text-center text-sm text-gray-400 hover:text-gray-600 underline">Discard Changes</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="lg:col-span-8">
                <div class="bg-white rounded-2xl shadow-sm border overflow-hidden">
                    <div class="p-4 border-b">
                        <form method="GET" class="relative">
                            <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                            <input type="text" name="search" placeholder="Search by name, email, or role..." value="<?= htmlspecialchars($search) ?>"
                                   class="w-full pl-11 pr-4 py-2 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-500 outline-none transition">
                        </form>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-gray-50 text-gray-400 text-[10px] uppercase font-bold tracking-widest">
                                <tr>
                                    <th class="px-6 py-4">User Details</th>
                                    <th class="px-6 py-4 text-center">Role</th>
                                    <th class="px-6 py-4 text-center">Status</th>
                                    <th class="px-6 py-4 text-center">Last Login</th>
                                    <th class="px-6 py-4 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php foreach ($users as $u): ?>
                                <tr class="hover:bg-blue-50/30 transition group">
                                    <td class="px-6 py-4">
                                        <div class="font-semibold text-gray-800"><?= htmlspecialchars($u['full_name']) ?></div>
                                        <div class="text-xs text-gray-400"><?= htmlspecialchars($u['email']) ?></div>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="text-[10px] font-bold px-2.5 py-1 rounded-md <?= $u['role'] == 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-600' ?>">
                                            <?= strtoupper($u['role']) ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <span class="inline-block w-2 h-2 rounded-full <?= $u['status'] == 'active' ? 'bg-green-500' : 'bg-red-400' ?> mr-1"></span>
                                        <span class="text-xs font-medium text-gray-600 lowercase"><?= $u['status'] ?></span>
                                    </td>
                                    <td class="px-6 py-4 text-center text-xs text-gray-500">
                                        <?= $u['last_login'] ? date('d M, H:i', strtotime($u['last_login'])) : 'Never' ?>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <div class="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <a href="?edit=<?= $u['id'] ?>" class="p-2 text-blue-500 hover:bg-blue-100 rounded-lg transition" title="Edit">
                                                <i class="fa-solid fa-pen"></i>
                                            </a>
                                            <a href="?delete=<?= $u['id'] ?>" onclick="return confirm('Confirm deletion of this user?')" 
                                               class="p-2 text-red-500 hover:bg-red-100 rounded-lg transition" title="Delete">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

</body>
</html>