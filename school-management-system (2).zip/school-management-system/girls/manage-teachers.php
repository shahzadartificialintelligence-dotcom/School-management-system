<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

if (!isset($conn) && isset($pdo)) {
    $conn = $pdo;
}

// Initialize variables
$success_message = '';
$error_message = '';

/* ================= AUTO-GENERATE TEACHER ID FUNCTION ================= */
function generateTeacherId($conn) {
    $prefix = "TCH";
    $year = date('Y');
    
    // Get the last teacher ID for this year
    $stmt = $conn->prepare("SELECT teacher_id FROM teachers WHERE teacher_id LIKE '$prefix$year%' ORDER BY id DESC LIMIT 1");
    $stmt->execute();
    $lastTeacher = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($lastTeacher) {
        // Extract the sequence number and increment
        $lastId = $lastTeacher['teacher_id'];
        $sequence = (int)substr($lastId, -4);
        $newSequence = $sequence + 1;
    } else {
        // Start from 1 if no teachers this year
        $newSequence = 1;
    }
    
    // Format: TCH20240001 (TCH + Year + 4-digit sequence)
    $newTeacherId = $prefix . $year . str_pad($newSequence, 4, '0', STR_PAD_LEFT);
    
    return $newTeacherId;
}

/* ================= ADD TEACHER ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_teacher'])) {

    // Get form data
    $name          = trim($_POST['name'] ?? '');
    $father_name   = trim($_POST['father_name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $gender        = $_POST['gender'] ?? '';
    $phone         = trim($_POST['phone'] ?? '');
    $address       = trim($_POST['address'] ?? '');
    $qualification = trim($_POST['qualification'] ?? '');

    // Validate required fields
    $required_fields = ['name', 'father_name', 'email', 'gender'];
    $missing_fields = [];
    
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $missing_fields[] = str_replace('_', ' ', $field);
        }
    }
    
    if (!empty($missing_fields)) {
        $error_message = "Required fields missing: " . implode(', ', $missing_fields);
    }
    
    // Validate email format
    if (empty($error_message) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format!";
    }
    
    // Validate phone number if provided
    if (empty($error_message) && !empty($phone) && !preg_match('/^[0-9+\-\s]{10,15}$/', $phone)) {
        $error_message = "Invalid phone number format!";
    }

    if (empty($error_message)) {
        try {
            $conn->beginTransaction();

            // Check if email already exists
            $stmt = $conn->prepare("SELECT id FROM teachers WHERE email = :email LIMIT 1");
            $stmt->execute([':email' => $email]);

            if ($stmt->fetch()) {
                $error_message = "A teacher with this email already exists.";
            } else {
                // Generate unique teacher ID
                $teacher_id = generateTeacherId($conn);
                
                // Insert new teacher
                $stmt = $conn->prepare("INSERT INTO teachers 
                    (teacher_id, name, father_name, email, gender, phone, address, qualification, created_at) 
                    VALUES 
                    (:teacher_id, :name, :father_name, :email, :gender, :phone, :address, :qualification, NOW())");

                $stmt->execute([
                    ':teacher_id'   => $teacher_id,
                    ':name'         => $name,
                    ':father_name'  => $father_name,
                    ':email'        => $email,
                    ':gender'       => $gender,
                    ':phone'        => $phone,
                    ':address'      => $address,
                    ':qualification'=> $qualification
                ]);

                $conn->commit();
                $success_message = "Teacher added successfully. Teacher ID: " . $teacher_id;
            }

        } catch (Exception $e) {
            $conn->rollBack();
            $error_message = "Error adding teacher: " . $e->getMessage();
        }
    }
}

/* ================= DELETE TEACHER ================= */
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $teacher_id = (int)$_GET['delete'];

    try {
        $stmt = $conn->prepare("DELETE FROM teachers WHERE id = :id");
        $stmt->execute([':id' => $teacher_id]);
        
        $success_message = "Teacher deleted successfully.";
    } catch (Exception $e) {
        $error_message = "Error deleting teacher: " . $e->getMessage();
    }
}

/* ================= EDIT TEACHER ================= */
$editTeacher = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $stmt = $conn->prepare("SELECT * FROM teachers WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $_GET['edit']]);
    $editTeacher = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$editTeacher) {
        $error_message = "Teacher not found!";
    }
}

/* ================= UPDATE TEACHER ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_teacher'])) {
    
    $id            = (int)$_POST['id'];
    $name          = trim($_POST['name'] ?? '');
    $father_name   = trim($_POST['father_name'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $gender        = $_POST['gender'] ?? '';
    $phone         = trim($_POST['phone'] ?? '');
    $address       = trim($_POST['address'] ?? '');
    $qualification = trim($_POST['qualification'] ?? '');

    // Validate required fields
    if (empty($name) || empty($father_name) || empty($email) || empty($gender)) {
        $error_message = "Please fill in all required fields.";
    }
    
    // Validate email format
    if (empty($error_message) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format!";
    }

    if (empty($error_message)) {
        try {
            // Check if email exists for another teacher
            $stmt = $conn->prepare("SELECT id FROM teachers WHERE email = :email AND id != :id LIMIT 1");
            $stmt->execute([':email' => $email, ':id' => $id]);

            if ($stmt->fetch()) {
                $error_message = "Email already exists for another teacher.";
            } else {
                $stmt = $conn->prepare("UPDATE teachers SET 
                    name = :name,
                    father_name = :father_name,
                    email = :email,
                    gender = :gender,
                    phone = :phone,
                    address = :address,
                    qualification = :qualification,
                    updated_at = NOW()
                    WHERE id = :id");

                $stmt->execute([
                    ':id'           => $id,
                    ':name'         => $name,
                    ':father_name'  => $father_name,
                    ':email'        => $email,
                    ':gender'       => $gender,
                    ':phone'        => $phone,
                    ':address'      => $address,
                    ':qualification'=> $qualification
                ]);

                $success_message = "Teacher updated successfully.";
                $editTeacher = null; // Clear edit mode
            }

        } catch (Exception $e) {
            $error_message = "Error updating teacher: " . $e->getMessage();
        }
    }
}

/* ================= FETCH TEACHERS WITH PAGINATION ================= */
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$search = $_GET['search'] ?? '';

// Count total records
if (!empty($search)) {
    $countStmt = $conn->prepare("SELECT COUNT(*) as total FROM teachers 
                                 WHERE name LIKE :search 
                                 OR teacher_id LIKE :search 
                                 OR email LIKE :search 
                                 OR father_name LIKE :search");
    $countStmt->execute([':search' => "%$search%"]);
} else {
    $countStmt = $conn->query("SELECT COUNT(*) as total FROM teachers");
}
$totalRecords = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPages = ceil($totalRecords / $limit);

// Fetch teachers
if (!empty($search)) {
    $stmt = $conn->prepare("SELECT * FROM teachers 
                            WHERE name LIKE :search 
                            OR teacher_id LIKE :search 
                            OR email LIKE :search 
                            OR father_name LIKE :search 
                            ORDER BY id DESC 
                            LIMIT :limit OFFSET :offset");
    
    $stmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
} else {
    $stmt = $conn->prepare("SELECT * FROM teachers ORDER BY id DESC LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
}

$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Manage Teachers - School Management System</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
body { font-family: 'Inter', sans-serif; }
.transition-all { transition: all 0.3s ease; }
</style>
</head>
<body class="bg-gray-100 min-h-screen">

<header class="bg-white shadow-md p-6">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
        <h1 class="text-3xl font-extrabold text-gray-800 mb-4 md:mb-0">
            <i class="fas fa-chalkboard-teacher text-blue-600 mr-2"></i>
            Manage Teachers
        </h1>
        <div class="flex space-x-4">
            <a href="girls_dashboard.php" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
                <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
            </a>
        </div>
    </div>
</header>

<main class="max-w-7xl mx-auto p-8">

    <!-- Success/Error Messages -->
    <?php if (!empty($success_message)): ?>
        <div class="bg-green-100 text-green-800 border border-green-200 p-4 rounded-lg mb-6 shadow-sm flex items-center justify-between">
            <span><i class="fas fa-check-circle mr-2"></i><?= htmlspecialchars($success_message) ?></span>
            <button onclick="this.parentElement.remove()" class="text-green-600 hover:text-green-800">
                <i class="fas fa-times"></i>
            </button>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($error_message)): ?>
        <div class="bg-red-100 text-red-800 border border-red-200 p-4 rounded-lg mb-6 shadow-sm flex items-center justify-between">
            <span><i class="fas fa-exclamation-circle mr-2"></i><?= htmlspecialchars($error_message) ?></span>
            <button onclick="this.parentElement.remove()" class="text-red-600 hover:text-red-800">
                <i class="fas fa-times"></i>
            </button>
        </div>
    <?php endif; ?>

    <!-- Add/Edit Teacher Section -->
    <div class="bg-white p-6 rounded-2xl shadow-xl mb-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">
            <i class="fas fa-<?= $editTeacher ? 'edit' : 'user-plus' ?> mr-2 text-blue-600"></i>
            <?= $editTeacher ? 'Edit Teacher' : 'Add New Teacher' ?>
        </h2>
        
        <form method="POST" class="space-y-4">
            <?php if($editTeacher): ?>
                <input type="hidden" name="id" value="<?= $editTeacher['id'] ?>">
            <?php endif; ?>
            
            <div class="grid md:grid-cols-4 gap-4">
                <?php if($editTeacher): ?>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Teacher ID</label>
                        <input type="text" value="<?= htmlspecialchars($editTeacher['teacher_id']) ?>" readonly 
                               class="w-full border-2 border-gray-200 bg-gray-50 rounded-lg p-3 text-gray-600">
                    </div>
                <?php endif; ?>
                
                <div class="<?= $editTeacher ? 'md:col-span-3' : 'md:col-span-4' ?>">
                    <label class="block text-sm font-semibold text-gray-600 mb-1">Full Name *</label>
                    <input type="text" name="name" placeholder="Enter full name" required 
                           value="<?= htmlspecialchars($editTeacher['name'] ?? '') ?>"
                           class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all">
                </div>
            </div>
            
            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">Father's Name *</label>
                    <input type="text" name="father_name" placeholder="Enter father's name" required 
                           value="<?= htmlspecialchars($editTeacher['father_name'] ?? '') ?>"
                           class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">Email Address *</label>
                    <input type="email" name="email" placeholder="teacher@example.com" required 
                           value="<?= htmlspecialchars($editTeacher['email'] ?? '') ?>"
                           class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all">
                </div>
            </div>
            
            <div class="grid md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">Phone Number</label>
                    <input type="tel" name="phone" placeholder="+1234567890" 
                           value="<?= htmlspecialchars($editTeacher['phone'] ?? '') ?>"
                           class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">Gender *</label>
                    <select name="gender" required class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all">
                        <option value="">Select Gender</option>
                        <option value="Male" <?= (isset($editTeacher['gender']) && $editTeacher['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= (isset($editTeacher['gender']) && $editTeacher['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
                        <option value="Other" <?= (isset($editTeacher['gender']) && $editTeacher['gender'] == 'Other') ? 'selected' : '' ?>>Other</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-600 mb-1">Qualification</label>
                    <input type="text" name="qualification" placeholder="e.g., M.Sc, B.Ed" 
                           value="<?= htmlspecialchars($editTeacher['qualification'] ?? '') ?>"
                           class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all">
                </div>
            </div>
            
            <div>
                <label class="block text-sm font-semibold text-gray-600 mb-1">Address</label>
                <textarea name="address" rows="2" placeholder="Enter full address" 
                          class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-all"><?= htmlspecialchars($editTeacher['address'] ?? '') ?></textarea>
            </div>
            
            <div class="flex justify-end space-x-3">
                <?php if($editTeacher): ?>
                    <a href="manage-teachers.php" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-times mr-2"></i>Cancel
                    </a>
                    <button type="submit" name="update_teacher" class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-save mr-2"></i>Update Teacher
                    </button>
                <?php else: ?>
                    <button type="submit" name="add_teacher" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-user-plus mr-2"></i>Add Teacher
                    </button>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Search and Filter -->
    <div class="bg-white p-4 rounded-2xl shadow-xl mb-6">
        <form method="GET" class="flex flex-col md:flex-row gap-3">
            <div class="flex-1">
                <div class="relative">
                    <input type="text" name="search" placeholder="Search by name, ID, email or father's name..." 
                           value="<?= htmlspecialchars($search) ?>" 
                           class="w-full border-2 border-gray-300 rounded-lg p-3 pl-10 focus:outline-none focus:border-blue-500 transition-all">
                    <i class="fas fa-search absolute left-3 top-4 text-gray-400"></i>
                </div>
            </div>
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg transition-all">
                <i class="fas fa-search mr-2"></i>Search
            </button>
            <?php if($search): ?>
                <a href="manage-teachers.php" class="bg-gray-500 hover:bg-gray-600 text-white px-8 py-3 rounded-lg transition-all text-center">
                    <i class="fas fa-times mr-2"></i>Clear
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Results Summary -->
    <div class="mb-4 text-gray-600 flex justify-between items-center">
        <span>
            <i class="fas fa-list mr-2"></i>
            Showing <?= count($teachers) ?> of <?= $totalRecords ?> teachers
        </span>
        <?php if($totalRecords > 0): ?>
            <span class="text-sm bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
                Page <?= $page ?> of <?= $totalPages ?>
            </span>
        <?php endif; ?>
    </div>

    <!-- Teacher List Section -->
    <div class="bg-white p-6 rounded-2xl shadow-xl">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">
            <i class="fas fa-list mr-2 text-blue-600"></i>
            Teacher List
        </h2>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white rounded-lg overflow-hidden">
                <thead class="bg-gray-200 text-gray-700">
                    <tr>
                        <th class="py-3 px-4 text-left font-semibold">ID</th>
                        <th class="py-3 px-4 text-left font-semibold">Teacher ID</th>
                        <th class="py-3 px-4 text-left font-semibold">Full Name</th>
                        <th class="py-3 px-4 text-left font-semibold">Father Name</th>
                        <th class="py-3 px-4 text-left font-semibold">Email</th>
                        <th class="py-3 px-4 text-left font-semibold">Gender</th>
                        <th class="py-3 px-4 text-left font-semibold">Phone</th>
                        <th class="py-3 px-4 text-left font-semibold">Qualification</th>
                        <th class="py-3 px-4 text-left font-semibold">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php if (!empty($teachers)): ?>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr class="hover:bg-gray-50 transition-colors duration-150">
                                <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($teacher['id']) ?></td>
                                <td class="py-3 px-4 text-sm font-mono font-medium text-blue-600"><?= htmlspecialchars($teacher['teacher_id']) ?></td>
                                <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($teacher['name']) ?></td>
                                <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($teacher['father_name']) ?></td>
                                <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($teacher['email']) ?></td>
                                <td class="py-3 px-4 text-sm">
                                    <span class="px-2 py-1 text-xs font-medium rounded-full 
                                        <?= $teacher['gender'] == 'Male' ? 'bg-blue-100 text-blue-800' : ($teacher['gender'] == 'Female' ? 'bg-pink-100 text-pink-800' : 'bg-purple-100 text-purple-800') ?>">
                                        <?= htmlspecialchars($teacher['gender']) ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($teacher['phone']) ?></td>
                                <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($teacher['qualification']) ?></td>
                                <td class="py-3 px-4">
                                    <div class="flex space-x-2">
                                        <a href="?edit=<?= $teacher['id'] ?>" class="bg-blue-600 text-white text-xs py-2 px-3 rounded-full hover:bg-blue-700 transition-colors duration-300">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="?delete=<?= $teacher['id'] ?>&page=<?= $page ?>&search=<?= urlencode($search) ?>" 
                                           onclick="return confirm('Are you sure you want to delete <?= htmlspecialchars($teacher['name']) ?>?')" 
                                           class="bg-red-600 text-white text-xs py-2 px-3 rounded-full hover:bg-red-700 transition-colors duration-300">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="py-8 px-4 text-center text-gray-500">
                                <i class="fas fa-users text-4xl mb-3 text-gray-300"></i>
                                <p>No teachers found.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if($totalPages > 1): ?>
    <div class="mt-6 flex justify-center">
        <nav class="flex gap-2">
            <?php if($page > 1): ?>
                <a href="?page=1&search=<?= urlencode($search) ?>" 
                   class="px-4 py-2 bg-white text-blue-600 rounded-lg border hover:bg-blue-50 transition-all">
                    <i class="fas fa-angle-double-left"></i>
                </a>
                <a href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>" 
                   class="px-4 py-2 bg-white text-blue-600 rounded-lg border hover:bg-blue-50 transition-all">
                    <i class="fas fa-angle-left"></i>
                </a>
            <?php endif; ?>

            <?php
            $start = max(1, $page - 2);
            $end = min($totalPages, $page + 2);
            for($i = $start; $i <= $end; $i++):
            ?>
                <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>" 
                   class="px-4 py-2 <?= $i == $page ? 'bg-blue-600 text-white' : 'bg-white text-blue-600 hover:bg-blue-50' ?> rounded-lg border transition-all font-medium">
                    <?= $i ?>
                </a>
            <?php endfor; ?>

            <?php if($page < $totalPages): ?>
                <a href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>" 
                   class="px-4 py-2 bg-white text-blue-600 rounded-lg border hover:bg-blue-50 transition-all">
                    <i class="fas fa-angle-right"></i>
                </a>
                <a href="?page=<?= $totalPages ?>&search=<?= urlencode($search) ?>" 
                   class="px-4 py-2 bg-white text-blue-600 rounded-lg border hover:bg-blue-50 transition-all">
                    <i class="fas fa-angle-double-right"></i>
                </a>
            <?php endif; ?>
        </nav>
    </div>
    <?php endif; ?>

</main>

<script>
// Auto-hide success/error messages after 5 seconds
setTimeout(function() {
    document.querySelectorAll('.bg-green-100, .bg-red-100').forEach(function(el) {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity = '0';
        setTimeout(function() { 
            if (el.parentNode) {
                el.remove(); 
            }
        }, 500);
    });
}, 5000);

// Form validation
document.querySelector('form[method="POST"]')?.addEventListener('submit', function(e) {
    const phone = this.querySelector('input[name="phone"]').value;
    if (phone && !/^[0-9+\-\s]{10,15}$/.test(phone)) {
        e.preventDefault();
        alert('Please enter a valid phone number (10-15 digits)');
    }
});
</script>

</body>
</html>