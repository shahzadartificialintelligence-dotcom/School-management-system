<?php
// config/config.php

// Automatically detect protocol (http or https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";

// Your host name (localhost in XAMPP)
$host = $_SERVER['HTTP_HOST'];

// Folder name of your project (update if different)
$project_folder = "/school-management-system/";

// Define BASE_URL so we can use it anywhere
define('BASE_URL', $protocol . "://" . $host . $project_folder);
