<?php
$host = "localhost";
$dbname = "aracadem_boys_campus"; // your DB name
$username = "root"; // default in XAMPP
$password = "";     // default in XAMPP

try {
    // Create PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Alias for compatibility with files expecting $conn
    $conn = $pdo;

} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
