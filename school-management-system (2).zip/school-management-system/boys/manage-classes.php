<?php
session_start();
require_once(__DIR__ . '/../config/boysdb.php'); // Uses $pdo from config
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check

// Add new class
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_class'])) {
    $class_name = trim($_POST['class_name']);
    if (!empty($class_name)) {
        $stmt = $pdo->prepare("INSERT INTO classes (class_name) VALUES (:class_name)");
        $stmt->execute(['class_name' => $class_name]);
    }
}

// Delete class
if (isset($_GET['delete'])) {
    $class_id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM classes WHERE id = :id");
    $stmt->execute(['id' => $class_id]);
}

// Fetch all classes
$stmt = $pdo->query("SELECT * FROM classes ORDER BY id DESC");
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Classes - Admin Panel</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Inter Font -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

    <!-- Header Section -->
    <header class="bg-white shadow-md p-6">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <h1 class="text-3xl font-extrabold text-gray-800">
                Manage Classes
            </h1>
            <div class="flex space-x-4">
                <a href="boys_dashboard.php" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
                    Back to Dashboard
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-6xl mx-auto p-8">
        <!-- Add New Class Section -->
        <div class="bg-white p-6 rounded-2xl shadow-xl mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Add New Class</h2>
            <form method="POST" action="" class="space-y-4">
                <div>
                    <input type="text" name="class_name" placeholder="Enter Class Name" required class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200">
                </div>
                <div class="flex justify-end">
                    <button type="submit" name="add_class" class="bg-blue-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-blue-700 transition-colors duration-300 transform hover:scale-105">
                        Add Class
                    </button>
                </div>
            </form>
        </div>

        <!-- Class List Section -->
        <div class="bg-white p-6 rounded-2xl shadow-xl">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Class List</h2>
            <div class="overflow-x-auto">
                <?php if (!empty($classes)): ?>
                    <table class="min-w-full bg-white rounded-lg overflow-hidden">
                        <thead class="bg-gray-200 text-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left font-semibold">ID</th>
                                <th class="py-3 px-4 text-left font-semibold">Class Name</th>
                                <th class="py-3 px-4 text-left font-semibold">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php foreach ($classes as $row): ?>
                                <tr class="hover:bg-gray-50 transition-colors duration-150">
                                    <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($row['id']); ?></td>
                                    <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($row['class_name']); ?></td>
                                    <td class="py-3 px-4">
                                        <a href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this class?')" class="bg-red-600 text-white font-semibold text-xs py-2 px-4 rounded-full hover:bg-red-700 transition-colors duration-300">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center text-gray-500 py-4">No classes found.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>
</body>
</html>
