<?php
session_start();
require_once "../config/boysdb.php";
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check
// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);

// Initialize search parameters
$selected_class = isset($_GET['class_id']) ? intval($_GET['class_id']) : '';
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query based on filters
$students = [];
if ($selected_class) {
    $sql = "SELECT s.*, c.class_name 
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.id
            WHERE s.class_id = ?";
    $params = [$selected_class];
    
    if ($search_term) {
        $sql .= " AND (s.student_name LIKE ? OR s.roll_no LIKE ?)";
        $search_like = "%$search_term%";
        $params[] = $search_like;
        $params[] = $search_like;
    }
    
    $sql .= " ORDER BY s.student_name";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get single student for print view
if (isset($_GET['print_id'])) {
    $print_id = intval($_GET['print_id']);
    $stmt = $pdo->prepare("SELECT s.*, c.class_name 
                          FROM students s
                          LEFT JOIN classes c ON s.class_id = c.id
                          WHERE s.id = ?");
    $stmt->execute([$print_id]);
    $print_student = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student ID Cards - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        /* Beautiful ID Card Styles */
        .id-card {
            width: 380px;
            background: white;
            border-radius: 25px;
            overflow: hidden;
            position: relative;
            margin: 20px auto;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2), 0 0 0 2px rgba(255,255,255,0.5) inset;
            transition: all 0.3s ease;
        }
        
        .id-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 30px 50px rgba(0,0,0,0.3);
        }
        
        /* Card Header with Diagonal Split */
        .card-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 50%, #3a6ea5 100%);
            color: white;
            padding: 25px 20px;
            text-align: center;
            position: relative;
            clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
        }
        
        .card-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0,0 L100,0 L100,100 L0,100 Z" fill="rgba(255,255,255,0.05)"/></svg>');
            opacity: 0.1;
        }
        
        .school-name {
            font-size: 26px;
            font-weight: 800;
            line-height: 1.2;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        
        .campus-name {
            font-size: 14px;
            opacity: 0.95;
            margin-bottom: 15px;
            font-weight: 500;
            letter-spacing: 0.5px;
        }
        
        .school-number {
            font-size: 16px;
            font-weight: 600;
            background: rgba(255,255,255,0.15);
            padding: 8px 20px;
            border-radius: 50px;
            display: inline-block;
            border: 1px solid rgba(255,255,255,0.3);
            backdrop-filter: blur(5px);
        }
        
        .school-number i {
            margin-right: 8px;
            color: #ffd700;
        }
        
        /* Student Image - Square Style */
        .student-image-container {
            display: flex;
            justify-content: center;
            margin: 20px 0 15px;
            position: relative;
        }
        
        .student-image {
            width: 150px;
            height: 150px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            border: 5px solid white;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            transform: rotate(0deg);
            transition: all 0.3s ease;
        }
        
        .student-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .student-image i {
            font-size: 60px;
            color: #4a5568;
        }
        
        /* Card Details */
        .card-details {
            padding: 5px 25px 25px;
            background: white;
        }
        
        .detail-item {
            background: #f8fafc;
            border-radius: 12px;
            padding: 12px 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            border-left: 5px solid #1e3c72;
            box-shadow: 0 2px 5px rgba(0,0,0,0.03);
            transition: all 0.2s ease;
        }
        
        .detail-item:hover {
            background: #edf2f7;
            transform: translateX(5px);
        }
        
        .detail-icon {
            width: 35px;
            height: 35px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
        
        .detail-icon i {
            color: white;
            font-size: 16px;
        }
        
        .detail-content {
            flex: 1;
        }
        
        .detail-label {
            font-size: 12px;
            color: #718096;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .detail-value {
            font-size: 16px;
            font-weight: 600;
            color: #2d3748;
            line-height: 1.3;
        }
        
        /* Phone Number Special Style */
        .phone-detail {
            border-left-color: #48bb78;
            background: #f0fff4;
        }
        
        .phone-detail .detail-icon {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
        }
        
        /* Card Footer */
        .card-footer {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            padding: 12px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 12px;
            font-weight: 500;
            clip-path: polygon(0 15%, 100% 0, 100% 100%, 0 100%);
            margin-top: -5px;
        }
        
        .footer-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .footer-item i {
            color: #ffd700;
        }
        
        /* Print Button */
        .print-btn {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 14px 35px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            margin: 10px 0 20px;
            box-shadow: 0 10px 20px rgba(30, 60, 114, 0.3);
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .print-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 30px rgba(30, 60, 114, 0.4);
        }
        
        /* Print Styles */
        @media print {
            body * {
                visibility: hidden;
            }
            .print-section, .print-section * {
                visibility: visible;
            }
            .print-section {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }
            .no-print {
                display: none !important;
            }
            .id-card {
                box-shadow: none;
                border: 1px solid #ddd;
                page-break-after: always;
                margin: 0 auto;
            }
        }
        
        .student-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(380px, 1fr));
            gap: 30px;
            justify-items: center;
        }
        
        .filter-card {
            background: rgba(255,255,255,0.95);
            border-radius: 25px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            margin-bottom: 30px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255,255,255,0.5);
        }
        
        .print-container {
            text-align: center;
            margin: 30px 0;
        }
        
        .stats-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 15px 25px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            border: 2px solid rgba(255,255,255,0.5);
        }
    </style>
</head>
<body class="p-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="bg-white rounded-3xl shadow-2xl p-8 mb-8 flex justify-between items-center no-print border-2 border-white/50 backdrop-blur-lg bg-white/95">
            <div>
                <h1 class="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                    <i class="fas fa-id-card mr-3 text-blue-800"></i>
                    Student ID Cards
                </h1>
                <p class="text-gray-600 mt-2 text-lg">Generate beautiful student identification cards</p>
            </div>
            <a href="download.php" class="bg-gray-700 hover:bg-gray-800 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
                <i class="fas fa-arrow-left mr-2"></i>
                Dashboard
            </a>
        </div>

        <!-- Filter Section -->
        <div class="filter-card no-print">
            <form method="GET" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Class Dropdown - Required -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-3">
                            <i class="fas fa-school mr-2 text-blue-700"></i>
                            Select Class <span class="text-red-500">*</span>
                        </label>
                        <select name="class_id" required class="w-full border-2 border-gray-300 rounded-xl p-4 focus:border-blue-600 focus:ring-2 focus:ring-blue-200 bg-white shadow-sm">
                            <option value="">-- Choose a class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $selected_class == $class['id'] ? 'selected' : '' ?>>
                                    Class <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Search Field - Optional -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-3">
                            <i class="fas fa-search mr-2 text-blue-700"></i>
                            Search by Name or Roll No
                        </label>
                        <input type="text" 
                               name="search" 
                               value="<?= htmlspecialchars($search_term) ?>"
                               placeholder="Type to filter..." 
                               class="w-full border-2 border-gray-300 rounded-xl p-4 focus:border-blue-600 focus:ring-2 focus:ring-blue-200 bg-white shadow-sm">
                    </div>
                </div>
                
                <div class="flex gap-4">
                    <button type="submit" class="bg-gradient-to-r from-blue-700 to-purple-700 hover:from-blue-800 hover:to-purple-800 text-white font-bold py-4 px-10 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg text-lg">
                        <i class="fas fa-filter mr-2"></i>
                        Load Students
                    </button>
                    <a href="studentcard.php" class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-4 px-10 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg text-lg">
                        <i class="fas fa-times mr-2"></i>
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Results Stats -->
        <?php if ($selected_class && !empty($students)): ?>
            <div class="stats-card no-print">
                <div class="flex justify-between items-center">
                    <p class="text-gray-800 text-lg">
                        <i class="fas fa-users mr-2 text-blue-700"></i>
                        <span class="font-bold"><?= count($students) ?></span> students found in 
                        <span class="font-bold text-blue-700">Class <?= htmlspecialchars($students[0]['class_name'] ?? '') ?></span>
                    </p>
                    <span class="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold">
                        <i class="fas fa-id-card mr-1"></i>
                        ID Cards Ready
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Print View for Single Card -->
        <?php if (isset($print_student)): ?>
            <div class="print-section">
                <div class="id-card">
                    <div class="card-header">
                        <div class="school-name">Ghazali School</div>
                        <div class="campus-name">Pully Ransikay Campus</div>
                        <div class="school-number">
                            <i class="fas fa-phone-alt"></i> 03043955545
                        </div>
                    </div>
                    
                    <div class="student-image-container">
                        <div class="student-image" style="border-radius: 15px;">
                            <?php if (!empty($print_student['image']) && file_exists("uploads/" . $print_student['image'])): ?>
                                <img src="uploads/<?= htmlspecialchars($print_student['image']) ?>" alt="Student Photo">
                            <?php else: ?>
                                <i class="fas fa-user-graduate"></i>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="card-details">
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-user"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Student Name</div>
                                <div class="detail-value"><?= htmlspecialchars($print_student['student_name']) ?></div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Father's Name</div>
                                <div class="detail-value"><?= htmlspecialchars($print_student['parent_name'] ?? 'N/A') ?></div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-school"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Class</div>
                                <div class="detail-value">Class <?= htmlspecialchars($print_student['class_name']) ?></div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-icon">
                                <i class="fas fa-hashtag"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Roll Number</div>
                                <div class="detail-value"><?= htmlspecialchars($print_student['roll_no']) ?></div>
                            </div>
                        </div>
                        
                        <?php if (!empty($print_student['phone'])): ?>
                        <div class="detail-item phone-detail">
                            <div class="detail-icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <div class="detail-content">
                                <div class="detail-label">Contact Number</div>
                                <div class="detail-value"><?= htmlspecialchars($print_student['phone']) ?></div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-footer">
                        <div class="footer-item">
                            <i class="fas fa-id-card"></i>
                            <span>Student ID Card</span>
                        </div>
                        <div class="footer-item">
                            <i class="fas fa-calendar"></i>
                            <span><?= date('Y') ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="print-container no-print">
                <button onclick="window.print()" class="print-btn">
                    <i class="fas fa-print fa-lg"></i>
                    Print This Card
                </button>
                <a href="studentcard.php?class_id=<?= $selected_class ?>&search=<?= urlencode($search_term) ?>" 
                   class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-4 px-10 rounded-full ml-4 transition-all duration-300 inline-flex items-center gap-2">
                    <i class="fas fa-arrow-left"></i>
                    Back to List
                </a>
            </div>
        <?php endif; ?>

        <!-- Student Cards Grid -->
        <?php if (!isset($print_student) && $selected_class): ?>
            <?php if (empty($students)): ?>
                <div class="bg-white rounded-3xl shadow-2xl p-16 text-center">
                    <i class="fas fa-id-card text-7xl text-gray-400 mb-6"></i>
                    <h3 class="text-3xl font-bold text-gray-700 mb-3">No Students Found</h3>
                    <p class="text-gray-500 text-lg">No students in this class or try adjusting your search</p>
                </div>
            <?php else: ?>
                <div class="student-grid">
                    <?php foreach ($students as $student): ?>
                        <div class="id-card">
                            <div class="card-header">
                                <div class="school-name">Ghazali School</div>
                                <div class="campus-name">Pully Ransikay Campus</div>
                                <div class="school-number">
                                    <i class="fas fa-phone-alt"></i> 03043955545
                                </div>
                            </div>
                            
                            <div class="student-image-container">
                                <div class="student-image" style="border-radius: 15px;">
                                    <?php if (!empty($student['image']) && file_exists("uploads/" . $student['image'])): ?>
                                        <img src="uploads/<?= htmlspecialchars($student['image']) ?>" alt="Student Photo">
                                    <?php else: ?>
                                        <i class="fas fa-user-graduate"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="card-details">
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="detail-content">
                                        <div class="detail-label">Student Name</div>
                                        <div class="detail-value"><?= htmlspecialchars($student['student_name']) ?></div>
                                    </div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-user-tie"></i>
                                    </div>
                                    <div class="detail-content">
                                        <div class="detail-label">Father's Name</div>
                                        <div class="detail-value"><?= htmlspecialchars($student['parent_name'] ?? 'N/A') ?></div>
                                    </div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-school"></i>
                                    </div>
                                    <div class="detail-content">
                                        <div class="detail-label">Class</div>
                                        <div class="detail-value">Class <?= htmlspecialchars($student['class_name']) ?></div>
                                    </div>
                                </div>
                                
                                <div class="detail-item">
                                    <div class="detail-icon">
                                        <i class="fas fa-hashtag"></i>
                                    </div>
                                    <div class="detail-content">
                                        <div class="detail-label">Roll Number</div>
                                        <div class="detail-value"><?= htmlspecialchars($student['roll_no']) ?></div>
                                    </div>
                                </div>
                                
                                <?php if (!empty($student['phone'])): ?>
                                <div class="detail-item phone-detail">
                                    <div class="detail-icon">
                                        <i class="fas fa-phone-alt"></i>
                                    </div>
                                    <div class="detail-content">
                                        <div class="detail-label">Contact Number</div>
                                        <div class="detail-value"><?= htmlspecialchars($student['phone']) ?></div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="card-footer">
                                <div class="footer-item">
                                    <i class="fas fa-id-card"></i>
                                    <span>Student ID</span>
                                </div>
                                <div class="footer-item">
                                    <i class="fas fa-calendar"></i>
                                    <span><?= date('Y') ?></span>
                                </div>
                            </div>
                            
                            <!-- Print Button Below Card -->
                            <div class="text-center pb-5 no-print">
                                <a href="?print_id=<?= $student['id'] ?>&class_id=<?= $selected_class ?>&search=<?= urlencode($search_term) ?>" 
                                   class="inline-flex items-center gap-2 text-blue-700 hover:text-blue-900 font-semibold py-3 px-6 rounded-full transition-all hover:bg-blue-50">
                                    <i class="fas fa-print"></i>
                                    Print Card
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Print All Button - Outside Cards -->
                <div class="print-container no-print">
                    <button onclick="printAllCards()" class="print-btn">
                        <i class="fas fa-print fa-lg"></i>
                        Print All Cards (<?= count($students) ?>)
                    </button>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Initial Message -->
        <?php if (!isset($print_student) && !$selected_class): ?>
            <div class="bg-white rounded-3xl shadow-2xl p-16 text-center">
                <div class="w-32 h-32 bg-gradient-to-r from-blue-700 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-8">
                    <i class="fas fa-id-card text-white text-5xl"></i>
                </div>
                <h3 class="text-4xl font-bold text-gray-800 mb-4">Student ID Card Generator</h3>
                <p class="text-gray-600 text-xl mb-10 max-w-2xl mx-auto">Please select a class to view and print beautiful student identification cards</p>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                    <div class="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-2xl">
                        <div class="w-16 h-16 bg-blue-700 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-school text-white text-2xl"></i>
                        </div>
                        <h4 class="font-bold text-xl mb-2">Step 1</h4>
                        <p class="text-gray-600">Select a class from the dropdown menu</p>
                    </div>
                    <div class="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-2xl">
                        <div class="w-16 h-16 bg-purple-700 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-search text-white text-2xl"></i>
                        </div>
                        <h4 class="font-bold text-xl mb-2">Step 2</h4>
                        <p class="text-gray-600">Search by name or roll number (optional)</p>
                    </div>
                    <div class="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-2xl">
                        <div class="w-16 h-16 bg-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-print text-white text-2xl"></i>
                        </div>
                        <h4 class="font-bold text-xl mb-2">Step 3</h4>
                        <p class="text-gray-600">Print individual cards or all at once</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Auto-submit form when class changes
        document.querySelector('select[name="class_id"]').addEventListener('change', function() {
            if (this.value) {
                this.form.submit();
            }
        });

        // Print all cards function
        function printAllCards() {
            const printWindow = window.open('', '_blank');
            
            const cards = document.querySelectorAll('.id-card');
            let printContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Student ID Cards - Ghazali School</title>
                    <style>
                        * { font-family: 'Poppins', sans-serif; margin: 0; padding: 0; box-sizing: border-box; }
                        body { background: white; padding: 20px; }
                        .id-card {
                            width: 380px;
                            background: white;
                            border-radius: 25px;
                            overflow: hidden;
                            border: 1px solid #e0e0e0;
                            margin: 20px auto;
                            page-break-after: always;
                            box-shadow: none;
                        }
                        .card-header {
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 50%, #3a6ea5 100%);
                            color: white;
                            padding: 25px 20px;
                            text-align: center;
                            clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
                        }
                        .school-name {
                            font-size: 26px;
                            font-weight: 800;
                            text-transform: uppercase;
                            margin-bottom: 5px;
                        }
                        .campus-name {
                            font-size: 14px;
                            opacity: 0.95;
                            margin-bottom: 15px;
                        }
                        .school-number {
                            font-size: 16px;
                            font-weight: 600;
                            background: rgba(255,255,255,0.15);
                            padding: 8px 20px;
                            border-radius: 50px;
                            display: inline-block;
                            border: 1px solid rgba(255,255,255,0.3);
                        }
                        .student-image-container {
                            display: flex;
                            justify-content: center;
                            margin: 20px 0 15px;
                        }
                        .student-image {
                            width: 150px;
                            height: 150px;
                            background: #f5f7fa;
                            border: 5px solid white;
                            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
                            overflow: hidden;
                            border-radius: 15px;
                        }
                        .student-image img {
                            width: 100%;
                            height: 100%;
                            object-fit: cover;
                        }
                        .student-image i {
                            font-size: 60px;
                            color: #4a5568;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            height: 100%;
                        }
                        .card-details {
                            padding: 5px 25px 25px;
                        }
                        .detail-item {
                            background: #f8fafc;
                            border-radius: 12px;
                            padding: 12px 15px;
                            margin-bottom: 10px;
                            display: flex;
                            align-items: center;
                            border-left: 5px solid #1e3c72;
                        }
                        .phone-detail {
                            border-left-color: #48bb78;
                        }
                        .detail-icon {
                            width: 35px;
                            height: 35px;
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                            border-radius: 10px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin-right: 15px;
                        }
                        .phone-detail .detail-icon {
                            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
                        }
                        .detail-icon i {
                            color: white;
                            font-size: 16px;
                        }
                        .detail-label {
                            font-size: 12px;
                            color: #718096;
                            font-weight: 500;
                            text-transform: uppercase;
                        }
                        .detail-value {
                            font-size: 16px;
                            font-weight: 600;
                            color: #2d3748;
                        }
                        .card-footer {
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                            padding: 12px 25px;
                            display: flex;
                            justify-content: space-between;
                            color: white;
                            clip-path: polygon(0 15%, 100% 0, 100% 100%, 0 100%);
                        }
                    </style>
                </head>
                <body>
            `;
            
            cards.forEach(card => {
                // Clone the card and remove any print buttons inside
                const cardClone = card.cloneNode(true);
                const printBtnContainer = cardClone.querySelector('.no-print');
                if (printBtnContainer) {
                    printBtnContainer.remove();
                }
                printContent += cardClone.outerHTML;
            });
            
            printContent += '</body></html>';
            
            printWindow.document.write(printContent);
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
        }
    </script>
</body>
</html>