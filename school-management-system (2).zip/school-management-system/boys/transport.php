<?php
session_start();
require_once "../config/boysdb.php";
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check
// Fetch all transport routes
$stmt = $pdo->query("SELECT * FROM transport_routes ORDER BY 
                     FIELD(status, 'Active', 'Inactive'), 
                     start_time");
$routes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group routes by status
$active_routes = array_filter($routes, function($route) {
    return $route['status'] == 'Active';
});

$inactive_routes = array_filter($routes, function($route) {
    return $route['status'] == 'Inactive';
});

// Get statistics
$total_vehicles = count($routes);
$active_vehicles = count($active_routes);
$total_capacity = array_sum(array_column($routes, 'capacity'));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transport Schedule - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .main-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .header-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }
        
        .transport-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .school-header {
            text-align: center;
            margin-bottom: 30px;
            padding: 30px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border-radius: 15px;
        }
        
        .school-header h1 {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .school-header p {
            font-size: 18px;
            opacity: 0.9;
        }
        
        .route-card {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .route-card:hover {
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-color: #667eea;
        }
        
        .route-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 2px dashed #e0e0e0;
        }
        
        .vehicle-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 30px;
            font-size: 13px;
            font-weight: 600;
        }
        
        .status-active {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .status-inactive {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .route-point {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 12px;
        }
        
        .point-marker {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        
        .point-start {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .point-end {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .time-slot {
            background: #f7fafc;
            padding: 15px;
            border-radius: 12px;
            margin: 15px 0;
        }
        
        .day-tag {
            background: #e9ecef;
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
            margin: 0 5px 5px 0;
        }
        
        .driver-info {
            background: #f8fafc;
            padding: 12px;
            border-radius: 10px;
            margin-top: 10px;
        }
        
        .print-btn {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 15px 50px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            margin-top: 30px;
        }
        
        .print-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(30, 60, 114, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: scale(1.05);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .section-title {
            font-size: 24px;
            font-weight: 700;
            margin: 30px 0 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
            display: inline-block;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .transport-card, .transport-card * {
                visibility: visible;
            }
            .transport-card {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
                background: white;
            }
            .no-print {
                display: none !important;
            }
            .school-header {
                background: #1e3c72;
                color: white;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .route-card {
                break-inside: avoid;
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Header -->
        <div class="header-card flex justify-between items-center no-print">
            <div>
                <h1 class="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                    <i class="fas fa-bus mr-3 text-orange-600"></i>
                    Transport Schedule
                </h1>
                <p class="text-gray-600 mt-1">Complete transport routes and timings</p>
            </div>
            <div class="flex gap-3">
                <a href="download.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i>
                    Dashboard
                </a>
                <a href="manage-transport.php" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full">
                    <i class="fas fa-plus-circle"></i>
                    Manage Routes
                </a>
            </div>
        </div>

        <!-- Transport Schedule Card (Printable) -->
        <div class="transport-card" id="transport-content">
            <!-- School Header -->
            <div class="school-header">
                <h1>Ghazali School</h1>
                <p>Pully Ransikay Campus | 03043955545</p>
                <h2 class="text-xl mt-3">Transport Schedule & Route Information</h2>
            </div>

            <!-- Statistics -->
            <div class="stats-grid no-print">
                <div class="stat-card">
                    <div class="stat-value"><?= $total_vehicles ?></div>
                    <div class="stat-label">Total Vehicles</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= $active_vehicles ?></div>
                    <div class="stat-label">Active Routes</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= $total_capacity ?></div>
                    <div class="stat-label">Total Capacity</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value"><?= count($inactive_routes) ?></div>
                    <div class="stat-label">Inactive Routes</div>
                </div>
            </div>

            <!-- Active Routes -->
            <?php if (!empty($active_routes)): ?>
                <h3 class="section-title">
                    <i class="fas fa-check-circle text-green-600 mr-2"></i>
                    Active Routes (<?= count($active_routes) ?>)
                </h3>
                
                <?php foreach ($active_routes as $route): 
                    $days = explode(',', $route['route_days']);
                ?>
                    <div class="route-card">
                        <!-- Route Header -->
                        <div class="route-header">
                            <div class="flex items-center gap-4">
                                <span class="vehicle-badge">
                                    <i class="fas fa-bus mr-2"></i>
                                    <?= htmlspecialchars($route['vehicle_no']) ?>
                                </span>
                                <span class="status-badge status-active">
                                    <i class="fas fa-circle mr-1"></i>
                                    <?= $route['status'] ?>
                                </span>
                            </div>
                            <div class="text-right">
                                <span class="text-sm text-gray-500">
                                    <i class="fas fa-users mr-1"></i>
                                    Capacity: <?= $route['capacity'] ?> seats
                                </span>
                            </div>
                        </div>

                        <!-- Route Points -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <div class="route-point">
                                    <div class="point-marker point-start">
                                        <i class="fas fa-play"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm text-gray-500">Start Point</div>
                                        <div class="font-semibold"><?= htmlspecialchars($route['start_point']) ?></div>
                                    </div>
                                </div>
                                
                                <div class="route-point">
                                    <div class="point-marker point-end">
                                        <i class="fas fa-flag-checkered"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm text-gray-500">End Point</div>
                                        <div class="font-semibold"><?= htmlspecialchars($route['end_point']) ?></div>
                                    </div>
                                </div>
                            </div>

                            <!-- Time Information -->
                            <div class="time-slot">
                                <div class="grid grid-cols-2 gap-4">
                                    <div class="text-center">
                                        <div class="text-sm text-gray-500">Start Time</div>
                                        <div class="text-xl font-bold text-green-600">
                                            <?= date('h:i A', strtotime($route['start_time'])) ?>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-sm text-gray-500">End Time</div>
                                        <div class="text-xl font-bold text-red-600">
                                            <?= date('h:i A', strtotime($route['end_time'])) ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $start = new DateTime($route['start_time']);
                                $end = new DateTime($route['end_time']);
                                $duration = $start->diff($end);
                                $duration_text = '';
                                if ($duration->h > 0) $duration_text .= $duration->h . ' hour' . ($duration->h > 1 ? 's' : '');
                                if ($duration->i > 0) {
                                    if ($duration->h > 0) $duration_text .= ' ';
                                    $duration_text .= $duration->i . ' min';
                                }
                                ?>
                                <div class="text-center mt-2 text-sm text-gray-500">
                                    <i class="far fa-hourglass mr-1"></i>
                                    Journey Time: <?= $duration_text ?>
                                </div>
                            </div>
                        </div>

                        <!-- Operating Days -->
                        <div class="mt-4">
                            <div class="text-sm font-semibold mb-2">Operating Days:</div>
                            <div>
                                <?php foreach ($days as $day): ?>
                                    <span class="day-tag">
                                        <?= $day ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Driver Information -->
                        <div class="driver-info">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="flex items-center gap-3">
                                    <i class="fas fa-user-circle text-2xl text-blue-600"></i>
                                    <div>
                                        <div class="text-sm text-gray-500">Driver Name</div>
                                        <div class="font-semibold"><?= htmlspecialchars($route['driver_name']) ?></div>
                                    </div>
                                </div>
                                <div class="flex items-center gap-3">
                                    <i class="fas fa-phone-alt text-2xl text-green-600"></i>
                                    <div>
                                        <div class="text-sm text-gray-500">Contact Number</div>
                                        <div class="font-semibold"><?= htmlspecialchars($route['driver_phone']) ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <!-- Inactive Routes -->
            <?php if (!empty($inactive_routes)): ?>
                <h3 class="section-title mt-8">
                    <i class="fas fa-minus-circle text-red-600 mr-2"></i>
                    Inactive Routes (<?= count($inactive_routes) ?>)
                </h3>
                
                <?php foreach ($inactive_routes as $route): 
                    $days = explode(',', $route['route_days']);
                ?>
                    <div class="route-card opacity-75">
                        <!-- Route Header -->
                        <div class="route-header">
                            <div class="flex items-center gap-4">
                                <span class="vehicle-badge" style="background: #6c757d;">
                                    <i class="fas fa-bus mr-2"></i>
                                    <?= htmlspecialchars($route['vehicle_no']) ?>
                                </span>
                                <span class="status-badge status-inactive">
                                    <i class="fas fa-circle mr-1"></i>
                                    <?= $route['status'] ?>
                                </span>
                            </div>
                        </div>

                        <!-- Route Points -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <div class="route-point">
                                    <div class="point-marker point-start">
                                        <i class="fas fa-play"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm text-gray-500">Start Point</div>
                                        <div class="font-semibold"><?= htmlspecialchars($route['start_point']) ?></div>
                                    </div>
                                </div>
                                <div class="route-point">
                                    <div class="point-marker point-end">
                                        <i class="fas fa-flag-checkered"></i>
                                    </div>
                                    <div>
                                        <div class="text-sm text-gray-500">End Point</div>
                                        <div class="font-semibold"><?= htmlspecialchars($route['end_point']) ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="time-slot">
                                <div class="grid grid-cols-2 gap-4">
                                    <div class="text-center">
                                        <div class="text-sm text-gray-500">Start Time</div>
                                        <div class="text-xl font-bold"><?= date('h:i A', strtotime($route['start_time'])) ?></div>
                                    </div>
                                    <div class="text-center">
                                        <div class="text-sm text-gray-500">End Time</div>
                                        <div class="text-xl font-bold"><?= date('h:i A', strtotime($route['end_time'])) ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (empty($routes)): ?>
                <div class="text-center py-12">
                    <i class="fas fa-bus text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500 text-lg">No transport routes found.</p>
                    <p class="text-gray-400">Add routes in Transport Management section.</p>
                </div>
            <?php endif; ?>

            <!-- Footer Note -->
            <div class="mt-8 text-center text-gray-500 text-sm">
                <p>Generated on: <?= date('l, jS F Y, h:i A') ?></p>
                <p>For any queries, contact Transport Department</p>
            </div>
        </div>

        <!-- Print Button -->
        <div class="text-center no-print">
            <button onclick="printTransport()" class="print-btn">
                <i class="fas fa-print fa-lg"></i>
                Print Transport Schedule
            </button>
        </div>
    </div>

    <script>
        function printTransport() {
            const printContent = document.getElementById('transport-content').innerHTML;
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Transport Schedule - Ghazali School</title>
                    <style>
                        * {
                            font-family: 'Poppins', sans-serif;
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        body {
                            padding: 30px;
                            background: white;
                        }
                        .school-header {
                            text-align: center;
                            margin-bottom: 30px;
                            padding: 30px;
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                            color: white;
                            border-radius: 15px;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .school-header h1 { font-size: 36px; margin-bottom: 10px; }
                        .school-header p { font-size: 18px; opacity: 0.9; }
                        .section-title {
                            font-size: 24px;
                            font-weight: 700;
                            margin: 30px 0 20px;
                            padding-bottom: 10px;
                            border-bottom: 3px solid #667eea;
                        }
                        .route-card {
                            border: 2px solid #e0e0e0;
                            border-radius: 15px;
                            padding: 20px;
                            margin-bottom: 20px;
                            page-break-inside: avoid;
                        }
                        .route-header {
                            display: flex;
                            justify-content: space-between;
                            align-items: center;
                            margin-bottom: 15px;
                            padding-bottom: 15px;
                            border-bottom: 2px dashed #e0e0e0;
                        }
                        .vehicle-badge {
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            color: white;
                            padding: 8px 20px;
                            border-radius: 50px;
                            font-size: 18px;
                            font-weight: 600;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .status-active {
                            background: #c6f6d5;
                            color: #22543d;
                            padding: 5px 15px;
                            border-radius: 30px;
                        }
                        .grid {
                            display: grid;
                            grid-template-columns: repeat(2, 1fr);
                            gap: 20px;
                        }
                        .route-point {
                            display: flex;
                            align-items: center;
                            gap: 15px;
                            margin-bottom: 12px;
                        }
                        .point-marker {
                            width: 40px;
                            height: 40px;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                        }
                        .point-start { background: #c6f6d5; color: #22543d; }
                        .point-end { background: #fed7d7; color: #742a2a; }
                        .time-slot {
                            background: #f7fafc;
                            padding: 15px;
                            border-radius: 12px;
                        }
                        .day-tag {
                            background: #e9ecef;
                            padding: 5px 12px;
                            border-radius: 30px;
                            font-size: 12px;
                            display: inline-block;
                            margin: 0 5px 5px 0;
                        }
                        .driver-info {
                            background: #f8fafc;
                            padding: 12px;
                            border-radius: 10px;
                            margin-top: 10px;
                        }
                        @media print {
                            body { padding: 20px; }
                        }
                    </style>
                </head>
                <body>
                    ${printContent}
                </body>
                </html>
            `);
            
            printWindow.document.close();
            printWindow.focus();
            
            setTimeout(() => {
                printWindow.print();
            }, 500);
        }
    </script>
</body>
</html>