<?php
require_once('../config/boysdb.php');
session_start();
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check

// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);

// AJAX endpoint for fetching students by class
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_students') {
    header('Content-Type: application/json');
    $class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    
    if ($class_id > 0) {
        $stmt = $pdo->prepare("SELECT id, student_name, roll_no FROM students WHERE class_id = ? ORDER BY student_name");
        $stmt->execute([$class_id]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($students);
    } else {
        echo json_encode([]);
    }
    exit();
}

// Initialize filter parameters
$filter_class = isset($_GET['class_id']) ? intval($_GET['class_id']) : '';
$filter_student = isset($_GET['student_id']) ? intval($_GET['student_id']) : '';
$filter_search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query for fee records - FIXED COLLATION ISSUE
$query = "SELECT f.* FROM fees f WHERE 1=1";
$params = [];

if ($filter_class) {
    // Get class name first to avoid collation issues
    $class_stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $class_stmt->execute([$filter_class]);
    $class_name = $class_stmt->fetchColumn();
    
    if ($class_name) {
        $query .= " AND f.class_name = ?";
        $params[] = $class_name;
    }
}

if ($filter_student) {
    $query .= " AND f.student_id = ?";
    $params[] = $filter_student;
}

if ($filter_search) {
    $query .= " AND (f.student_name LIKE ? OR f.roll_no LIKE ?)";
    $search_term = "%$filter_search%";
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " ORDER BY f.due_date ASC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$fee_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate summary statistics
$total_fees = 0;
$total_paid = 0;
$total_remaining = 0;
$paid_count = 0;
$partial_count = 0;
$pending_count = 0;

foreach ($fee_records as $record) {
    $total_fees += $record['total_amount'];
    $total_paid += $record['paid_amount'];
    $total_remaining += $record['remaining_amount'];
    
    if ($record['status'] == 'Paid') $paid_count++;
    elseif ($record['status'] == 'Partially Paid') $partial_count++;
    elseif ($record['status'] == 'Pending') $pending_count++;
}

// Get class name for display
$class_display = '';
if ($filter_class) {
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$filter_class]);
    $class_display = $stmt->fetchColumn();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Reports - Ghazali School</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .main-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .filter-card {
            background: rgba(255,255,255,0.95);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }
        
        .report-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }
        
        .school-header {
            text-align: center;
            margin-bottom: 30px;
            padding: 30px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border-radius: 15px;
        }
        
        .school-header h1 {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .school-header p {
            font-size: 18px;
            opacity: 0.9;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
        }
        
        .stat-card.green {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
        }
        
        .stat-card.orange {
            background: linear-gradient(135deg, #f6ad55 0%, #dd6b20 100%);
        }
        
        .stat-card.red {
            background: linear-gradient(135deg, #f56565 0%, #c53030 100%);
        }
        
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        
        .status-paid {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .status-partial {
            background: #feebc8;
            color: #744210;
        }
        
        .status-pending {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .fees-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .fees-table th {
            background: #1e3c72;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        .fees-table td {
            padding: 12px 15px;
            border: 1px solid #e0e0e0;
        }
        
        .fees-table tr:nth-child(even) {
            background: #f8fafc;
        }
        
        .amount {
            font-weight: 600;
        }
        
        .total-row {
            background: #e9ecef;
            font-weight: 700;
        }
        
        .print-btn {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border: none;
            padding: 15px 50px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            margin-top: 30px;
        }
        
        .print-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(30, 60, 114, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 50px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
            transform: scale(1.05);
        }
        
        .summary-box {
            background: #f8fafc;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .student-select {
            width: 100%;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 12px;
            font-size: 14px;
        }
        
        .student-select:focus {
            border-color: #667eea;
            outline: none;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            .report-card, .report-card * {
                visibility: visible;
            }
            .report-card {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                padding: 20px;
                background: white;
            }
            .no-print {
                display: none !important;
            }
            .school-header {
                background: #1e3c72;
                color: white;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .fees-table th {
                background: #1e3c72;
                color: white;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Header -->
        <div class="filter-card flex justify-between items-center no-print">
            <div>
                <h1 class="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-900 to-purple-900">
                    <i class="fas fa-file-invoice-dollar mr-3 text-green-600"></i>
                    Fee Reports
                </h1>
                <p class="text-gray-600 mt-1">View and print fee records by class and student</p>
            </div>
            <div class="flex gap-3">
                <a href="download.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i>
                    Dashboard
                </a>
                <a href="manage-fees.php" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full">
                    <i class="fas fa-plus-circle"></i>
                    Manage Fees
                </a>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="filter-card no-print">
            <form method="GET" id="filterForm" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <!-- Class Dropdown -->
                    <div>
                        <label class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-school mr-2 text-blue-600"></i>
                            Select Class
                        </label>
                        <select name="class_id" id="class_id" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
                            <option value="">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $filter_class == $class['id'] ? 'selected' : '' ?>>
                                    Class <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Student Dropdown (Auto-populates) -->
                    <div>
                        <label class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-user-graduate mr-2 text-purple-600"></i>
                            Select Student
                        </label>
                        <select name="student_id" id="student_id" class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
                            <option value="">All Students</option>
                        </select>
                        <div id="student-loading" class="text-sm text-gray-500 mt-1 hidden">
                            <i class="fas fa-spinner fa-spin mr-2"></i>Loading students...
                        </div>
                    </div>
                    
                    <!-- Search Field -->
                    <div>
                        <label class="block font-semibold mb-2 text-gray-700">
                            <i class="fas fa-search mr-2 text-blue-600"></i>
                            Search by Name or Roll No
                        </label>
                        <input type="text" name="search" id="search" value="<?= htmlspecialchars($filter_search) ?>" 
                               placeholder="Type to search..." 
                               class="w-full border-2 border-gray-300 rounded-xl p-3 focus:outline-none focus:border-blue-500">
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="flex items-end gap-3">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl transition-all">
                            <i class="fas fa-filter mr-2"></i>Apply
                        </button>
                        <a href="fees.php" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-xl transition-all">
                            <i class="fas fa-times"></i> Clear
                        </a>
                    </div>
                </div>
            </form>
        </div>

        <!-- Fee Report Card (Printable) -->
        <div class="report-card" id="report-content">
            <!-- School Header -->
            <div class="school-header">
                <h1>Ghazali School</h1>
                <p>Pully Ransikay Campus | 03043955545</p>
                <h2 class="text-xl mt-3">Fee Collection Report</h2>
                <?php if ($class_display): ?>
                    <p class="text-lg mt-2">Class: <?= htmlspecialchars($class_display) ?></p>
                <?php endif; ?>
                <?php if ($filter_student): 
                    $stmt = $pdo->prepare("SELECT student_name FROM students WHERE id = ?");
                    $stmt->execute([$filter_student]);
                    $student_name = $stmt->fetchColumn();
                ?>
                    <p class="text-lg">Student: <?= htmlspecialchars($student_name) ?></p>
                <?php endif; ?>
                <?php if ($filter_search): ?>
                    <p class="text-lg">Search: "<?= htmlspecialchars($filter_search) ?>"</p>
                <?php endif; ?>
            </div>

            <?php if (!empty($fee_records)): ?>
                <!-- Statistics -->
                <div class="stats-grid no-print">
                    <div class="stat-card">
                        <div class="stat-value"><?= count($fee_records) ?></div>
                        <div class="stat-label">Total Records</div>
                    </div>
                    <div class="stat-card green">
                        <div class="stat-value">Rs. <?= number_format($total_paid, 2) ?></div>
                        <div class="stat-label">Total Collected</div>
                    </div>
                    <div class="stat-card orange">
                        <div class="stat-value">Rs. <?= number_format($total_remaining, 2) ?></div>
                        <div class="stat-label">Total Remaining</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value">Rs. <?= number_format($total_fees, 2) ?></div>
                        <div class="stat-label">Total Fees</div>
                    </div>
                </div>

                <!-- Status Summary -->
                <div class="grid grid-cols-3 gap-4 mb-6">
                    <div class="bg-green-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-green-700"><?= $paid_count ?></div>
                        <div class="text-sm text-gray-600">Paid</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-yellow-700"><?= $partial_count ?></div>
                        <div class="text-sm text-gray-600">Partially Paid</div>
                    </div>
                    <div class="bg-red-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-red-700"><?= $pending_count ?></div>
                        <div class="text-sm text-gray-600">Pending</div>
                    </div>
                </div>

                <!-- Fees Table -->
                <table class="fees-table">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Student Name</th>
                            <th>Roll No</th>
                            <th>Total Fee</th>
                            <th>Paid</th>
                            <th>Remaining</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $serial = 1;
                        $grand_total = 0;
                        $grand_paid = 0;
                        $grand_remaining = 0;
                        
                        foreach ($fee_records as $row): 
                            $grand_total += $row['total_amount'];
                            $grand_paid += $row['paid_amount'];
                            $grand_remaining += $row['remaining_amount'];
                        ?>
                            <tr>
                                <td><?= $serial++ ?></td>
                                <td class="font-medium"><?= htmlspecialchars($row['student_name']); ?></td>
                                <td><?= htmlspecialchars($row['roll_no']); ?></td>
                                <td class="amount">Rs. <?= number_format($row['total_amount'], 2); ?></td>
                                <td class="amount text-green-600">Rs. <?= number_format($row['paid_amount'], 2); ?></td>
                                <td class="amount text-red-600">Rs. <?= number_format($row['remaining_amount'], 2); ?></td>
                                <td><?= date('d M Y', strtotime($row['due_date'])); ?></td>
                                <td>
                                    <span class="status-badge 
                                        <?= $row['status'] == 'Paid' ? 'status-paid' : 
                                            ($row['status'] == 'Partially Paid' ? 'status-partial' : 'status-pending'); ?>">
                                        <?= $row['status']; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <!-- Grand Total Row -->
                        <tr class="total-row">
                            <td colspan="3" class="text-right font-bold">GRAND TOTAL:</td>
                            <td class="amount">Rs. <?= number_format($grand_total, 2); ?></td>
                            <td class="amount text-green-700">Rs. <?= number_format($grand_paid, 2); ?></td>
                            <td class="amount text-red-700">Rs. <?= number_format($grand_remaining, 2); ?></td>
                            <td colspan="2"></td>
                        </tr>
                    </tbody>
                </table>

                <!-- Summary by Status -->
                <div class="summary-box mt-6">
                    <h3 class="font-bold text-lg mb-3">Summary by Status:</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <span class="status-badge status-paid mr-2">Paid</span>
                            <span class="font-semibold"><?= $paid_count ?> students</span>
                            <span class="text-green-600 block mt-1">Rs. <?php 
                                $paid_total = 0;
                                foreach ($fee_records as $r) {
                                    if ($r['status'] == 'Paid') $paid_total += $r['total_amount'];
                                }
                                echo number_format($paid_total, 2);
                            ?></span>
                        </div>
                        <div>
                            <span class="status-badge status-partial mr-2">Partially Paid</span>
                            <span class="font-semibold"><?= $partial_count ?> students</span>
                            <span class="text-yellow-600 block mt-1">Rs. <?php 
                                $partial_total = 0;
                                foreach ($fee_records as $r) {
                                    if ($r['status'] == 'Partially Paid') $partial_total += $r['remaining_amount'];
                                }
                                echo number_format($partial_total, 2);
                            ?> remaining</span>
                        </div>
                        <div>
                            <span class="status-badge status-pending mr-2">Pending</span>
                            <span class="font-semibold"><?= $pending_count ?> students</span>
                            <span class="text-red-600 block mt-1">Rs. <?php 
                                $pending_total = 0;
                                foreach ($fee_records as $r) {
                                    if ($r['status'] == 'Pending') $pending_total += $r['total_amount'];
                                }
                                echo number_format($pending_total, 2);
                            ?> due</span>
                        </div>
                    </div>
                </div>

                <!-- Collection Summary -->
                <div class="summary-box mt-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-gray-600">Collection Rate:</p>
                            <p class="text-2xl font-bold text-green-600">
                                <?= $total_fees > 0 ? round(($total_paid / $total_fees) * 100, 2) : 0 ?>%
                            </p>
                        </div>
                        <div>
                            <p class="text-gray-600">Pending Rate:</p>
                            <p class="text-2xl font-bold text-red-600">
                                <?= $total_fees > 0 ? round(($total_remaining / $total_fees) * 100, 2) : 0 ?>%
                            </p>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-file-invoice text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500 text-lg">No fee records found.</p>
                    <p class="text-gray-400">Try adjusting your filters or add fee records in Manage Fees.</p>
                </div>
            <?php endif; ?>

            <!-- Footer Note -->
            <div class="mt-8 text-center text-gray-500 text-sm">
                <p>Generated on: <?= date('l, jS F Y, h:i A') ?></p>
                <p>This is a computer-generated report. No signature required.</p>
            </div>
        </div>

        <!-- Print Button -->
        <?php if (!empty($fee_records)): ?>
            <div class="text-center no-print">
                <button onclick="printReport()" class="print-btn">
                    <i class="fas fa-print fa-lg"></i>
                    Print Fee Report
                </button>
            </div>
        <?php endif; ?>
    </div>

    <script>
        $(document).ready(function() {
            // Load students when class is selected
            $('#class_id').change(function() {
                var classId = $(this).val();
                
                if (classId) {
                    $('#student_id').prop('disabled', true);
                    $('#student-loading').removeClass('hidden');
                    
                    $.ajax({
                        url: window.location.href,
                        type: 'GET',
                        dataType: 'json',
                        data: {
                            ajax: 'get_students',
                            class_id: classId
                        },
                        success: function(students) {
                            var options = '<option value="">All Students</option>';
                            
                            if (students.length > 0) {
                                $.each(students, function(index, student) {
                                    options += '<option value="' + student.id + '">' + student.student_name + ' (Roll: ' + student.roll_no + ')</option>';
                                });
                                $('#student_id').prop('disabled', false);
                            } else {
                                options = '<option value="">No students found in this class</option>';
                            }
                            
                            $('#student_id').html(options);
                            $('#student-loading').addClass('hidden');
                        },
                        error: function() {
                            $('#student_id').html('<option value="">Error loading students</option>');
                            $('#student-loading').addClass('hidden');
                        }
                    });
                } else {
                    $('#student_id').html('<option value="">All Students</option>');
                    $('#student_id').prop('disabled', false);
                }
            });

            // Auto-submit when student is selected
            $('#student_id').change(function() {
                $('#filterForm').submit();
            });

            // Auto-submit on search (with debounce)
            let searchTimeout;
            $('#search').on('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    $('#filterForm').submit();
                }, 500);
            });

            // Trigger class change on page load if class is selected
            <?php if ($filter_class): ?>
                $('#class_id').trigger('change');
                
                // Set selected student if any
                <?php if ($filter_student): ?>
                    setTimeout(function() {
                        $('#student_id').val(<?= $filter_student ?>);
                    }, 500);
                <?php endif; ?>
            <?php endif; ?>
        });

        function printReport() {
            const printContent = document.getElementById('report-content').innerHTML;
            const printWindow = window.open('', '_blank');
            
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Fee Report - Ghazali School</title>
                    <style>
                        * {
                            font-family: 'Poppins', sans-serif;
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        body {
                            padding: 30px;
                            background: white;
                        }
                        .school-header {
                            text-align: center;
                            margin-bottom: 30px;
                            padding: 30px;
                            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                            color: white;
                            border-radius: 15px;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .school-header h1 { font-size: 36px; margin-bottom: 10px; }
                        .school-header p { font-size: 18px; opacity: 0.9; }
                        .fees-table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                        }
                        .fees-table th {
                            background: #1e3c72;
                            color: white;
                            padding: 15px;
                            text-align: left;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .fees-table td {
                            padding: 12px 15px;
                            border: 1px solid #e0e0e0;
                        }
                        .fees-table tr:nth-child(even) {
                            background: #f8fafc;
                        }
                        .total-row {
                            background: #e9ecef;
                            font-weight: 700;
                        }
                        .status-badge {
                            padding: 4px 12px;
                            border-radius: 30px;
                            font-size: 12px;
                            font-weight: 600;
                            display: inline-block;
                        }
                        .status-paid {
                            background: #c6f6d5;
                            color: #22543d;
                        }
                        .status-partial {
                            background: #feebc8;
                            color: #744210;
                        }
                        .status-pending {
                            background: #fed7d7;
                            color: #742a2a;
                        }
                        .amount {
                            font-weight: 600;
                        }
                        .summary-box {
                            background: #f8fafc;
                            border-radius: 10px;
                            padding: 15px;
                            margin-top: 20px;
                        }
                        .grid {
                            display: grid;
                            gap: 20px;
                        }
                        .grid-cols-3 {
                            grid-template-columns: repeat(3, 1fr);
                        }
                        .grid-cols-2 {
                            grid-template-columns: repeat(2, 1fr);
                        }
                        @media print {
                            body { padding: 20px; }
                        }
                    </style>
                </head>
                <body>
                    ${printContent}
                </body>
                </html>
            `);
            
            printWindow.document.close();
            printWindow.focus();
            
            setTimeout(() => {
                printWindow.print();
            }, 500);
        }
    </script>
</body>
</html>