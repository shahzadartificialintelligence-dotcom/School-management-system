<?php
session_start();
require_once "../config/boysdb.php";
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check

$message = '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Center - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .download-card {
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
        }
        
        .download-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }
        
        .download-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .download-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .coming-soon {
            position: relative;
            overflow: hidden;
        }
        
        .coming-soon::after {
            content: 'Coming Soon';
            position: absolute;
            top: 10px;
            right: -30px;
            background: #f59e0b;
            color: white;
            padding: 5px 30px;
            transform: rotate(45deg);
            font-size: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body class="p-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="bg-white rounded-2xl shadow-xl p-8 mb-8">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-4xl font-extrabold text-gray-800 mb-2">
                        <i class="fas fa-download text-blue-600 mr-3"></i>
                        Download Center
                    </h1>
                    <p class="text-gray-600">Download various documents and reports</p>
                </div>
                <a href="boys_dashboard.php" class="bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Back to Dashboard
                </a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-8 rounded-lg shadow" role="alert">
                <p><?= htmlspecialchars($message) ?></p>
            </div>
        <?php endif; ?>

        <!-- Download Cards Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            <!-- Student ID Card Download -->
            <div class="download-card bg-white rounded-2xl shadow-xl p-8 text-center">
                <div class="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-id-card text-5xl text-blue-600"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">Student ID Card</h3>
                <p class="text-gray-600 mb-6">Download student identification cards</p>
                <a href="studentcard.php">
                <button 
                        class="download-btn text-white font-bold py-3 px-8 rounded-full inline-flex items-center gap-3">
                    <i class="fas fa-download"></i>
                    Download ID Card
                </button></a>
                <p class="text-xs text-gray-500 mt-4">PDF format • Individual/Bulk download</p>
            </div>

            <!-- Class Timetable Download -->
            <div class="download-card bg-white rounded-2xl shadow-xl p-8 text-center">
                <div class="w-24 h-24 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-calendar-alt text-5xl text-purple-600"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">Class Timetable</h3>
                <p class="text-gray-600 mb-6">Download class-wise timetables</p>
                <a href="timetable.php">
                <button
                        class="download-btn text-white font-bold py-3 px-8 rounded-full inline-flex items-center gap-3">
                    <i class="fas fa-download"></i>
                    Download Timetable
                </button></a>
                <p class="text-xs text-gray-500 mt-4">PDF/Excel format • Class-wise</p>
            </div>

            <!-- Fee Challan Download -->
            <div class="download-card bg-white rounded-2xl shadow-xl p-8 text-center">
                <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-file-invoice-dollar text-5xl text-green-600"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">Fee Challan</h3>
                <p class="text-gray-600 mb-6">Download student fee challans</p>
                <a href="fees.php">
                <button  
                        class="download-btn text-white font-bold py-3 px-8 rounded-full inline-flex items-center gap-3">
                    <i class="fas fa-download"></i>
                    Download Fee Challan
                </button></a>
                <p class="text-xs text-gray-500 mt-4">PDF format • Monthly/Yearly</p>
            </div>

            <!-- Exam Timetable Download -->
            <div class="download-card bg-white rounded-2xl shadow-xl p-8 text-center">
                <div class="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-pen-to-square text-5xl text-yellow-600"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">Exam Timetable</h3>
                <p class="text-gray-600 mb-6">Download examination schedules</p>
                <a href="exam-timetable.php">
                <button 
                        class="download-btn text-white font-bold py-3 px-8 rounded-full inline-flex items-center gap-3">
                    <i class="fas fa-download"></i>
                    Download Exam Schedule
                </button></a>
                <p class="text-xs text-gray-500 mt-4">PDF format • Term-wise</p>
            </div>

            <!-- Transport Route Download -->
            <div class="download-card bg-white rounded-2xl shadow-xl p-8 text-center">
                <div class="w-24 h-24 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-bus text-5xl text-orange-600"></i>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">Transport Routes</h3>
                <p class="text-gray-600 mb-6">Download transport route details</p>
                <a href="transport.php">
                <button  
                        class="download-btn text-white font-bold py-3 px-8 rounded-full inline-flex items-center gap-3">
                    <i class="fas fa-download"></i>
                    Download Routes
                </button>
                <p class="text-xs text-gray-500 mt-4">PDF format • Route-wise</p>
            </div>

        
        </div>

        <!-- Quick Stats Section -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mt-12">
            <div class="bg-white rounded-xl shadow-lg p-6 text-center">
                <div class="text-3xl font-bold text-blue-600 mb-2">150+</div>
                <div class="text-gray-600">Student Cards</div>
            </div>
            <div class="bg-white rounded-xl shadow-lg p-6 text-center">
                <div class="text-3xl font-bold text-purple-600 mb-2">12</div>
                <div class="text-gray-600">Class Timetables</div>
            </div>
            <div class="bg-white rounded-xl shadow-lg p-6 text-center">
                <div class="text-3xl font-bold text-green-600 mb-2">300+</div>
                <div class="text-gray-600">Fee Challans</div>
            </div>
            <div class="bg-white rounded-xl shadow-lg p-6 text-center">
                <div class="text-3xl font-bold text-orange-600 mb-2">6</div>
                <div class="text-gray-600">Exam Schedules</div>
            </div>
        </div>

        <!-- Download History (Optional) -->
        <div class="bg-white rounded-2xl shadow-xl p-8 mt-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-history mr-3 text-blue-600"></i>
                Recent Downloads
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Document Type</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Downloaded By</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date & Time</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr class="hover:bg-gray-50">
                            <td class="py-3 px-4 text-sm text-gray-800">
                                <i class="fas fa-id-card text-blue-600 mr-2"></i>
                                Student ID Card (Class 10)
                            </td>
                            <td class="py-3 px-4 text-sm text-gray-600">Admin</td>
                            <td class="py-3 px-4 text-sm text-gray-600">2024-02-24 10:30 AM</td>
                            <td class="py-3 px-4">
                                <span class="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-1 rounded-full">Completed</span>
                            </td>
                        </tr>
                        <tr class="hover:bg-gray-50">
                            <td class="py-3 px-4 text-sm text-gray-800">
                                <i class="fas fa-calendar-alt text-purple-600 mr-2"></i>
                                Class Timetable (Grade 9)
                            </td>
                            <td class="py-3 px-4 text-sm text-gray-600">Admin</td>
                            <td class="py-3 px-4 text-sm text-gray-600">2024-02-24 09:15 AM</td>
                            <td class="py-3 px-4">
                                <span class="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-1 rounded-full">Completed</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- JavaScript for future functionality -->
    <script>
        // These functions will be implemented later
        function downloadStudentCard() {
            // Will be implemented later
            alert('Student Card download feature coming soon!');
        }
        
        function downloadTimetable() {
            // Will be implemented later
            alert('Timetable download feature coming soon!');
        }
        
        function downloadFees() {
            // Will be implemented later
            alert('Fees download feature coming soon!');
        }
        
        function downloadExamTimetable() {
            // Will be implemented later
            alert('Exam Timetable download feature coming soon!');
        }
        
        function downloadTransport() {
            // Will be implemented later
            alert('Transport download feature coming soon!');
        }
    </script>
</body>
</html>