<?php
session_start();
require_once(__DIR__ . '/../config/boysdb.php'); // Uses $conn from config
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check 

// Fetch subjects with class names
$stmt = $conn->prepare("
    SELECT subjects.id, subjects.subject_name, classes.class_name
    FROM subjects
    JOIN classes ON subjects.class_id = classes.id
");
$stmt->execute();
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch classes for dropdown
$class_stmt = $conn->query("SELECT id, class_name FROM classes");
$classes = $class_stmt->fetchAll(PDO::FETCH_ASSOC);

// Add subject
if (isset($_POST['add_subject'])) {
    $subject_name = trim($_POST['subject_name']);
    $class_id = $_POST['class_id'];

    if (!empty($subject_name) && !empty($class_id)) {
        $insert = $conn->prepare("INSERT INTO subjects (subject_name, class_id) VALUES (?, ?)");
        $insert->execute([$subject_name, $class_id]);
        header("Location: manage-subjects.php");
        exit();
    }
}

// Delete subject
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $delete = $conn->prepare("DELETE FROM subjects WHERE id = ?");
    $delete->execute([$id]);
    header("Location: manage-subjects.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Subjects - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">

    <header class="bg-white shadow-md p-6">
        <div class="max-w-6xl mx-auto flex justify-between items-center">
            <h1 class="text-3xl font-extrabold text-gray-800">
                Manage Subjects
            </h1>
            <div class="flex space-x-4">
                <a href="boys_dashboard.php" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg">
                    Back to Dashboard
                </a>
            </div>
        </div>
    </header>

    <main class="max-w-6xl mx-auto p-8">
        <div class="bg-white p-6 rounded-2xl shadow-xl mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Add New Subject</h2>
            <form method="POST" action="" class="space-y-4">
                <div>
                    <input type="text" name="subject_name" placeholder="Enter Subject Name" required class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200">
                </div>
                <div>
                    <select name="class_id" required class="w-full border-2 border-gray-300 rounded-lg p-3 focus:outline-none focus:border-blue-500 transition-colors duration-200">
                        <option value="">Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= htmlspecialchars($class['id']); ?>">
                                <?= htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="flex justify-end">
                    <button type="submit" name="add_subject" class="bg-blue-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-blue-700 transition-colors duration-300 transform hover:scale-105">
                        Add Subject
                    </button>
                </div>
            </form>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-xl">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Subject List</h2>
            <div class="overflow-x-auto">
                <?php if (!empty($subjects)): ?>
                    <table class="min-w-full bg-white rounded-lg overflow-hidden">
                        <thead class="bg-gray-200 text-gray-700">
                            <tr>
                                <th class="py-3 px-4 text-left font-semibold">#</th>
                                <th class="py-3 px-4 text-left font-semibold">Subject Name</th>
                                <th class="py-3 px-4 text-left font-semibold">Class Name</th>
                                <th class="py-3 px-4 text-left font-semibold">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php foreach ($subjects as $i => $subject): ?>
                                <tr class="hover:bg-gray-50 transition-colors duration-150">
                                    <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($i + 1); ?></td>
                                    <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($subject['subject_name']); ?></td>
                                    <td class="py-3 px-4 text-sm text-gray-800"><?= htmlspecialchars($subject['class_name']); ?></td>
                                    <td class="py-3 px-4">
                                        <a href="?delete=<?= htmlspecialchars($subject['id']); ?>"
                                           onclick="return confirm('Are you sure you want to delete this subject?');"
                                           class="bg-red-600 text-white font-semibold text-xs py-2 px-4 rounded-full hover:bg-red-700 transition-colors duration-300">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center text-gray-500 py-4">No subjects found.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>
</body>
</html>