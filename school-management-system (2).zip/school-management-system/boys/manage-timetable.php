<?php
session_start();
require_once "../config/boysdb.php";
require_once __DIR__ . '/../auth/boys-session_check.php';   // ✅ Must load before role check

// Initialize message variable
$message = '';

// Fetch all classes for dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all teachers for autocomplete
$teachers = $pdo->query("SELECT id, name FROM teachers ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// AJAX endpoint for fetching subjects based on class
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_subjects') {
    header('Content-Type: application/json');
    $class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
    
    if ($class_id > 0) {
        $stmt = $pdo->prepare("SELECT id, subject_name FROM subjects WHERE class_id = ? ORDER BY subject_name");
        $stmt->execute([$class_id]);
        $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($subjects);
    } else {
        echo json_encode([]);
    }
    exit();
}

// AJAX endpoint for teacher search
if (isset($_GET['ajax']) && $_GET['ajax'] == 'search_teachers') {
    header('Content-Type: application/json');
    $term = isset($_GET['term']) ? $_GET['term'] : '';
    
    if (strlen($term) >= 2) {
        $stmt = $pdo->prepare("SELECT id, name, email FROM teachers WHERE name LIKE ? ORDER BY name LIMIT 10");
        $stmt->execute(["%$term%"]);
        $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $results = [];
        foreach ($teachers as $teacher) {
            $results[] = [
                'id' => $teacher['id'],
                'label' => $teacher['name'] . ' (' . $teacher['email'] . ')',
                'value' => $teacher['name']
            ];
        }
        echo json_encode($results);
    } else {
        echo json_encode([]);
    }
    exit();
}

// Add new timetable entry
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_timetable'])) {
    $teacher_id = intval($_POST['teacher_id'] ?? 0);
    $teacher_name = trim($_POST['teacher_name'] ?? '');
    $class_id = intval($_POST['class_id'] ?? 0);
    $class_name = trim($_POST['class_name'] ?? '');
    $subject_id = intval($_POST['subject_id'] ?? 0);
    $subject_name = trim($_POST['subject_name'] ?? '');
    $day = trim($_POST['day'] ?? '');
    $start_time = trim($_POST['start_time'] ?? '');
    $end_time = trim($_POST['end_time'] ?? '');

    if ($teacher_id && $class_id && $subject_id && $day && $start_time && $end_time) {
        try {
            // Check if teacher exists
            $stmt = $pdo->prepare("SELECT id FROM teachers WHERE id = ?");
            $stmt->execute([$teacher_id]);
            if (!$stmt->fetch()) {
                $message = "Teacher not found in database!";
            } else {
                // Check if class exists
                $stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ?");
                $stmt->execute([$class_id]);
                if (!$stmt->fetch()) {
                    $message = "Class not found in database!";
                } else {
                    // Check if subject exists and belongs to the class
                    $stmt = $pdo->prepare("SELECT id FROM subjects WHERE id = ? AND class_id = ?");
                    $stmt->execute([$subject_id, $class_id]);
                    if (!$stmt->fetch()) {
                        $message = "Subject not found or doesn't belong to the selected class!";
                    } else {
                        // Check for time conflicts
                        $stmt = $pdo->prepare("SELECT id FROM timetable 
                                               WHERE day = ? AND teacher_id = ? 
                                               AND ((start_time <= ? AND end_time > ?) 
                                                    OR (start_time < ? AND end_time >= ?))");
                        $stmt->execute([$day, $teacher_id, $start_time, $start_time, $end_time, $end_time]);
                        
                        if ($stmt->fetch()) {
                            $message = "Teacher already has a class at this time!";
                        } else {
                            // Insert timetable entry
                            $stmt = $pdo->prepare("INSERT INTO timetable 
                                                  (teacher_id, teacher_name, class_id, class_name, subject_id, subject_name, day, start_time, end_time) 
                                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                            $stmt->execute([$teacher_id, $teacher_name, $class_id, $class_name, $subject_id, $subject_name, $day, $start_time, $end_time]);
                            
                            $_SESSION['message'] = "Timetable entry added successfully!";
                            header("Location: manage-timetable.php");
                            exit();
                        }
                    }
                }
            }
        } catch (PDOException $e) {
            $message = "Error adding entry: " . $e->getMessage();
        }
    } else {
        $message = "Please fill in all required fields.";
    }
    
    if (!empty($message)) {
        $_SESSION['message'] = $message;
        header("Location: manage-timetable.php");
        exit();
    }
}

// Delete timetable entry
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    try {
        $stmt = $pdo->prepare("DELETE FROM timetable WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['message'] = "Timetable entry deleted successfully!";
    } catch (PDOException $e) {
        $_SESSION['message'] = "Error deleting entry: " . $e->getMessage();
    }
    header("Location: manage-timetable.php");
    exit();
}

// Fetch timetable entries with joins
$stmt = $pdo->query("SELECT t.*, c.class_name as class, s.subject_name as subject 
                     FROM timetable t
                     LEFT JOIN classes c ON t.class_id = c.id
                     LEFT JOIN subjects s ON t.subject_id = s.id
                     ORDER BY FIELD(t.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), t.start_time");
$timetables = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle session messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

// Group timetables by day for better display
$timetable_by_day = [];
foreach ($timetables as $entry) {
    $timetable_by_day[$entry['day']][] = $entry;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Timetable - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <style>
        :root {
            --primary-color: #007bff;
            --primary-hover: #0056b3;
            --secondary-color: #6c757d;
            --secondary-hover: #5a6268;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --danger-hover: #c82333;
            --bg-light: #f8f9fa;
            --text-dark: #212529;
            --white: #ffffff;
            --card-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --border-light: #dee2e6;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--bg-light);
            color: var(--text-dark);
        }

        .header {
            background-color: var(--white);
            box-shadow: var(--card-shadow);
            padding: 1.5rem 2rem;
            margin-bottom: 2rem;
        }

        .header .container-fluid {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title {
            font-weight: 700;
            color: var(--primary-color);
            font-size: 1.75rem;
        }

        .btn-action {
            display: inline-flex;
            align-items: center;
            font-weight: 500;
            padding: 0.5rem 1.2rem;
            border-radius: 50rem;
            transition: all 0.3s ease;
        }

        .btn-action.btn-back {
            background-color: var(--secondary-color);
            color: var(--white);
        }

        .btn-action.btn-back:hover {
            background-color: var(--secondary-hover);
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .content-container {
            max-width: 1200px;
            margin: auto;
            padding: 0 15px;
        }

        h2 {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-card {
            background-color: var(--white);
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--card-shadow);
            margin-bottom: 2.5rem;
        }

        .form-card h4 {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-control, .form-select {
            border-radius: 8px;
            padding: 10px 15px;
            border-color: var(--border-light);
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 0.25rem rgba(0, 123, 255, 0.25);
            border-color: var(--primary-color);
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            font-weight: 500;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
            border-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        .table-container {
            background-color: var(--white);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--card-shadow);
            margin-bottom: 2rem;
        }

        .table-primary thead th {
            background-color: var(--primary-color);
            color: var(--white);
            font-weight: 600;
            text-transform: uppercase;
            border-color: var(--primary-color);
        }

        .table-bordered th, .table-bordered td {
            border-color: var(--border-light);
        }

        .table-hover tbody tr:hover {
            background-color: var(--bg-light);
        }

        .alert-info {
            border-radius: 8px;
            text-align: center;
        }

        .btn-danger {
            background-color: var(--danger-color);
            border-color: var(--danger-color);
            font-weight: 500;
            padding: 5px 12px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .btn-danger:hover {
            background-color: var(--danger-hover);
            border-color: var(--danger-hover);
            transform: scale(1.05);
        }

        .day-header {
            background-color: #e9ecef;
            font-weight: 600;
            font-size: 1.1rem;
            padding: 0.75rem 1rem;
        }

        .day-header i {
            margin-right: 0.5rem;
            color: var(--primary-color);
        }

        .subject-badge {
            background-color: #e3f2fd;
            color: #0d47a1;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .time-badge {
            background-color: #f3e5f5;
            color: #4a148c;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .teacher-badge {
            background-color: #e8f5e9;
            color: #1b5e20;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.9rem;
        }

        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(0,123,255,0.3);
            border-radius: 50%;
            border-top-color: var(--primary-color);
            animation: spin 1s ease-in-out infinite;
            margin-left: 10px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .ui-autocomplete {
            max-height: 200px;
            overflow-y: auto;
            overflow-x: hidden;
            z-index: 9999 !important;
        }

        .ui-menu-item {
            padding: 8px 12px;
            font-family: 'Poppins', sans-serif;
        }

        .ui-state-focus {
            background-color: var(--primary-color) !important;
            color: white !important;
            border: none !important;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container-fluid">
            <h1 class="header-title">
                <i class="fas fa-calendar-alt me-2"></i>
                Timetable Management
            </h1>
            <a href="boys_dashboard.php" class="btn btn-primary">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>
    </header>

    <div class="content-container">
        <h2>
            <i class="fas fa-clock me-2"></i>
            Manage Timetable
        </h2>

        <?php if (!empty($message)): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle me-2"></i>
                <?= htmlspecialchars($message) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="form-card">
            <h4>
                <i class="fas fa-plus-circle me-2"></i>
                Add New Timetable Entry
            </h4>
            <form method="POST" id="timetableForm">
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-chalkboard-teacher me-1"></i> Teacher *
                        </label>
                        <input type="text" 
                               id="teacher_search" 
                               class="form-control" 
                               placeholder="Start typing teacher name..." 
                               autocomplete="off"
                               required>
                        <input type="hidden" name="teacher_id" id="teacher_id" required>
                        <input type="hidden" name="teacher_name" id="teacher_name">
                        <div id="teacher-hint" class="form-text text-muted">
                            <i class="fas fa-info-circle"></i> Type at least 2 characters to search
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-school me-1"></i> Class *
                        </label>
                        <select name="class_id" id="class_id" class="form-select" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" data-name="<?= htmlspecialchars($class['class_name']) ?>">
                                    Class <?= htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="class_name" id="class_name">
                    </div>
                </div>
                
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-book me-1"></i> Subject *
                        </label>
                        <select name="subject_id" id="subject_id" class="form-select" required disabled>
                            <option value="">First select a class</option>
                        </select>
                        <input type="hidden" name="subject_name" id="subject_name">
                        <div id="subject-loading" style="display: none;" class="mt-2">
                            <span class="loading-spinner"></span> Loading subjects...
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-calendar-day me-1"></i> Day *
                        </label>
                        <select name="day" class="form-select" required>
                            <option value="">Select Day</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                        </select>
                    </div>
                </div>
                
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-clock me-1"></i> Start Time *
                        </label>
                        <input type="time" name="start_time" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="fas fa-clock me-1"></i> End Time *
                        </label>
                        <input type="time" name="end_time" class="form-control" required>
                    </div>
                </div>
                
                <div class="d-grid">
                    <button type="submit" name="add_timetable" class="btn btn-primary btn-lg" id="submitBtn">
                        <i class="fas fa-plus-circle me-2"></i>
                        Add Timetable Entry
                    </button>
                </div>
            </form>
        </div>

        <!-- Timetable Display by Day -->
        <?php if ($timetables): ?>
            <?php 
            $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            foreach ($days as $day): 
                if (isset($timetable_by_day[$day])):
            ?>
                <div class="table-container">
                    <div class="day-header">
                        <i class="fas fa-calendar-day"></i>
                        <?= $day ?>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle mb-0">
                            <thead class="table-primary">
                                <tr>
                                    <th>Time</th>
                                    <th>Teacher</th>
                                    <th>Class</th>
                                    <th>Subject</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($timetable_by_day[$day] as $row): ?>
                                    <tr>
                                        <td>
                                            <span class="time-badge">
                                                <i class="far fa-clock me-1"></i>
                                                <?= date('h:i A', strtotime($row['start_time'])) ?> - 
                                                <?= date('h:i A', strtotime($row['end_time'])) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="teacher-badge">
                                                <i class="fas fa-chalkboard-teacher me-1"></i>
                                                <?= htmlspecialchars($row['teacher_name']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-info">
                                                Class <?= htmlspecialchars($row['class_name'] ?? $row['class']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="subject-badge">
                                                <i class="fas fa-book me-1"></i>
                                                <?= htmlspecialchars($row['subject_name'] ?? $row['subject']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a class="btn btn-danger btn-sm" 
                                               href="?delete=<?= $row['id']; ?>" 
                                               onclick="return confirm('Delete this timetable entry?')">
                                                <i class="fas fa-trash-alt me-1"></i>Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php 
                endif;
            endforeach; 
            ?>
        <?php else: ?>
            <div class="alert alert-info text-center p-5">
                <i class="fas fa-calendar-times fa-3x mb-3"></i>
                <h4>No Timetable Entries Found</h4>
                <p>Add your first timetable entry using the form above.</p>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Teacher autocomplete
            $("#teacher_search").autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: window.location.href,
                        dataType: "json",
                        data: {
                            ajax: 'search_teachers',
                            term: request.term
                        },
                        success: function(data) {
                            response(data);
                        },
                        error: function() {
                            response([]);
                        }
                    });
                },
                minLength: 2,
                select: function(event, ui) {
                    // When teacher is selected
                    $("#teacher_search").val(ui.item.label);
                    $("#teacher_id").val(ui.item.id);
                    $("#teacher_name").val(ui.item.value);
                    
                    // Add success indicator
                    $("#teacher_search").addClass('is-valid');
                    $("#teacher-hint").html('<i class="fas fa-check-circle text-success"></i> Teacher selected: ' + ui.item.value);
                    
                    return false;
                },
                open: function() {
                    $(this).removeClass("ui-corner-all").addClass("ui-corner-top");
                },
                close: function() {
                    $(this).removeClass("ui-corner-top").addClass("ui-corner-all");
                }
            }).focus(function() {
                $(this).autocomplete("search");
            });

            // Load subjects when class is selected
            $("#class_id").change(function() {
                var classId = $(this).val();
                var className = $(this).find('option:selected').data('name');
                $("#class_name").val(className);
                
                if (classId) {
                    // Disable subject dropdown and show loading
                    $("#subject_id").prop('disabled', true);
                    $("#subject_id").html('<option value="">Loading subjects...</option>');
                    $("#subject-loading").show();
                    
                    // Fetch subjects via AJAX
                    $.ajax({
                        url: window.location.href,
                        dataType: "json",
                        data: {
                            ajax: 'get_subjects',
                            class_id: classId
                        },
                        success: function(subjects) {
                            var options = '<option value="">Select Subject</option>';
                            
                            if (subjects.length > 0) {
                                $.each(subjects, function(index, subject) {
                                    options += '<option value="' + subject.id + '" data-name="' + subject.subject_name + '">' + subject.subject_name + '</option>';
                                });
                                $("#subject_id").prop('disabled', false);
                            } else {
                                options = '<option value="">No subjects found for this class</option>';
                            }
                            
                            $("#subject_id").html(options);
                            $("#subject-loading").hide();
                        },
                        error: function() {
                            $("#subject_id").html('<option value="">Error loading subjects</option>');
                            $("#subject-loading").hide();
                        }
                    });
                } else {
                    $("#subject_id").prop('disabled', true);
                    $("#subject_id").html('<option value="">First select a class</option>');
                }
            });

            // Set subject name when subject is selected
            $("#subject_id").change(function() {
                var subjectName = $(this).find('option:selected').data('name');
                $("#subject_name").val(subjectName);
            });

            // Form validation
            $("#timetableForm").submit(function(e) {
                var teacherId = $("#teacher_id").val();
                var classId = $("#class_id").val();
                var subjectId = $("#subject_id").val();
                var startTime = $("input[name='start_time']").val();
                var endTime = $("input[name='end_time']").val();
                
                if (!teacherId) {
                    e.preventDefault();
                    alert("Please select a teacher from the dropdown");
                    $("#teacher_search").focus();
                    return false;
                }
                
                if (!classId) {
                    e.preventDefault();
                    alert("Please select a class");
                    return false;
                }
                
                if (!subjectId) {
                    e.preventDefault();
                    alert("Please select a subject");
                    return false;
                }
                
                if (startTime && endTime && startTime >= endTime) {
                    e.preventDefault();
                    alert("End time must be after start time");
                    return false;
                }
                
                return true;
            });

            // Validate teacher input
            $("#teacher_search").blur(function() {
                var teacherId = $("#teacher_id").val();
                var teacherName = $(this).val();
                
                if (teacherName && !teacherId) {
                    $(this).addClass('is-invalid');
                    $("#teacher-hint").html('<i class="fas fa-exclamation-circle text-danger"></i> Please select a teacher from the dropdown');
                } else {
                    $(this).removeClass('is-invalid');
                }
            });

            // Time validation
            $("input[name='start_time'], input[name='end_time']").change(function() {
                var startTime = $("input[name='start_time']").val();
                var endTime = $("input[name='end_time']").val();
                
                if (startTime && endTime && startTime >= endTime) {
                    $("input[name='end_time']").addClass('is-invalid');
                    $("#time-error").remove();
                    $("input[name='end_time']").after('<div id="time-error" class="invalid-feedback">End time must be after start time</div>');
                } else {
                    $("input[name='end_time']").removeClass('is-invalid');
                    $("#time-error").remove();
                }
            });
        });
    </script>
</body>
</html>