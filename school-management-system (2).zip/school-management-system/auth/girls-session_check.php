<?php
// ✅ Only start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Role re-check interval in seconds
$role_check_interval = 180; // 3 minutes

// Function to get latest role from DB (PDO)
function getUserRoleFromDB($user_id, $pdo) {
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? $row['role'] : null;
}

// ✅ If not logged in → redirect
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: ../auth/girls-login.php");
    exit();
}

// ✅ Load DB connection (PDO)
require_once __DIR__ . '/../config/girlsdp.php';

// ✅ Role re-check every X seconds
if (!isset($_SESSION['LAST_ROLE_CHECK']) ||
    (time() - $_SESSION['LAST_ROLE_CHECK']) > $role_check_interval) {

    $latestRole = getUserRoleFromDB($_SESSION['user_id'], $pdo);

    if ($latestRole !== $_SESSION['role']) {
        session_unset();
        session_destroy();
        header("Location: ../auth/girls-login.php?error=role_changed");
        exit();
    }

    $_SESSION['LAST_ROLE_CHECK'] = time();
}
?>
