<?php
session_start();

// Always use absolute path so it works no matter where the script is
require_once(__DIR__ . '/../config/girlsdp.php'); 
require_once(__DIR__ . '/../config/config.php'); // For BASE_URL constant

// Redirect already logged-in admin users directly to boys dashboard
if (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header("Location: " . BASE_URL . "girls/girls_dashboard.php");
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = "Please fill all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        try {
            // Login with email only - check for admin role
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email AND role = 'admin' LIMIT 1");
            $stmt->execute([':email' => $email]);
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                // Check if user account is active
                if (isset($user['status']) && $user['status'] === 'inactive') {
                    $error = "Your account is inactive. Please contact administrator.";
                } else {
                    // Save session data
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'] ?? $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    
                    // Set last login time
                    $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $updateStmt->execute([$user['id']]);

                    // Redirect to boys dashboard
                    header("Location: " . BASE_URL . "girls/girls_dashboard.php");
                    exit();
                }
            } else {
                $error = "Invalid email or password. Only admin users can login here.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Girls Campus Admin Login - Ghazali School</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 420px;
            text-align: center;
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .school-logo {
            margin-bottom: 20px;
        }

        .school-logo i {
            font-size: 48px;
            color: #1e3c72;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .campus-badge {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 8px 20px;
            border-radius: 50px;
            display: inline-block;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 15px;
            letter-spacing: 1px;
        }

        .campus-badge i {
            margin-right: 5px;
            color: #ffd700;
        }

        h2 {
            color: #333;
            margin-bottom: 5px;
            font-weight: 700;
            font-size: 28px;
        }

        .campus-name {
            color: #1e3c72;
            font-weight: 600;
            margin-bottom: 10px;
            font-size: 18px;
        }

        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .error {
            color: #d9534f;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            display: <?php echo $error ? 'flex' : 'none'; ?>;
            align-items: center;
            gap: 10px;
            text-align: left;
            animation: shake 0.5s ease-in-out;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
            20%, 40%, 60%, 80% { transform: translateX(5px); }
        }

        .error i {
            font-size: 18px;
        }

        .info-message {
            background-color: #e7f3ff;
            border-left: 4px solid #1e3c72;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 8px;
            text-align: left;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .info-message i {
            color: #1e3c72;
            font-size: 24px;
        }

        .info-message p {
            color: #0c5460;
            font-size: 13px;
            line-height: 1.5;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .input-group {
            position: relative;
            text-align: left;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 14px;
        }

        .input-icon {
            position: relative;
        }

        .input-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        .input-icon input {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s ease;
            background-color: #fafafa;
        }

        .input-icon input:focus {
            border-color: #1e3c72;
            background-color: #fff;
            outline: none;
            box-shadow: 0 0 0 3px rgba(30, 60, 114, 0.1);
        }

        .input-icon input:focus + i {
            color: #1e3c72;
        }

        .input-icon input.error-field {
            border-color: #d9534f;
            background-color: #fff8f8;
        }

        .input-hint {
            font-size: 12px;
            color: #999;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        button[type="submit"] {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: #fff;
            padding: 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }

        button[type="submit"]:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 60, 114, 0.4);
        }

        button[type="submit"]:active {
            transform: translateY(0);
        }

        button[type="submit"] i {
            font-size: 18px;
        }

        .login-info {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 13px;
            color: #666;
        }

        .campus-note {
            background-color: #e8f4fd;
            border: 1px solid #b8e0ff;
            border-radius: 8px;
            padding: 10px;
            margin-top: 15px;
            text-align: left;
            font-size: 12px;
            color: #1e3c72;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .campus-note i {
            color: #1e3c72;
        }

        .back-home {
            margin-top: 15px;
        }

        .back-home a {
            color: #666;
            text-decoration: none;
            font-size: 13px;
            transition: color 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .back-home a:hover {
            color: #1e3c72;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }

            h2 {
                font-size: 24px;
            }

            button[type="submit"] {
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="school-logo">
            <i class="fas fa-mars fa-4x"></i>
        </div>
        
        <div class="campus-badge">
            <i class="fas fa-crown"></i> Girls Campus Admin
        </div>
        
        <h2>Welcome Admin!</h2>
        <div class="campus-name">Ghazali School - girls Wing</div>
        <p class="subtitle">Login to access boys campus dashboard</p>
        
        <?php if ($error): ?>
            <div class="error">
                <i class="fas fa-exclamation-circle"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>

        <div class="info-message">
            <i class="fas fa-shield-alt"></i>
            <p>This login is exclusively for Boys Campus administrators. This will redirect to Boys Dashboard.</p>
        </div>

        <form method="POST" id="loginForm" autocomplete="off">
            <div class="input-group">
                <label for="email">
                    <i class="fas fa-envelope"></i> Admin Email
                </label>
                <div class="input-icon">
                    <i class="fas fa-envelope"></i>
                    <input type="email" 
                           id="email" 
                           name="email" 
                           placeholder="admin@girls.school.com" 
                           required
                           autocomplete="email"
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
            </div>

            <div class="input-group">
                <label for="password">
                    <i class="fas fa-lock"></i> Password
                </label>
                <div class="input-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" 
                           id="password" 
                           name="password" 
                           placeholder="Enter your password" 
                           required
                           autocomplete="current-password">
                </div>
                <div class="input-hint" style="justify-content: space-between;">
                    <span><i class="fas fa-key"></i> Admin password required</span>
                    <span><i class="fas fa-eye" id="togglePassword" style="cursor: pointer;" onclick="togglePasswordVisibility()"></i></span>
                </div>
            </div>

            <button type="submit">
                <i class="fas fa-sign-in-alt"></i>
                Access Girls Dashboard
            </button>
        </form>

        <div class="campus-note">
            <i class="fas fa-info-circle"></i>
            <span>You are logging into <strong>Girls Campus Admin Panel</strong>.here is <strong>login gmail:</strong>admin@girlscampus.com <br> <strong>password:</strong>admin123</span>
        </div>

        <div class="login-info">
            <div class="back-home">
                <a href="../index.php">
                    <i class="fas fa-home"></i> Back to Home
                </a>
            </div>

            <div class="other-logins" style="margin-top: 15px; font-size: 12px;">
                <a href="boys-login.php" style="color: #1e3c72; text-decoration: none; margin-right: 10px;">
                    <i class="fas fa-venus"></i> boys Campus
                </a>

        </div>
    </div>

    <script>
        // Toggle password visibility
        function togglePasswordVisibility() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('togglePassword');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }

        // Form validation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            
            // Remove existing error classes
            document.querySelectorAll('.input-icon input').forEach(input => {
                input.classList.remove('error-field');
            });
            
            if (!email || !password) {
                e.preventDefault();
                showError('Please fill in all fields');
                
                if (!email) {
                    document.getElementById('email').classList.add('error-field');
                }
                if (!password) {
                    document.getElementById('password').classList.add('error-field');
                }
                return false;
            }
            
            // Validate email format
            if (!isValidEmail(email)) {
                e.preventDefault();
                showError('Please enter a valid email address');
                document.getElementById('email').classList.add('error-field');
                return false;
            }
            
            return true;
        });

        function isValidEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        function showError(message) {
            // Remove existing error
            const existingError = document.querySelector('.error');
            if (existingError) {
                existingError.remove();
            }

            // Create new error
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error';
            errorDiv.style.display = 'flex';
            errorDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i><span>' + message + '</span>';
            
            // Insert at the top of form
            const form = document.getElementById('loginForm');
            form.parentNode.insertBefore(errorDiv, form);
            
            // Auto hide after 5 seconds
            setTimeout(() => {
                errorDiv.style.transition = 'opacity 0.5s';
                errorDiv.style.opacity = '0';
                setTimeout(() => errorDiv.remove(), 500);
            }, 5000);
        }

        // Auto-hide PHP error messages after 5 seconds
        setTimeout(function() {
            const errorDiv = document.querySelector('.error');
            if (errorDiv && !errorDiv.classList.contains('persistent')) {
                errorDiv.style.transition = 'opacity 0.5s';
                errorDiv.style.opacity = '0';
                setTimeout(() => errorDiv.remove(), 500);
            }
        }, 5000);

        // Add input focus effects
        document.querySelectorAll('.input-icon input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.querySelector('i').style.color = '#1e3c72';
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.querySelector('i').style.color = '#999';
                }
            });
        });

        // Real-time email validation
        document.getElementById('email').addEventListener('input', function() {
            const email = this.value.trim();
            if (email && !isValidEmail(email)) {
                this.classList.add('error-field');
            } else {
                this.classList.remove('error-field');
            }
        });

        // Prevent form resubmission on page refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>