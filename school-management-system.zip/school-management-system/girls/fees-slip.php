<?php
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role checkk

// Get fee record ID from URL
$fee_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$fee_id) {
    die("Invalid fee record ID");
}

// Fetch fee record with student details
$stmt = $pdo->prepare("
    SELECT f.*, s.parent_name, s.address, s.phone 
    FROM fees f 
    LEFT JOIN students s ON f.student_id = s.id 
    WHERE f.id = ?
");
$stmt->execute([$fee_id]);
$fee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$fee) {
    die("Fee record not found");
}

// Calculate remaining amount
$remaining = $fee['total_amount'] - $fee['paid_amount'];
$status = $fee['status'];

// Format dates
$issue_date = date('d-M-Y', strtotime($fee['created_at']));
$due_date = date('d-M-Y', strtotime($fee['due_date']));
$month_year = date('F, Y', strtotime($fee['due_date']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Fee Slip - <?= htmlspecialchars($fee['student_name']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f0f2f5;
            padding: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .fee-slip {
            width: 100%;
            max-width: 800px;
            background: white;
            border: 2px solid #000;
            padding: 15px;
            margin: 10px auto;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border-radius: 0;
            overflow-x: auto;
        }
        
        @media (min-width: 768px) {
            .fee-slip {
                padding: 20px;
                margin: 20px auto;
            }
        }
        
        .header {
            text-align: center;
            margin-bottom: 15px;
            border-bottom: 2px solid #000;
            padding-bottom: 12px;
        }
        
        @media (min-width: 768px) {
            .header {
                margin-bottom: 20px;
                padding-bottom: 15px;
            }
        }
        
        .school-name {
            font-size: 20px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #000;
            word-break: break-word;
        }
        
        @media (min-width: 768px) {
            .school-name {
                font-size: 28px;
                letter-spacing: 2px;
            }
        }
        
        .campus {
            font-size: 14px;
            font-weight: 600;
            margin-top: 3px;
            color: #333;
        }
        
        @media (min-width: 768px) {
            .campus {
                font-size: 16px;
                margin-top: 5px;
            }
        }
        
        .phone {
            font-size: 12px;
            margin-top: 3px;
            color: #555;
        }
        
        @media (min-width: 768px) {
            .phone {
                font-size: 14px;
                margin-top: 5px;
            }
        }
        
        .title-section {
            display: flex;
            flex-direction: column;
            gap: 5px;
            margin: 15px 0;
            padding: 8px 0;
            border-top: 1px dashed #000;
            border-bottom: 1px dashed #000;
        }
        
        @media (min-width: 768px) {
            .title-section {
                flex-direction: row;
                justify-content: space-between;
                margin: 20px 0;
                padding: 10px 0;
            }
        }
        
        .copy-type {
            font-size: 16px;
            font-weight: 700;
            text-transform: uppercase;
        }
        
        @media (min-width: 768px) {
            .copy-type {
                font-size: 18px;
            }
        }
        
        .comp-no {
            font-size: 14px;
            font-weight: 600;
        }
        
        @media (min-width: 768px) {
            .comp-no {
                font-size: 16px;
            }
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 10px;
            margin: 15px 0;
            padding: 12px;
            border: 1px solid #000;
            background: #f9f9f9;
        }
        
        @media (min-width: 640px) {
            .info-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                padding: 15px;
            }
        }
        
        .info-item {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }
        
        @media (min-width: 640px) {
            .info-item {
                flex-direction: row;
                align-items: center;
                gap: 0;
            }
        }
        
        .info-label {
            font-weight: 700;
            min-width: 100px;
            color: #333;
            font-size: 12px;
        }
        
        @media (min-width: 768px) {
            .info-label {
                font-size: 14px;
            }
        }
        
        .info-value {
            font-weight: 600;
            color: #000;
            border-bottom: 1px dotted #999;
            padding-bottom: 3px;
            word-break: break-word;
            font-size: 13px;
        }
        
        @media (min-width: 768px) {
            .info-value {
                font-size: 14px;
            }
        }
        
        .student-id-box {
            background: #e3f2fd;
            border: 2px solid #1976d2;
            padding: 8px 12px;
            margin: 12px 0;
            display: flex;
            flex-direction: column;
            gap: 5px;
            font-size: 16px;
        }
        
        @media (min-width: 640px) {
            .student-id-box {
                flex-direction: row;
                align-items: center;
                gap: 15px;
                padding: 10px 15px;
                margin: 15px 0;
                font-size: 18px;
            }
        }
        
        .student-id-label {
            font-weight: 700;
            color: #1976d2;
        }
        
        .student-id-value {
            font-family: 'Courier New', monospace;
            font-weight: 800;
            font-size: 18px;
            color: #0d47a1;
            word-break: break-word;
        }
        
        @media (min-width: 768px) {
            .student-id-value {
                font-size: 22px;
            }
        }
        
        .due-date-box {
            background: #ffeb3b;
            padding: 8px 12px;
            font-weight: 700;
            border: 1px solid #000;
            text-align: center;
            margin-bottom: 15px;
            font-size: 13px;
        }
        
        @media (min-width: 640px) {
            .due-date-box {
                padding: 8px 15px;
                text-align: right;
                margin-bottom: 15px;
                font-size: 14px;
            }
        }
        
        .fee-table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 13px;
        }
        
        @media (min-width: 768px) {
            .fee-table {
                margin: 20px 0;
                font-size: 14px;
            }
        }
        
        .fee-table th {
            background: #000;
            color: white;
            padding: 8px;
            text-align: left;
            font-size: 13px;
        }
        
        @media (min-width: 768px) {
            .fee-table th {
                padding: 12px;
                font-size: 16px;
            }
        }
        
        .fee-table td {
            padding: 8px;
            border: 1px solid #999;
        }
        
        @media (min-width: 768px) {
            .fee-table td {
                padding: 12px;
            }
        }
        
        .fee-table .amount {
            text-align: right;
            font-weight: 700;
            white-space: nowrap;
        }
        
        .total-row {
            background: #f0f0f0;
            font-weight: 700;
        }
        
        .payment-status {
            margin: 15px 0;
            padding: 12px;
            border: 2px solid #000;
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: flex-start;
        }
        
        @media (min-width: 640px) {
            .payment-status {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                padding: 15px;
            }
        }
        
        .status-badge {
            padding: 6px 16px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 14px;
            display: inline-block;
        }
        
        @media (min-width: 768px) {
            .status-badge {
                padding: 8px 20px;
                font-size: 16px;
            }
        }
        
        .status-paid {
            background: #4caf50;
            color: white;
        }
        
        .status-partial {
            background: #ff9800;
            color: white;
        }
        
        .status-pending {
            background: #f44336;
            color: white;
        }
        
        .footer {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            gap: 5px;
            font-size: 10px;
            color: #666;
            border-top: 1px dashed #000;
            padding-top: 12px;
        }
        
        @media (min-width: 640px) {
            .footer {
                flex-direction: row;
                justify-content: space-between;
                margin-top: 30px;
                font-size: 12px;
                padding-top: 15px;
            }
        }
        
        .signature {
            margin-top: 30px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        @media (min-width: 640px) {
            .signature {
                flex-direction: row;
                justify-content: space-between;
                gap: 0;
            }
        }
        
        .signature-item {
            width: 100%;
        }
        
        @media (min-width: 640px) {
            .signature-item {
                width: 200px;
            }
        }
        
        .signature-line {
            width: 100%;
            border-top: 1px solid #000;
            margin-top: 5px;
        }
        
        .office-use {
            margin-top: 20px;
            padding: 12px;
            background: #f0f0f0;
            border: 1px dashed #000;
            font-size: 13px;
        }
        
        @media (min-width: 768px) {
            .office-use {
                margin-top: 20px;
                padding: 10px;
            }
        }
        
        .action-buttons {
            position: sticky;
            top: 0;
            z-index: 100;
            background: rgba(255, 255, 255, 0.95);
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 50px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            width: 100%;
            max-width: 800px;
        }
        
        .action-btn {
            padding: 12px 20px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex: 1 1 auto;
            min-width: 120px;
            -webkit-tap-highlight-color: transparent;
        }
        
        @media (min-width: 768px) {
            .action-btn {
                padding: 12px 30px;
                font-size: 16px;
                flex: 0 1 auto;
            }
        }
        
        .print-btn {
            background: #2196F3;
            color: white;
        }
        
        .print-btn:hover {
            background: #1976D2;
            transform: scale(1.05);
        }
        
        .back-btn {
            background: #6c757d;
            color: white;
        }
        
        .back-btn:hover {
            background: #5a6268;
            transform: scale(1.05);
        }
        
        .action-btn:active {
            transform: scale(0.95);
        }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .fee-slip {
                box-shadow: none;
                border: 2px solid #000;
                margin: 0;
                max-width: 100%;
                page-break-inside: avoid;
            }
            
            .action-buttons {
                display: none;
            }
            
            .no-print {
                display: none;
            }
            
            .office-copy, .student-copy {
                page-break-inside: avoid;
                page-break-after: always;
            }
        }
        
        .office-copy, .student-copy {
            margin-bottom: 20px;
            page-break-inside: avoid;
        }
        
        @media (min-width: 768px) {
            .office-copy, .student-copy {
                margin-bottom: 30px;
            }
        }
        
        .duplicate-watermark {
            position: relative;
        }
        
        .duplicate-watermark::before {
            content: "DUPLICATE";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-size: 40px;
            color: rgba(255, 0, 0, 0.1);
            font-weight: 800;
            pointer-events: none;
            z-index: 1;
            white-space: nowrap;
        }
        
        @media (min-width: 768px) {
            .duplicate-watermark::before {
                font-size: 60px;
            }
        }
        
        /* Touch-friendly improvements */
        button, a {
            touch-action: manipulation;
        }
        
        /* Improve readability on small screens */
        @media (max-width: 480px) {
            .fee-table th,
            .fee-table td {
                padding: 6px;
            }
            
            .info-grid {
                padding: 8px;
            }
            
            .student-id-value {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <!-- Action Buttons - Mobile Optimized -->
    <div class="action-buttons no-print">
        <button onclick="window.print()" class="action-btn print-btn">
            <i class="fas fa-print"></i>
            <span>Print Slip</span>
        </button>
        <a href="manage-fees.php" class="action-btn back-btn">
            <i class="fas fa-arrow-left"></i>
            <span>Back to Fees</span>
        </a>
    </div>

    <!-- Student Copy -->
    <div class="fee-slip student-copy">
        <div class="header">
            <div class="school-name">GHAZALI MODEL HIGH SCHOOL</div>
            <div class="campus">Boys Campus</div>
            <div class="phone">Ph: 0346533623</div>
        </div>
        
        <div class="title-section">
            <span class="copy-type">Student Copy</span>
            <span class="comp-no">Comp #: <?= str_pad($fee['id'], 3, '0', STR_PAD_LEFT) ?></span>
        </div>
        
        <div class="student-id-box">
            <span class="student-id-label">Student ID:</span>
            <span class="student-id-value"><?= htmlspecialchars($fee['std_id']) ?></span>
        </div>
        
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Student's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['student_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Father's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['parent_name'] ?? 'N/A') ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Class:</span>
                <span class="info-value"><?= htmlspecialchars($fee['class_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Roll No:</span>
                <span class="info-value"><?= htmlspecialchars($fee['roll_no']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Month:</span>
                <span class="info-value"><?= $month_year ?></span>
            </div>
        </div>
        
        <div class="due-date-box">
            <strong>Due Date:</strong> <?= $due_date ?>
        </div>
        
        <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
            <table class="fee-table">
                <thead>
                    <tr>
                        <th>Particulars</th>
                        <th style="text-align: right;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Monthly Fee - <?= $month_year ?></td>
                        <td class="amount">Rs. <?= number_format($fee['total_amount'], 2) ?></td>
                    </tr>
                    <?php if ($fee['paid_amount'] > 0): ?>
                    <tr>
                        <td>Paid Amount</td>
                        <td class="amount" style="color: #4caf50;">- Rs. <?= number_format($fee['paid_amount'], 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr class="total-row">
                        <td><strong>Remaining Amount</strong></td>
                        <td class="amount"><strong>Rs. <?= number_format($remaining, 2) ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="payment-status">
            <span style="font-weight: 700;">Payment Status:</span>
            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $status)) ?>">
                <?= $status ?>
            </span>
        </div>
        
        <div class="footer">
            <span>Generated on: <?= date('d-M-Y h:i A') ?></span>
            <span>This is a computer generated slip</span>
        </div>
        
        <div class="signature">
            <div class="signature-item">
                <div>Student's Signature</div>
                <div class="signature-line"></div>
            </div>
            <div class="signature-item">
                <div>Authorized Signature</div>
                <div class="signature-line"></div>
            </div>
        </div>
    </div>

    <!-- Office Copy (Duplicate) -->
    <div class="fee-slip office-copy duplicate-watermark" style="margin-top: 20px;">
        <div class="header">
            <div class="school-name">GHAZALI MODEL HIGH SCHOOL</div>
            <div class="campus">Boys Campus</div>
            <div class="phone">Ph: 0346533623</div>
        </div>
        
        <div class="title-section">
            <span class="copy-type" style="color: #d32f2f;">Office Copy</span>
            <span class="comp-no">Comp #: <?= str_pad($fee['id'], 3, '0', STR_PAD_LEFT) ?></span>
        </div>
        
        <div class="student-id-box">
            <span class="student-id-label">Student ID:</span>
            <span class="student-id-value"><?= htmlspecialchars($fee['std_id']) ?></span>
        </div>
        
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Student's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['student_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Father's Name:</span>
                <span class="info-value"><?= htmlspecialchars($fee['parent_name'] ?? 'N/A') ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Class:</span>
                <span class="info-value"><?= htmlspecialchars($fee['class_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Roll No:</span>
                <span class="info-value"><?= htmlspecialchars($fee['roll_no']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Month:</span>
                <span class="info-value"><?= $month_year ?></span>
            </div>
        </div>
        
        <div class="due-date-box">
            <strong>Due Date:</strong> <?= $due_date ?>
        </div>
        
        <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
            <table class="fee-table">
                <thead>
                    <tr>
                        <th>Particulars</th>
                        <th style="text-align: right;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Monthly Fee - <?= $month_year ?></td>
                        <td class="amount">Rs. <?= number_format($fee['total_amount'], 2) ?></td>
                    </tr>
                    <?php if ($fee['paid_amount'] > 0): ?>
                    <tr>
                        <td>Paid Amount</td>
                        <td class="amount" style="color: #4caf50;">- Rs. <?= number_format($fee['paid_amount'], 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr class="total-row">
                        <td><strong>Remaining Amount</strong></td>
                        <td class="amount"><strong>Rs. <?= number_format($remaining, 2) ?></strong></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <div class="payment-status">
            <span style="font-weight: 700;">Payment Status:</span>
            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $status)) ?>">
                <?= $status ?>
            </span>
        </div>
        
        <div class="office-use">
            <p><strong>Office Use Only:</strong></p>
            <p style="margin-top: 10px;">Received by: ____________________ Date: _____________</p>
        </div>
        
        <div class="footer">
            <span>Generated on: <?= date('d-M-Y h:i A') ?></span>
            <span>Comp #: <?= str_pad($fee['id'], 3, '0', STR_PAD_LEFT) ?></span>
        </div>
    </div>
</body>
</html>