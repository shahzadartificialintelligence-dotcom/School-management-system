<?php
session_start();
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role checkk

$success = '';
$error = '';
$editUser = null;

// 2. Delete User Logic
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    if ($_GET['delete'] == $_SESSION['user_id']) {
        $error = "Security Error: You cannot delete your own account.";
    } else {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        header("Location: manage-users.php?msg=User+Deleted");
        exit();
    }
}

// 3. Fetch User for Editing
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_GET['edit']]);
    $editUser = $stmt->fetch(PDO::FETCH_ASSOC);
}

// 4. Handle Add/Update Form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'] ?? 'admin';
    $status = $_POST['status'] ?? 'active';
    $id = $_POST['user_id'] ?? null;

    if (empty($full_name) || empty($email)) {
        $error = "Name and Email are required fields.";
    } else {
        try {
            if ($id) {
                // UPDATE
                if (!empty($password)) {
                    $hashed = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET full_name=?, email=?, password=?, role=?, status=?, updated_at=NOW() WHERE id=?");
                    $stmt->execute([$full_name, $email, $hashed, $role, $status, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE users SET full_name=?, email=?, role=?, status=?, updated_at=NOW() WHERE id=?");
                    $stmt->execute([$full_name, $email, $role, $status, $id]);
                }
                $success = "User updated successfully.";
            } else {
                // INSERT NEW
                $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $check->execute([$email]);
                if ($check->fetch()) {
                    $error = "This email is already in use.";
                } else {
                    $hashed = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password, role, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$full_name, $email, $hashed, $role, $status]);
                    $success = "New user created successfully.";
                }
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// 5. Fetch All Users for the List
$search = $_GET['search'] ?? '';
$sql = "SELECT * FROM users";
if ($search) {
    $sql .= " WHERE full_name LIKE :s OR email LIKE :s OR role LIKE :s";
}
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
if ($search) $stmt->bindValue(':s', "%$search%");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manage Users | Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap');
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: #f3f4f6;
            -webkit-tap-highlight-color: transparent;
        }
        .card-glass { 
            background: rgba(255, 255, 255, 0.9); 
            backdrop-filter: blur(8px); 
            border: 1px solid rgba(255,255,255,0.4); 
        }
        
        /* Mobile optimizations */
        @media (max-width: 640px) {
            .table-card-view {
                display: block;
            }
            .table-card-view thead {
                display: none;
            }
            .table-card-view tbody tr {
                display: block;
                margin-bottom: 1rem;
                border: 1px solid #e5e7eb;
                border-radius: 0.75rem;
                padding: 1rem;
                background: white;
            }
            .table-card-view tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.5rem !important;
                border: none;
            }
            .table-card-view tbody td:before {
                content: attr(data-label);
                font-weight: 600;
                color: #6b7280;
                font-size: 0.75rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }
        }

        /* Smooth transitions */
        .transition-all {
            transition: all 0.2s ease;
        }
        
        /* Better touch targets for mobile */
        button, a, [role="button"], input, select {
            touch-action: manipulation;
        }
        
        /* Improve form element spacing on mobile */
        @media (max-width: 640px) {
            input, select, button {
                min-height: 44px;
            }
        }
    </style>
</head>
<body class="p-3 sm:p-4 md:p-8 min-h-screen">

    <div class="max-w-7xl mx-auto">
        <!-- Header Section - Mobile Optimized -->
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 md:mb-8 gap-4">
            <div class="w-full sm:w-auto">
                <h1 class="text-xl sm:text-2xl font-bold text-gray-800 tracking-tight">User Management</h1>
                <p class="text-xs sm:text-sm text-gray-500 mt-1">Add, update, or remove system users and admins.</p>
            </div>
            <div class="flex gap-2 w-full sm:w-auto">
                <a href="girls_dashboard.php" class="flex-1 sm:flex-none bg-white px-3 sm:px-4 py-2.5 sm:py-2 rounded-lg shadow-sm border text-sm font-medium text-gray-600 hover:bg-gray-50 transition flex items-center justify-center gap-2">
                    <i class="fa-solid fa-house"></i>
                    <span class="sm:inline">Dashboard</span>
                </a>
            </div>
        </div>

        <!-- Alert Messages - Mobile Optimized -->
        <?php if ($success || isset($_GET['msg'])): ?>
            <div class="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl mb-4 md:mb-6 flex items-center gap-3 text-sm md:text-base">
                <i class="fa-solid fa-circle-check flex-shrink-0"></i>
                <span class="break-words"><?= htmlspecialchars($success ?: $_GET['msg']) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-4 md:mb-6 flex items-center gap-3 text-sm md:text-base">
                <i class="fa-solid fa-circle-exclamation flex-shrink-0"></i>
                <span class="break-words"><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <!-- Main Grid - Stack on Mobile -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
            
            <!-- Form Section - Full width on mobile -->
            <div class="lg:col-span-4 order-2 lg:order-1">
                <div class="card-glass p-4 sm:p-6 rounded-2xl shadow-sm border sticky top-4">
                    <h3 class="text-base sm:text-lg font-bold text-gray-800 mb-4 sm:mb-6 flex items-center">
                        <i class="fa-solid <?= $editUser ? 'fa-user-pen text-orange-500' : 'fa-user-plus text-blue-500' ?> mr-2 text-lg sm:text-xl"></i>
                        <span class="truncate"><?= $editUser ? 'Edit User Details' : 'Create New User' ?></span>
                    </h3>
                    
                    <form method="POST" class="space-y-3 sm:space-y-4">
                        <?php if($editUser): ?>
                            <input type="hidden" name="user_id" value="<?= $editUser['id'] ?>">
                        <?php endif; ?>

                        <div>
                            <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Full Name</label>
                            <input type="text" name="full_name" required value="<?= htmlspecialchars($editUser['full_name'] ?? '') ?>" 
                                   class="w-full px-3 sm:px-4 py-2.5 sm:py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition text-sm sm:text-base"
                                   placeholder="Enter full name">
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Email Address</label>
                            <input type="email" name="email" required value="<?= htmlspecialchars($editUser['email'] ?? '') ?>" 
                                   class="w-full px-3 sm:px-4 py-2.5 sm:py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition text-sm sm:text-base"
                                   placeholder="Enter email">
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Password <?= $editUser ? '<span class="text-amber-500 font-normal lowercase">(Optional)</span>' : '' ?></label>
                            <input type="password" name="password" <?= $editUser ? '' : 'required' ?> 
                                   placeholder="<?= $editUser ? 'Leave blank to keep current' : 'Enter password' ?>"
                                   class="w-full px-3 sm:px-4 py-2.5 sm:py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none transition text-sm sm:text-base">
                        </div>

                        <div class="grid grid-cols-2 gap-3 sm:gap-4">
                            <div>
                                <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Role</label>
                                <select name="role" class="w-full px-3 sm:px-4 py-2.5 sm:py-2.5 rounded-xl border border-gray-200 outline-none focus:border-blue-500 transition text-sm sm:text-base bg-white">
                                    <option value="admin" <?= (isset($editUser) && $editUser['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                                    <option value="staff" <?= (isset($editUser) && $editUser['role'] == 'staff') ? 'selected' : '' ?>>Staff</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-400 uppercase mb-1 ml-1">Status</label>
                                <select name="status" class="w-full px-3 sm:px-4 py-2.5 sm:py-2.5 rounded-xl border border-gray-200 outline-none focus:border-blue-500 transition text-sm sm:text-base bg-white">
                                    <option value="active" <?= (isset($editUser) && $editUser['status'] == 'active') ? 'selected' : '' ?>>Active</option>
                                    <option value="inactive" <?= (isset($editUser) && $editUser['status'] == 'inactive') ? 'selected' : '' ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 sm:py-3 rounded-xl shadow-lg shadow-blue-200 transition-all active:scale-95 text-sm sm:text-base mt-2">
                            <?= $editUser ? 'Update User' : 'Create User' ?>
                        </button>
                        
                        <?php if($editUser): ?>
                            <a href="manage-users.php" class="block text-center text-xs sm:text-sm text-gray-400 hover:text-gray-600 underline py-2">
                                Discard Changes
                            </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- Users List Section - Mobile Optimized Table -->
            <div class="lg:col-span-8 order-1 lg:order-2">
                <div class="bg-white rounded-2xl shadow-sm border overflow-hidden">
                    <!-- Search Bar - Mobile Optimized -->
                    <div class="p-3 sm:p-4 border-b">
                        <form method="GET" class="relative">
                            <i class="fa-solid fa-magnifying-glass absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm sm:text-base"></i>
                            <input type="text" name="search" placeholder="Search by name, email, or role..." value="<?= htmlspecialchars($search) ?>"
                                   class="w-full pl-9 sm:pl-11 pr-3 sm:pr-4 py-2.5 sm:py-2 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-blue-500 outline-none transition text-sm sm:text-base">
                        </form>
                    </div>

                    <!-- Table - Convert to Cards on Mobile -->
                    <div class="overflow-x-auto">
                        <table class="w-full text-left table-card-view">
                            <thead class="bg-gray-50 text-gray-400 text-[10px] uppercase font-bold tracking-widest">
                                <tr>
                                    <th class="px-4 sm:px-6 py-3 sm:py-4">User Details</th>
                                    <th class="px-4 sm:px-6 py-3 sm:py-4 text-center">Role</th>
                                    <th class="px-4 sm:px-6 py-3 sm:py-4 text-center">Status</th>
                                    <th class="px-4 sm:px-6 py-3 sm:py-4 text-center">Last Login</th>
                                    <th class="px-4 sm:px-6 py-3 sm:py-4 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php foreach ($users as $u): ?>
                                <tr class="hover:bg-blue-50/30 transition group">
                                    <td class="px-4 sm:px-6 py-3 sm:py-4" data-label="User">
                                        <div class="font-semibold text-gray-800 text-sm sm:text-base"><?= htmlspecialchars($u['full_name']) ?></div>
                                        <div class="text-xs text-gray-400 break-words"><?= htmlspecialchars($u['email']) ?></div>
                                    </td>
                                    <td class="px-4 sm:px-6 py-3 sm:py-4 text-center" data-label="Role">
                                        <span class="text-[10px] sm:text-xs font-bold px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-md <?= $u['role'] == 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-600' ?>">
                                            <?= strtoupper($u['role']) ?>
                                        </span>
                                    </td>
                                    <td class="px-4 sm:px-6 py-3 sm:py-4 text-center" data-label="Status">
                                        <div class="flex items-center justify-center gap-1">
                                            <span class="inline-block w-2 h-2 rounded-full <?= $u['status'] == 'active' ? 'bg-green-500' : 'bg-red-400' ?>"></span>
                                            <span class="text-xs font-medium text-gray-600 lowercase"><?= $u['status'] ?></span>
                                        </div>
                                    </td>
                                    <td class="px-4 sm:px-6 py-3 sm:py-4 text-center text-xs text-gray-500" data-label="Last Login">
                                        <?= $u['last_login'] ? date('d M, H:i', strtotime($u['last_login'])) : 'Never' ?>
                                    </td>
                                    <td class="px-4 sm:px-6 py-3 sm:py-4 text-right" data-label="Actions">
                                        <div class="flex justify-end gap-1 sm:gap-2">
                                            <a href="?edit=<?= $u['id'] ?>" class="p-2 sm:p-2 text-blue-500 hover:bg-blue-100 rounded-lg transition" title="Edit">
                                                <i class="fa-solid fa-pen text-sm sm:text-base"></i>
                                            </a>
                                            <a href="?delete=<?= $u['id'] ?>" onclick="return confirm('Confirm deletion of this user?')" 
                                               class="p-2 sm:p-2 text-red-500 hover:bg-red-100 rounded-lg transition" title="Delete">
                                                <i class="fa-solid fa-trash-can text-sm sm:text-base"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Empty State -->
                    <?php if (empty($users)): ?>
                    <div class="text-center py-8 sm:py-12">
                        <i class="fa-solid fa-users-slash text-gray-300 text-4xl sm:text-5xl mb-3"></i>
                        <p class="text-gray-500 text-sm sm:text-base">No users found</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile-specific improvements -->
    <script>
        // Prevent zoom on form inputs for better mobile experience
        document.addEventListener('touchstart', function(e) {
            if (e.target.nodeName === 'INPUT' || e.target.nodeName === 'SELECT' || e.target.nodeName === 'TEXTAREA') {
                e.target.style.fontSize = '16px';
            }
        }, { passive: true });
    </script>
</body>
</html>