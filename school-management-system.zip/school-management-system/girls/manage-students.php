<?php
session_start();
require_once __DIR__ . '/../config/girlsdp.php';
require_once __DIR__ . '/../auth/girls-session_check.php';   // ✅ Must load before role check

// AJAX Handler for loading students by class
if (isset($_GET['get_students_by_class'])) {
    $class_id = $_GET['get_students_by_class'];
    $stmt = $pdo->prepare("SELECT id, student_name, parent_name FROM students WHERE class_id = ? ORDER BY student_name");
    $stmt->execute([$class_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// AJAX Handler for fetching parent's name from a specific student
if (isset($_GET['get_parent_by_sibling'])) {
    $sibling_id = $_GET['get_parent_by_sibling'];
    $stmt = $pdo->prepare("SELECT parent_name FROM students WHERE id = ? LIMIT 1");
    $stmt->execute([$sibling_id]);
    echo $stmt->fetchColumn();
    exit;
}

$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);
$editStudent = null;
$error = "";
$success = "";
$search = $_GET['search'] ?? '';

/* ================= EDIT ================= */
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ? LIMIT 1");
    $stmt->execute([$_GET['edit']]);
    $editStudent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // If editing, parse sibling_ids for checkboxes
    if ($editStudent && !empty($editStudent['sibling_ids'])) {
        $editStudent['sibling_array'] = explode(',', $editStudent['sibling_ids']);
    }
}

/* ================= DELETE ================= */
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $pdo->beginTransaction();
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

        // Get image name to delete the file
        $stmt = $pdo->prepare("SELECT image FROM students WHERE id = ?");
        $stmt->execute([$_GET['delete']]);
        $img = $stmt->fetchColumn();
        if ($img && file_exists("uploads/" . $img)) {
            unlink("uploads/" . $img);
        }

        // Delete the student
        $del = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $del->execute([$_GET['delete']]);

        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $pdo->commit();
        
        header("Location: manage-students.php?success=Student+deleted+successfully");
        exit();

    } catch (Exception $e) {
        $pdo->rollBack();
        header("Location: manage-students.php?error=" . urlencode("Delete failed: " . $e->getMessage()));
        exit();
    }
}

/* ================= ADD / UPDATE ================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $dob = $_POST['dob'];
    $class_id = (int)$_POST['class_id'];
    $roll_input = (int)$_POST['roll_no'];
    $parent_name = trim($_POST['parent_name']);
    $address = trim($_POST['address'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $admission_date = $_POST['admission_date'];
    $total_fees = $_POST['total_fees'] ?? 0;
    
    // Sibling IDs from checkboxes (stored as comma separated string)
    $sibling_ids = isset($_POST['siblings']) ? implode(',', $_POST['siblings']) : null;

    // Handle image upload
    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileExt = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $imageName = time() . '_' . uniqid() . '.' . $fileExt;
        $uploadPath = $uploadDir . $imageName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath)) {
            // If updating, delete old image
            if ($id && $editStudent && !empty($editStudent['image']) && file_exists($uploadDir . $editStudent['image'])) {
                unlink($uploadDir . $editStudent['image']);
            }
        } else {
            $error = "Failed to upload image.";
        }
    } elseif ($id && !empty($_POST['existing_image'])) {
        // Keep existing image when no new image uploaded
        $imageName = $_POST['existing_image'];
    }

    if (empty($error)) {
        $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id=? LIMIT 1");
        $stmt->execute([$class_id]);
        $class_name = $stmt->fetchColumn();
        $roll_no = $roll_input;

        if (!$id) {
            // Generate unique std_id
            do {
                $std_id = "STD" . rand(1000, 9999);
                $checkStd = $pdo->prepare("SELECT id FROM students WHERE std_id=?");
                $checkStd->execute([$std_id]);
            } while($checkStd->rowCount() > 0);

            $stmt = $pdo->prepare("INSERT INTO students (std_id, student_name, email, dob, class_id, roll_no, parent_name, address, phone, admission_date, total_fees, sibling_ids, image, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$std_id, $name, $email, $dob, $class_id, $roll_no, $parent_name, $address, $phone, $admission_date, $total_fees, $sibling_ids, $imageName]);
            $success = "Student added successfully!";
        } else {
            $stmt = $pdo->prepare("UPDATE students SET student_name=?, email=?, dob=?, class_id=?, roll_no=?, parent_name=?, address=?, phone=?, admission_date=?, total_fees=?, sibling_ids=?, image=?, updated_at=NOW() WHERE id=?");
            $stmt->execute([$name, $email, $dob, $class_id, $roll_no, $parent_name, $address, $phone, $admission_date, $total_fees, $sibling_ids, $imageName, $id]);
            $success = "Student updated successfully!";
        }
        header("Location: manage-students.php?success=" . urlencode($success));
        exit();
    }
}

// Basic Fetch for Table
$stmt = $pdo->prepare("SELECT s.*, c.class_name FROM students s LEFT JOIN classes c ON s.class_id = c.id WHERE s.student_name LIKE ? ORDER BY s.id DESC");
$stmt->execute(["%$search%"]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>Manage Students</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap');
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #f3f4f6;
            -webkit-tap-highlight-color: transparent;
        }
        
        /* Mobile optimizations */
        @media (max-width: 768px) {
            .table-card-view {
                display: block;
            }
            .table-card-view thead {
                display: none;
            }
            .table-card-view tbody tr {
                display: block;
                margin-bottom: 1rem;
                border: 1px solid #e5e7eb;
                border-radius: 0.75rem;
                padding: 1rem;
                background: white;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            }
            .table-card-view tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.5rem !important;
                border: none;
                border-bottom: 1px dashed #f0f0f0;
            }
            .table-card-view tbody td:last-child {
                border-bottom: none;
            }
            .table-card-view tbody td:before {
                content: attr(data-label);
                font-weight: 600;
                color: #6b7280;
                font-size: 0.75rem;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                margin-right: 1rem;
            }
        }

        /* Better touch targets */
        button, a, [role="button"], input, select, textarea {
            touch-action: manipulation;
        }
        
        @media (max-width: 640px) {
            input, select, button, textarea {
                min-height: 44px;
                font-size: 16px !important; /* Prevents zoom on iOS */
            }
        }
        
        /* Smooth transitions */
        .transition-all {
            transition: all 0.2s ease;
        }
        
        /* Custom scrollbar for sibling list */
        #siblingList {
            scrollbar-width: thin;
            scrollbar-color: #cbd5e1 #f1f5f9;
        }
        #siblingList::-webkit-scrollbar {
            width: 6px;
        }
        #siblingList::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 10px;
        }
        #siblingList::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
    </style>
</head>
<body class="bg-gray-100 p-3 sm:p-4 md:p-8 min-h-screen">

<div class="max-w-7xl mx-auto">
    <!-- Header - Mobile Optimized -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 md:mb-6 gap-3">
        <h1 class="text-xl sm:text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
            <i class="fas fa-user-graduate mr-2 text-blue-600 text-xl sm:text-2xl"></i>
            <span>Manage Students</span>
        </h1>
        <a href="girls_dashboard.php" class="w-full sm:w-auto bg-gray-600 text-white px-4 sm:px-6 py-2.5 sm:py-2 rounded-lg shadow hover:bg-gray-700 transition text-center text-sm sm:text-base flex items-center justify-center gap-2">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </div>

    <!-- Alert Messages - Mobile Optimized -->
    <?php if ($error): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm sm:text-base flex items-center gap-2">
            <i class="fas fa-exclamation-circle"></i>
            <span><?= $error ?></span>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['success'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm sm:text-base flex items-center gap-2">
            <i class="fas fa-check-circle"></i>
            <span><?= htmlspecialchars($_GET['success']) ?></span>
        </div>
    <?php endif; ?>

    <!-- Form Section - Mobile Optimized -->
    <div class="bg-white rounded-lg shadow-lg mb-6 overflow-hidden">
        <div class="p-4 sm:p-6 border-b bg-gray-50">
            <h2 class="text-base sm:text-lg font-bold text-gray-700 flex items-center">
                <i class="fas fa-<?= $editStudent ? 'edit' : 'plus-circle' ?> mr-2 text-blue-600"></i>
                <?= $editStudent ? 'Edit Student Details' : 'Add New Student' ?>
            </h2>
        </div>
        
        <form method="POST" enctype="multipart/form-data" class="p-4 sm:p-6">
            <input type="hidden" name="id" value="<?= $editStudent['id'] ?? '' ?>">
            <?php if ($editStudent && !empty($editStudent['image'])): ?>
                <input type="hidden" name="existing_image" value="<?= $editStudent['image'] ?>">
            <?php endif; ?>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                <!-- Basic Information -->
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Student Name *</label>
                    <input type="text" name="name" required value="<?= htmlspecialchars($editStudent['student_name'] ?? '') ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base" placeholder="Enter full name">
                </div>
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Email *</label>
                    <input type="email" name="email" required value="<?= htmlspecialchars($editStudent['email'] ?? '') ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base" placeholder="student@example.com">
                </div>
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Date of Birth *</label>
                    <input type="date" name="dob" required value="<?= $editStudent['dob'] ?? '' ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base">
                </div>
                
                <!-- Class and Roll -->
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Class *</label>
                    <select name="class_id" required class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base bg-white">
                        <option value="">Select Class</option>
                        <?php foreach($classes as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= (isset($editStudent['class_id']) && $editStudent['class_id'] == $c['id']) ? 'selected' : '' ?>>Class <?= $c['class_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Roll Number *</label>
                    <input type="number" name="roll_no" required value="<?= $editStudent ? preg_replace('/[^0-9]/', '', $editStudent['roll_no']) : '' ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base" placeholder="Enter roll number">
                </div>
                
                <!-- Parent/Father Name -->
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Parent/Father Name *</label>
                    <input type="text" name="parent_name" id="parent_name" required value="<?= htmlspecialchars($editStudent['parent_name'] ?? '') ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base" placeholder="Enter parent name">
                </div>
                
                <!-- Contact Information -->
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Phone Number</label>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($editStudent['phone'] ?? '') ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base" placeholder="Enter phone number">
                </div>
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Admission Date</label>
                    <input type="date" name="admission_date" value="<?= $editStudent['admission_date'] ?? date('Y-m-d') ?>" 
                           class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base">
                </div>
                
                <!-- Fees -->
                <div>
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-blue-600">Total Fees (Monthly/Annual)</label>
                    <input type="number" name="total_fees" value="<?= $editStudent['total_fees'] ?? '' ?>" 
                           class="border border-blue-300 p-2.5 sm:p-2 rounded-lg w-full font-bold text-sm sm:text-base" placeholder="Enter fees amount">
                </div>
                
                <!-- Student Image -->
                <div class="sm:col-span-2 lg:col-span-1">
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Student Image</label>
                    <input type="file" name="image" accept="image/*" class="border p-2 rounded-lg w-full text-sm sm:text-base">
                    <?php if ($editStudent && !empty($editStudent['image'])): ?>
                        <div class="mt-2 flex items-center gap-3">
                            <img src="uploads/<?= $editStudent['image'] ?>" class="h-12 w-12 sm:h-16 sm:w-16 object-cover rounded-lg border">
                            <span class="text-xs text-gray-500">Current image</span>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Address - Full Width -->
                <div class="sm:col-span-2 lg:col-span-3">
                    <label class="block font-semibold mb-1 text-xs sm:text-sm text-gray-600">Address</label>
                    <textarea name="address" rows="2" class="border p-2.5 sm:p-2 rounded-lg w-full text-sm sm:text-base" placeholder="Enter full address"><?= htmlspecialchars($editStudent['address'] ?? '') ?></textarea>
                </div>

                <!-- Siblings Section -->
                <div class="sm:col-span-2 lg:col-span-3 border-t pt-4 mt-2">
                    <label class="inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="hasSibling" class="h-5 w-5 text-blue-600 rounded" 
                            <?= ($editStudent && !empty($editStudent['sibling_ids'])) ? 'checked' : '' ?>
                            onchange="document.getElementById('siblingSection').classList.toggle('hidden')">
                        <span class="ml-2 font-bold text-gray-700 text-sm sm:text-base">Has Siblings in School?</span>
                    </label>
                    
                    <div id="siblingSection" class="<?= ($editStudent && !empty($editStudent['sibling_ids'])) ? '' : 'hidden' ?> mt-4 bg-gray-50 p-3 sm:p-4 rounded-lg">
                        <p class="text-xs sm:text-sm text-gray-500 mb-3 font-semibold">Select Sibling's Class to load students:</p>
                        
                        <div class="flex flex-col sm:flex-row gap-3 mb-4">
                            <select id="siblingClassSelect" onchange="loadClassStudents(this.value)" class="border p-2.5 sm:p-2 rounded-lg w-full sm:w-1/2 lg:w-1/3 text-sm sm:text-base bg-white">
                                <option value="">-- Choose Class --</option>
                                <?php foreach($classes as $c): ?>
                                    <option value="<?= $c['id'] ?>">Class <?= $c['class_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            
                            <button type="button" onclick="clearSiblingSelection()" class="bg-gray-500 text-white px-4 py-2.5 sm:py-2 rounded-lg hover:bg-gray-600 transition text-sm">
                                <i class="fas fa-times mr-1"></i> Clear
                            </button>
                        </div>
                        
                        <div id="siblingList" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 max-h-60 overflow-y-auto p-2 border rounded-lg bg-white">
                            <!-- Siblings will be loaded here via AJAX -->
                            <?php if ($editStudent && !empty($editStudent['sibling_ids'])): ?>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        setTimeout(function() {
                                            loadAllSiblings();
                                        }, 500);
                                    });
                                </script>
                            <?php endif; ?>
                        </div>
                        
                        <p class="text-xs text-gray-500 mt-3 flex items-center gap-1">
                            <i class="fas fa-info-circle text-blue-500"></i> 
                            Check the siblings of this student. Parent name will auto-fill from selected sibling.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Form Actions -->
            <div class="mt-6 flex flex-col sm:flex-row gap-3">
                <button type="submit" class="w-full sm:w-auto bg-green-600 text-white font-bold py-3 sm:py-2 px-8 rounded-lg hover:bg-green-700 transition text-sm sm:text-base flex items-center justify-center gap-2">
                    <i class="fas fa-save"></i>
                    <?= $editStudent ? 'Update Student' : 'Save Student' ?>
                </button>
                <?php if ($editStudent): ?>
                    <a href="manage-students.php" class="w-full sm:w-auto bg-gray-500 text-white font-bold py-3 sm:py-2 px-6 rounded-lg hover:bg-gray-600 transition text-sm sm:text-base text-center flex items-center justify-center gap-2">
                        <i class="fas fa-times"></i>
                        Cancel
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Search Bar - Mobile Optimized -->
    <div class="mb-4">
        <form method="GET" class="flex flex-col sm:flex-row gap-2">
            <div class="flex-1 relative">
                <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                <input type="text" name="search" placeholder="Search by student name..." value="<?= htmlspecialchars($search) ?>" 
                       class="border p-2.5 sm:p-2 rounded-lg w-full pl-9 text-sm sm:text-base">
            </div>
            <div class="flex gap-2">
                <button type="submit" class="flex-1 sm:flex-none bg-blue-600 text-white px-4 py-2.5 sm:py-2 rounded-lg hover:bg-blue-700 transition text-sm flex items-center justify-center gap-2">
                    <i class="fas fa-search"></i>
                    <span class="sm:hidden">Search</span>
                </button>
                <?php if ($search): ?>
                    <a href="manage-students.php" class="flex-1 sm:flex-none bg-gray-500 text-white px-4 py-2.5 sm:py-2 rounded-lg hover:bg-gray-600 transition text-sm flex items-center justify-center gap-2">
                        <i class="fas fa-times"></i>
                        <span class="sm:hidden">Clear</span>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Students Table - Mobile Card View -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left table-card-view">
                <thead class="bg-gray-200 text-gray-600 text-xs uppercase font-bold">
                    <tr>
                        <th class="p-3 sm:p-4">Student ID</th>
                        <th class="p-3 sm:p-4">Image</th>
                        <th class="p-3 sm:p-4">Name</th>
                        <th class="p-3 sm:p-4">Roll No</th>
                        <th class="p-3 sm:p-4">Class</th>
                        <th class="p-3 sm:p-4">Father Name</th>
                        <th class="p-3 sm:p-4">Phone</th>
                        <th class="p-3 sm:p-4">Total Fees</th>
                        <th class="p-3 sm:p-4">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach($students as $s): ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="p-3 sm:p-4 font-mono text-xs sm:text-sm" data-label="Student ID"><?= $s['std_id'] ?></td>
                        <td class="p-3 sm:p-4" data-label="Image">
                            <?php if (!empty($s['image']) && file_exists("uploads/" . $s['image'])): ?>
                                <img src="uploads/<?= $s['image'] ?>" class="h-8 w-8 sm:h-10 sm:w-10 object-cover rounded-full border">
                            <?php else: ?>
                                <div class="h-8 w-8 sm:h-10 sm:w-10 bg-gray-200 rounded-full flex items-center justify-center text-gray-500 text-xs">
                                    <i class="fas fa-user"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="p-3 sm:p-4 font-medium text-sm sm:text-base" data-label="Name"><?= htmlspecialchars($s['student_name']) ?></td>
                        <td class="p-3 sm:p-4 text-sm" data-label="Roll No"><?= $s['roll_no'] ?></td>
                        <td class="p-3 sm:p-4 text-sm" data-label="Class">Class <?= $s['class_name'] ?></td>
                        <td class="p-3 sm:p-4 text-sm" data-label="Father Name"><?= htmlspecialchars($s['parent_name']) ?></td>
                        <td class="p-3 sm:p-4 text-sm" data-label="Phone"><?= $s['phone'] ?? '-' ?></td>
                        <td class="p-3 sm:p-4 font-semibold text-green-700 text-sm" data-label="Total Fees">₹<?= number_format($s['total_fees']) ?></td>
                        <td class="p-3 sm:p-4" data-label="Actions">
                            <div class="flex gap-2 sm:gap-3">
                                <a href="?edit=<?= $s['id'] ?>&search=<?= urlencode($search) ?>" class="text-blue-600 hover:text-blue-900 p-2" title="Edit">
                                    <i class="fas fa-edit text-sm sm:text-base"></i>
                                </a>
                                <a href="?delete=<?= $s['id'] ?>&search=<?= urlencode($search) ?>" onclick="return confirm('Delete this student?')" class="text-red-600 hover:text-red-900 p-2" title="Delete">
                                    <i class="fas fa-trash text-sm sm:text-base"></i>
                                </a>
                                <?php if (!empty($s['sibling_ids'])): ?>
                                    <span class="text-green-600 p-2" title="Has siblings"><i class="fas fa-users text-sm sm:text-base"></i></span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($students)): ?>
                    <tr>
                        <td colspan="9" class="p-8 text-center text-gray-500">
                            <i class="fas fa-users-slash text-3xl mb-2"></i>
                            <p>No students found.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Store all loaded siblings for reference
let allLoadedStudents = [];

// Load students when sibling class is selected
function loadClassStudents(classId) {
    if(!classId) return;
    
    const container = document.getElementById('siblingList');
    container.innerHTML = '<div class="col-span-4 text-center py-4"><i class="fas fa-spinner fa-spin mr-2"></i>Loading students...</div>';

    fetch(`?get_students_by_class=${classId}`)
        .then(res => res.json())
        .then(data => {
            allLoadedStudents = data;
            displaySiblings(data);
        })
        .catch(error => {
            container.innerHTML = '<div class="col-span-4 text-center py-4 text-red-500">Error loading students.</div>';
        });
}

// Display siblings in the grid
function displaySiblings(students) {
    const container = document.getElementById('siblingList');
    const currentSiblingIds = <?= json_encode($editStudent['sibling_array'] ?? []) ?>;
    
    if (students.length === 0) {
        container.innerHTML = '<div class="col-span-4 text-center py-4 text-gray-500">No students found in this class.</div>';
        return;
    }
    
    container.innerHTML = "";
    students.forEach(st => {
        const isChecked = currentSiblingIds.includes(String(st.id));
        container.innerHTML += `
            <label class="flex items-center p-2 border rounded-lg cursor-pointer hover:bg-blue-50 transition ${isChecked ? 'bg-blue-100 border-blue-300' : 'bg-white'}">
                <input type="checkbox" name="siblings[]" value="${st.id}" class="mr-2 sibling-checkbox" 
                       onchange="handleSiblingCheck(this, ${st.id}, '${st.parent_name.replace(/'/g, "\\'")}')"
                       ${isChecked ? 'checked' : ''}>
                <span class="text-xs sm:text-sm font-medium truncate">${st.student_name}</span>
            </label>
        `;
    });
}

// Handle sibling checkbox change
function handleSiblingCheck(checkbox, siblingId, parentName) {
    if (checkbox.checked) {
        // Auto-fill parent name if not already filled
        const parentField = document.getElementById('parent_name');
        if (!parentField.value) {
            parentField.value = parentName;
        }
        
        // Highlight the selected sibling
        checkbox.closest('label').classList.add('bg-blue-100', 'border-blue-300');
    } else {
        // Remove highlight
        checkbox.closest('label').classList.remove('bg-blue-100', 'border-blue-300');
    }
}

// Clear sibling selection
function clearSiblingSelection() {
    document.querySelectorAll('input[name="siblings[]"]').forEach(cb => {
        cb.checked = false;
        cb.closest('label').classList.remove('bg-blue-100', 'border-blue-300');
    });
    document.getElementById('siblingClassSelect').value = '';
    document.getElementById('siblingList').innerHTML = '';
}

// Load all siblings when editing (for multiple classes)
function loadAllSiblings() {
    const currentSiblingIds = <?= json_encode($editStudent['sibling_array'] ?? []) ?>;
    if (currentSiblingIds.length === 0) return;
    
    // Fetch each sibling's details
    currentSiblingIds.forEach(id => {
        fetch(`?get_parent_by_sibling=${id}`)
            .then(res => res.text())
            .then(name => {
                console.log(`Sibling ID ${id}: ${name}`);
            });
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($editStudent && !empty($editStudent['sibling_ids'])): ?>
        const siblingIds = <?= json_encode($editStudent['sibling_array'] ?? []) ?>;
        if (siblingIds.length > 0) {
            // You could load the first sibling's class here
        }
    <?php endif; ?>
    
    // Add real-time validation
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const email = document.querySelector('input[name="email"]').value;
            const phone = document.querySelector('input[name="phone"]').value;
            
            if (phone && !/^[0-9+\-\s]{10,15}$/.test(phone)) {
                e.preventDefault();
                alert('Please enter a valid phone number (10-15 digits)');
            }
        });
    }
});

// Auto-hide success/error messages after 5 seconds
setTimeout(function() {
    document.querySelectorAll('.bg-green-100, .bg-red-100').forEach(el => {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 500);
    });
}, 5000);

// Prevent zoom on input focus for iOS
document.addEventListener('touchstart', function(e) {
    if (e.target.nodeName === 'INPUT' || e.target.nodeName === 'SELECT' || e.target.nodeName === 'TEXTAREA') {
        e.target.style.fontSize = '16px';
    }
}, { passive: true });
</script>

</body>
</html>